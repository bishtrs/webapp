<?php 
    include("header.htm");
?>

<head>
    <title>Python List</title>
	<meta name="description" content="Python List" />
	<link rel="canonical" href="https://www.techblogss.com/python/python-list" />
	<style>
		table, td, th {
		  border: 1px solid black;
		}
		th, td {
		  padding: 10px;
		  text-align: center;
		}
	</style>
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Python List</h1>
	</div>
	<div id="solution">
		<p>
		<b><i>List</b></i> is a ordered set of values enclosed in square brackets []. A <b><i>List</b></i> is mutable which means its values can be
		modified. The values that make up a list are called its elements, and they can be of any type.  The first index is zero, the second index is one, and so on.
		Belows are some example of a simple list:
		</p>
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>>countries = ["India", "Nepal", "Russia"] 
>>>nestedList = [1, 2, [3, 4, 5], 6]
</pre> 
		<br>

        <h2>1) Creating a List</h2>
		<p>List can be created in follwing ways:</p>
		
		<h3>a. By enclosing elements in [ ]</h3>

<pre class="prettyprint">>>>numbers = [1,2,3,4,5]</pre>
		<h3>b. From another List</h3>
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>>subset = numbers[1:4]</pre>

		<h3>c. List comprehension</h3>
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>>subset = []
>>>for i in numbers :
       subset.append (i+3)
>>> subset
[4, 5, 6, 7, 8]</pre>
		
<!--		<h3>4. Using built-in object</h3>
<pre class="prettyprint"># emptry list
>>>numbers = list() 

>>>numbers = list[(1,2,3,4)]</pre>-->

<br>

		<h2>2) Accessing Elements in a List</h2>
		
		
		<h3>a. By index</h3>
		<p>For accessing an element, we use index.</p>
		
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> number[1]	
2
>>> numbers[-2]
4
</pre>

		<h3>b. Using pair of index</h3>
		<p>To access an element of list containing another list, we use pair of index.</p>

		<pre class="prettyprint">>>> numbers = [1,2,[3,4,5]]
>>> numbers[2]
[3, 4, 5]
>>> numbers[2][1]
4</pre>

		<h3>c. List slice</h3>
		<p>Slice operator works on list also. We know that a slice of a list is its sub-list. For creating a list slice, we use [n:m] operator.</p>
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> numbers[1:2]
[2]
>>> numbers[1:4]
[2, 3, 4]</pre>

		<h3>d. List slice using steps.</h3>
		<p>We can also slice a list by steps as shown below.</p>
<pre class="prettyprint">>>>numbers = [1,2,3,4,5,6,7,8,9,10]
>>> numbers[0:10:2]
[1, 3, 5, 7, 9]
</pre>
<br>

		<h2>3) Traversing a List</h2>
		
		
		<h3>a. Using for loop</h3>
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> for i in numbers:
        print (i)
1
2
3
4
5
</pre>
<br>

		<h3>b. Using while loop</h3>

<pre class="prettyprint">>>> numbers = [1,2,3,4,5]
>>> while i &lt; len(numbers):
	print(numbers[i])
	i = i +1

1
2
3
4
5</pre>

		<h3>c. Using for loop with range</h3>
		
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> for i in range ( len (numbers))
        numbers
1
2
3
4
5</pre>
<br>
		<h2>4) Appending to a List</h2>
		
		
		<h3>a. Using append()</h3>
		<p>To add new elements at the end of the list, Python provides a method append ( ).</p>
				
<pre class="prettyprint">>>> numbers = [1,2,3,4,5]
>>> numbers.append(6)
>>> numbers
[1, 2, 3, 4, 5, 6]
</pre>

		<h3>a. Using extend()</h3>
		<p>append() method can add only one element to a list. To add multiple elements, you can use extend() method.</p>
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> list = [6,7,8,9]
>>> numbers.extend(list)
>>> numbers
[1, 2, 3, 4, 5, 6, 7, 8, 9]
</pre>
<br>
		<h2>5) Updating array elements of a List</h2>
		
		
		<h3>a. Using index of element</h3>
		
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> numbers[3] = 7
>>> numbers
[1, 2, 3, 7, 5]
</pre>

		<h3>b. Using slice</h3>
		
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> numbers[1:3] = [7,9]
>>> numbers
[1, 7, 9, 4, 5]
>>> numbers[1:5] = [8]
>>> numbers
[1, 8]
>>> numbers = [1,2,3,4,5]
>>> list = numbers*2
>>> list
[1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
</pre>


<br>
		<h2>6) Deleting elements of a List</h2>
		
		
		<h3>a. Using pop() method</h3>
		<p>pop() method removes the element from the specified index, and also return the element which was removed.</p>
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> num = numbers.pop(1)
>>> num
2
>>> numbers
[2, 3, 4, 5]
</pre>

		<h3>b. Using remove() method</h3>
		<p>If we know the element to be deleted but not the index, of the element, then remove() can be used.</p>
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> numbers.remove(4)
>>> numbers
[1, 2, 3, 5]
</pre>

		<h3>c. Using del</h3>
		<p>del removes the specified element from the list, but does not return the deleted value.</p>
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> del numbers[1]
>>> numbers
[2, 3, 4, 5]
</pre>
		
		<h3>d. Using del with slicing</h3>
						
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> del numbers[1:3]
>>> numbers
[1, 4, 5]
</pre>

<br>
		<h2>7) Other important List functions & methods</h2>
		
		
		<h3>a. insert() method</h3>
		<p>This method allows to insert an element at the given position specified by its index. It has following syntax : list. insert (index, item)</p>
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> numbers.insert(3,10)
>>> numbers
[1, 2, 3, 10, 4, 5]
</pre>

		<h3>b. reverse() method</h3>
		<p>reverse() method is used to reverse the elements in a list.</p>
				
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>> numbers.reverse()
>>> numbers
[5, 4, 3, 2, 1]
</pre>

		<h3>c. sort() method</h3>
		<p>sort() method is used for arranging elements in an order. It has following syntax : sort ([cmp [, key [, reverse]]]). <b><i>cmp</b></i> argument allows to override the
		default way of comparing elements of list. By default, sort determines the order of elements by comparing the elements in the list against each other.
		The parameter 'key' is for specifying a function that transforms each element of list before comparison.</p>
				
<pre class="prettyprint">>>>countries = ['Brazil', 'Russia', 'India', 'Australia']
>>> countries.sort()
>>> countries
['Australia', 'Brazil', 'India', 'Russia']
>>> countries = ['Brazil', 'Russia', 'India', 'Australia']
>>> countries.sort(reverse=True)
['Russia', 'India', 'Brazil', 'Australia']
>>> countries
['Australia', 'Brazil', 'India', 'Russia']
>>> countries.sort (key=len)
>>> countries
['India', 'Brazil', 'Russia', 'Australia']
</pre>
		
<br>
		<h2>8) List as arguments</h2>
		
		<p>When a list is passed to the function, the function gets a reference to the list. So if the function makes any changes in the list, they will be
		reflected back in the list.</p>
				
<pre class="prettyprint">>>> def multiply(L):
	for i in range (len(l)):
            L[i] = L[i]*2
>>>numbers = [1,2,3,4,5]
>>>multiply(numbers)
>>>numbers		
[2, 4, 6, 8, 10]
</pre>

		<p>If you create an alias for a list and modify it using the alias, it will impact original list as shown below.</p>
		
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>>numbers2 = numbers
>>>numbers2[2] = 10
>>>numbers		
[1, 2, 10, 4, 5]
</pre>
		
		<p>You can check if both the variables are pointing to the same objects using <b><i>is</b></i></p>

<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>>numbers2 = numbers
>>>numbers is numbers2
True
</pre>
		
		
    </div>	
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>