<?php 
    include("header.htm");
?>

<head>
    <title>Python Installation and Setup</title>
	<meta name="description" content="Python Installation and Setup" />
	<link rel="canonical" href="https://www.techblogss.com/python/python-installation-and-setup" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Python Installation and Setup</h1>
	</div>
	<div id="solution">
		<h4>Step 1) Download latest version of Python from below link </h4>
        <a href="https://www.python.org/downloads/">https://www.python.org/downloads/</a>
        <h4>Step 2) Double click on installer exe file e.g. python-3.8.2.exe, it will launch below screen. </h4>
        <div>
            <p><img src="../images/python/installation.jpg" alt="Python installer" style="width:600px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h4>Step 3) Select option 'Add Python 3.8 to PATH' & click on 'Install Now'</h4>
        <div>
            <p><img src="../images/python/installation2.jpg" alt="Python installer" style="width:600px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
         <h4>Step 4) Once installation is complete, you will see below screen</h4>
         <div>
            <p><img src="../images/python/installation3.jpg" alt="Python installer" style="width:600px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h4>Step 5) Verify Python installation</h4>
         <p>a) Launch Python IDE by clicking on Windows and then on IDLE under Python</p>
        <div>
            <p><img src="../images/python/installation4.jpg" alt="Python installer" style="width:400px;height:400px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <p>b) Type print('Hello World') to print simple 'Hello World' message</p>
        <div>
            <p><img src="../images/python/installation6.jpg" alt="Maven Build" style="width:600px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br>
        <p>c) Type quit() to exit the editor</p>
        <div>
            <p><img src="../images/python/installation5.jpg" alt="Maven Build" style="width:600px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br>

    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
References : <br><br>
<a href="https://www.python.org/downloads/">https://www.python.org/downloads/</a>	<br><br>
 
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>