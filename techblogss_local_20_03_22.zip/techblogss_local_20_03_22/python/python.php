<?php 
    include("header.htm");
?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="Solutions to problems in Python" />
    <link rel="canonical" href="https://www.techblogss.com/python/python">
    <meta name="robots" content="noindex">
</head>

<body>
    <?php include("navigation.htm");?>
	
	<div id="title">
		<div id="topic" class="topic">
		
		<div style='background-color:#159414;color:white'><h3>Python</h3></div>
            <ul id="problems">
                <li><a href="python-installation-and-setup" target="_blank">Python Installation and Setup</a></li>
                <li><a href="execute-python-program" target="_blank">How to execute Python program</a></li>
				<li><a href="python-variable-types" target="_blank">Python variable types</a></li>
				<li><a href="python-operators" target="_blank">Python Operators</a></li>
				<li><a href="python-functions" target="_blank">Python Functions</a></li>
                <li><a href="conditional-and-looping-construct" target="_blank">Conditional and Looping Construct</a></li>
                <li><a href="python-strings" target="_blank">Python Strings</a></li>
				<li><a href="python-list" target="_blank">Python List</a></li>
				<li><a href="python-dictionary" target="_blank">Python Dictionary</a></li>
            </ul>
        </div>
		
	</div>
	

	<div id="contentMain">
		<div id="wrap">
		<h2>Python tutorials</h2>
		<p>Python is an interpreted, high-level, general-purpose programming language. This page provides Python tutorials for software programmers 
        who want to learn Python programming language from scratch.<br><br>
        Please click on the topic on left to see details. The code solutions have been tested with <b><i>Python 3.8</b></i>. <br><br>
        <?php include("share.htm"); ?>
	</div>
	</div>
    
            <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>

	
</body>

<?php include("footer.htm");?>

</html>
