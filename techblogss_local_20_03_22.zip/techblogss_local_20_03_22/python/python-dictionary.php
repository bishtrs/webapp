<?php 
    include("header.htm");
?>

<head>
    <title>Python Dictionary</title>
	<meta name="description" content="Python Dictionary" />
	<link rel="canonical" href="https://www.techblogss.com/python/python-dictionary" />
	<style>
		table, td, th {
		  border: 1px solid black;
		}
		th, td {
		  padding: 10px;
		  text-align: center;
		}
	</style>
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Python Dictionary</h1>
	</div>
	<div id="solution">
		<p>
		<b><i>Dictionary</b></i> stores data in the form of key-value pair. However, dictionary keys are not in sequences and hence doesn't maintain
		left-to right order like List. Belows are some example of a dictionary:
		</p>
<pre class="prettyprint">>>>dict = {1:"Apple",2:"Banana",3:"Orange"}
>>>print(dict)
{1: 'Apple', 2: 'Banana', 3: 'Orange'}
>>>days = {'M':"Monday",'T':"Tuesday",'W':"Wednesday"}
>>>print(days)
{'M': 'Monday', 'T': 'Tuesday', 'W': 'Wednesday'}
</pre> 
		<br>

        <h2>1) Creating a List</h2>
		<p>List can be created in follwing ways:</p>
		
		<h3>a. By enclosing elements in [ ]</h3>

<pre class="prettyprint">>>>numbers = [1,2,3,4,5]</pre>
		<h3>b. From another List</h3>
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>>subset = numbers[1:4]</pre>

		<h3>c. List comprehension</h3>
<pre class="prettyprint">>>>numbers = [1,2,3,4,5]
>>>subset = []
>>>for i in numbers :
       subset.append (i+3)
>>> subset
[4, 5, 6, 7, 8]</pre>
		


<br>



		
    </div>	
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>