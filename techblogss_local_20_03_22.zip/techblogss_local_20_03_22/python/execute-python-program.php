<?php 
    include("header.htm");
?>

<head>
    <title>How to execute Python program</title>
	<meta name="description" content="How to execute Python program" />
	<link rel="canonical" href="https://www.techblogss.com/python/execute-python-program" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to execute a Python program</h1>
	</div>
	<div id="solution">
		<h4>Step 1) Launch Python IDLE</h4>
        <div>
            <p><img src="../images/python/installation4.jpg" alt="Run Python" style="width:400px;height:400px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
        <h4>Step 2) Select File -> New File</h4>
        <div>
            <p><img src="../images/python/run.jpg" alt="Run Python" style="width:600px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
        <h4>Step 3) Write some python code which prints the Python version as shown below and press F5 to Run the code</h4>
        <div>
            <p><img src="../images/python/run2.jpg" alt="Run Python" style="width:600px;height:400px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
         <h4>Step 4) Save the file with .py extension somewhere</h4>
         <div>
            <p><img src="../images/python/run3.jpg" alt="Run Python" style="width:600px;height:400px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h4>Step 5) You will see that in Python shell, run.py is executed and shows the output</h4>
        <div>
            <p><img src="../images/python/run4.jpg" alt="Run Python" style="width:600px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<h4>You can also execute Python program in run.py using windows command prompt by using this command</h4>
		<p>python &lt;file path></p>
        <div>
            <p><img src="../images/python/run5.jpg" alt="Run Python" style="width:700px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
References : <br><br>
<a href="https://www.python.org/downloads/">https://www.python.org/downloads/</a>	<br><br>
 
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>