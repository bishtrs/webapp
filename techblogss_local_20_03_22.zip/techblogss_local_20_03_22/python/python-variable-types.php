<?php 
    include("header.htm");
?>

<head>
    <title>Python variable types</title>
	<meta name="description" content="Python variable types" />
	<link rel="canonical" href="https://www.techblogss.com/python/python-variable-types" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Python variable types</h1>
	</div>
	<div id="solution">
		<p>
		<b><i>Variables</b></i> are reserved memory locations to store values. When we create a program, we often need to store values so
		that they can be used later. In Python values can be assigned to a <b><i>variable</b></i> using <b><i>=</b></i> operator. 
		See few examples below:
		</p>
		<p>
		name = "James" (name is the variable and James is the value)<br>
		sum = 100 (sum is the variable and 100 is the value)
		</p>
		
		<h2>Python variables name should follow these rules :</h2>
		
		<ul>
		<li>A variable name can be of any size.</li>
		<li>A variable name is allowed to have following characters a-z, A-Z, 0-9 and underscore (_)</li>
		<li>A variable name should begin with an alphabet or underscore.</li>
		<li>A variable name should not be a keyword.</li>
		</ul>
		
		<h2>Python has following data types:</h2>
		
		<div>
            <p><img src="../images/python/types.jpg" alt="Python types" style="width:600px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		
		<h2>1. Number </h2>
		<p>
		Number data type stores Numerical Values. These are of three different types:
		</p>
		
		<h4>a) Integer & Long</h4><p> e.g. 10 (Integer), 123456L (Long)</p>
		<h4>b) Floating Point</h4> <p>e.g. 12.30</p>
		<h4>c) Complex</h4> <p>e.g. 3+2j</p>
		
		<h2>2. None </h2>
		<p>
		This is special data type with single value. It is used to signify the absence of value/false in a situation. It is represented by None.
		</p>
		
		<h2>3. Sequence </h2>
		<p>
		A sequence is an ordered collection of items. These are of three different types:
		</p>
		
		<h4>a) String</h4>
		<p>
		String is an ordered sequence of characters. They are enclosed in single quotes ('') or double (""). They can have any character or sign,
		including space in them. For example str = 'language'.
		</p>
		<h4>b) Lists</h4>
		<p>
		List is also a sequence of values of any type. Values in the list are called elements / items. List is enclosed in square brackets e.g.
		list = [ '2', 3 , 2.23, 'ram', 70.2 ].
		</p>
		<h4>c) Tuples</h4>
		<p>
		Tuples are a sequence of values of any type. Tuples are enclosed in () e.g. (4,2).
		</p>
		
		<h2>4. Sets </h2>
		<p>
		Set is an unordered collection of values, of any type, with no duplicate entry. For e.g. s = set ([1,2,34]).
		</p>
		
		<h2>5. Mappings</h2>
		<p>
		Mappings is unordered and mutable. Dictionaries fall under Mappings. Dictionaries store any number of python objects. They store data
		key - value pairs, which are accessed using key. Dictionary is enclosed in curly brackets. For e.g. 
		dict = {'name': 'ram','code':123, 'dept': 'hr'}.
		</p>
    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>