<?php 
    include("header.htm");
?>

<head>
    <title>Python Strings</title>
	<meta name="description" content="Python Strings" />
	<link rel="canonical" href="https://www.techblogss.com/python/python-strings" />
	<style>
		table, td, th {
		  border: 1px solid black;
		}
		th, td {
		  padding: 10px;
		  text-align: justify;
		}
	</style>
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Python Strings</h1>
	</div>
	<div id="solution">
		<p>
		In python, consecutive sequence of characters is known as a <b><i>string</b></i>. A character in a <b><i>string</b></i> can be accessed using index.
        You can declare a <b><i>string</b></i> in python as shown below
		</p>
		
<pre class="prettyprint">
>>>str = "sample"
>>>print (str)
sample
</pre> 
		
		<p>
		Since <b><i>string</b></i> is an array of characters, you can access a <b><i>string</b></i> character by index as shown below. Positive index will read 
        <b><i>string</b></i> from left while negative index will read <b><i>string</b></i> from right.
		</p>
		
<pre class="prettyprint">
>>>str = "sample"
>>>print (str[0])
s
>>>print (str[-2])
l
</pre> 

		<br>
		<h2>1) Creating and initializing strings</h2>
		<p>
			A literal/constant value to a string can be assigned using a single quotes, double quotes or triple quotes
		</p>
        
<pre class="prettyprint">
>>>str = "sample"
>>>print (str)
sample
>>>str = 'sample'
>>>print (str)
sample
</pre>
		
		<br>
        
        <p>
			You need to use triple quotes are used when the text is multiline
		</p>

<pre class="prettyprint">
>>>str = """this is a sample multiline string
this is a sample multiline string
this is a sample multiline string"""
>>>print (str)
this is a sample multiline string
this is a sample multiline string
this is a sample multiline string
</pre>
        <br>
		
		<h2>2) Escape Character</h2>
		<p>
			<b><i>Escape characters</b></i> are used to insert characters in a string that are illegal in a string.
            An <b><i>escape character</b></i> is a backslash \ followed by the character you want to insert. 
            For example to isert double quote inside a string, you need to add backslash \.
		</p>
<pre class="prettyprint">>>> print('this is a \"sample\" string')
this is a "sample" string
</pre>
        <br>
        <p>Below are some other <b><i>escape characters</b></i> used in Python:</p>
        <table>
			<tr>
				<th style="width:20%;">Escape character</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>\'</td>
				<td>Single Quote</td>
				<td>>>>print('hello \' there')<br>hello ' there</td>
		    </tr>
			<tr>
				<td>\\</td>
				<td>Backslash</td>
				<td>>>>print('hello \\ there')<br>hello \ there</td>
		    </tr>
			<tr>
				<td>\n</td>
				<td>New Line</td>
				<td>>>>print('hello \n there')<br>hello<br>there</td>
		    </tr>
			<tr>
				<td>\t</td>
				<td>Tab</td>
				<td>>>>print('hello \t there')<br>hello 	 there</td>
		    </tr>
		</table>   

        <br>
        <h2>3) User Input</h2>
		<p>
			String can also be created by <b><i>User Input</b></i> which means when we ask the user for input, whatever use eners will be converted to string.
            This is achieved by using <b><i>input()</b></i> method.
		</p>    

<pre class="prettyprint">>>>str=input("Enter the string")
Enter the string hello there
>>>print str
'hello there'
</pre>

        <br>
        <h2>4) Strings are immutable</h2>
		<p>
			Strings are immutable which means that the contents of the string cannot be modified/changed once it is created. For example below code will give error.
		</p> 

<pre class="prettyprint">>>>str='python'
>>>str[2]='i'
TypeError: 'str' object does not support item assignment
</pre>  

        <br>
        <h2>5) String Traversing</h2>
		<p>
			Strings in Python are arrays of bytes representing unicode characters. Python does not have a character data type, a single character in a string is 
            simply a string with a length of 1. Traversing a string means accessing all the elements of the string one after the other. A string can be traversed 
            using: for loop or while loop.
		</p> 

<pre class="prettyprint">>>>str='python'
>>>for i in A:
       print(i)
p
y
t
h
o
n       
</pre> 

<pre class="prettyprint">>>>str='python'
>>>while i &lt; len(str):
       print(str[i])
       i+=1
p
y
t
h
o
n       
</pre> 
		<br>

		<h2>6) String Operations</h2>
		<p>
			Below are the important Strings operations:
		</p>
		
		<table>
			<tr>
				<th style="width:20%;">Operator</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>+ (Concatenation)</td>
				<td>The + operator joins the text on both sides of the operator</td>
				<td>>>>'Hello'+'World'<br>'Hello World'</td>
		    </tr>
			<tr>
				<td>* (Repetition)</td>
				<td>The * operator repeats the string on the left hand side times the value on right hand side.</td>
				<td>>>>3*'Hello World'<br>'Hello World Hello World Hello World'</td>
		    </tr>
			<tr>
				<td>in (Membership)</td>
				<td>The operator displays 1 if the string contains the given character or the sequence of characters.</td>
				<td>>>>str='Hello World'<br>>>>'W' in str<br>True</td>
		    </tr>
			<tr>
				<td>not in</td>
				<td>The operator displays 1 if the string does not contain the given character or the sequence of characters.</td>
				<td>>>>str='Hello World'<br>>>>'WE' not in str<br>True</td>
		    </tr>
			<tr>
				<td>range(start, stop, step)</td>
				<td>returns a list of plain integers from start to stop. Step is the difference between numbers, default value of step is 1.</td>
				<td>>>>x = range(0, 12, 3)<br>>>>for n in x:<br>print(n)>>>0<br>3<br>6<br>9</td>
		    </tr>
			<tr>
				<td>Slice[n:m]</td>
				<td>The Slice[n : m] operator extracts sub parts from the strings.</td>
				<td>>>>str='Hello World'<br>>>>print str[1:3]<br>el</td>
		    </tr>
		</table>
		<br>
		
		<h3>Some more String slice operations</h3>
<pre class="prettyprint">>>>str='Hello World'
>>>print (str[3:])
lo World
		
>>>print (str[:3])
Hel		

>>>print (str[:])
Hello World

>>>print (str[-2:])
ld

>>>print (str[:-2])
Hello Wor
</pre> 
		<br>
		
		<h2>7) String built in methods</h2>
		<p>
			Below is the list of some of the String built in methods:
		</p>
		

		<table>
			<tr>
				<th style="width:20%;">Function</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>len()</td>
				<td>Returns the length of the string.</td>
				<td>>>>str = 'Hello World'<br>>>>print (len(str))<br>11</td>
		    </tr>
			<tr>
				<td>capitalize()</td>
				<td>Returns the exact copy of the string with the first letter in uppercase</td>
				<td>>>>str = 'hello World'<br>>>>print (str.capitalize())<br>Hello World</td>
		    </tr>
			<tr>
				<td>find(value, start, end)</td>
				<td>returns the first occurrence of the specified value, -1 if the value is not found. value is required while 
				start & end are optional</td>
				<td>>>>str = 'hello World'<br>>>>print (str.find('ello'))<br>1</td>
		    </tr>
			<tr>
				<td>isalnum()</td>
				<td>Returns True if the string contains only letters and digit, false if the string contains any special character
					like _ , @,#,* etc.</td>
				<td>>>>str = 'hello & World'<br>>>>print (str.isalnum())<br>False</td>
		    </tr>
			<tr>
				<td>isalpha()</td>
				<td>Returns True if the string contains only letters, else returns False.</td>
				<td>>>>str = 'helloWorld'<br>>>>print (str.isalpha())<br>True</td>
		    </tr>
			
		</table>
		<br>
		
		<p>To view complete list of String methods, view this page</p>
		<a href="https://docs.python.org/2.5/lib/string-methods.html" target="_blank">https://docs.python.org/2.5/lib/string-methods.html</a>
		
		<h2>8) Regular expressions and Pattern matching</h2>
		<p>
			A regular expression is a sequence of letters and some special characters called meta characters. The sequence created by using meta 
			characters and letters is used to represent a group of patterns. Also you need to import re module whch includes functions for 
			working on regular expression.
		</p>
		<p>
			For example if there is a string 'hello world' and we want to search if the string ends with 'ld'. We can do this by 
			searching for pattern 'ld$' where '$' is a meta character.
		</p>
<pre class="prettyprint">>>>str='hello world'
import re
>>>if (re.search('ld$',str)):
       print ('found string')
   else:
       print ('not found')

found string
>>>if (re.search('le$',str)):
       print ('found string')
   else:
       print ('not found')

not found
</pre> 	
		<br>
		<p>
			Below is the list of meta characters used to form regular expressions.:
		</p>

		<table>
			<tr>
				<th style="width:20%;">Meta Character</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>[]</td>
				<td>Used to match a set of characters</td>
				<td>[wor] The regular expression would match any of the characters w, o, or r</td>
		    </tr>
			<tr>
				<td>^</td>
				<td>Used to complement a set of characters</td>
				<td>[^wor] The regular expression would match any other character except w, o, or r</td>
		    </tr>
			<tr>
				<td>$</td>
				<td>Used to match the end of string</td>
				<td>ld$ regular expression would match any string ending with ld</td>
		    </tr>
			<tr>
				<td>*</td>
				<td>Used to specify that the previous character can be matched zero or more times</td>
				<td>wor* regular expression would match word, world, worworld</td>
		    </tr>
			<tr>
				<td>+</td>
				<td>Used to specify that the previous character can be matched one or more times</td>
				<td>wor+ regular expression would match world, worworld</td>
		    </tr>
			<tr>
				<td>?</td>
				<td>Used to specify that the previous character can be matched once or zero times</td>
				<td>wor? regular expression would match word , world but not worworld</td>
		    </tr>
			<tr>
				<td>{}</td>
				<td>The curly brackets accept two integer values. The first value specifies the minimum no of occurrences and second value
					specifies the maximum of occurrences</td>
				<td>wor{1,2} regular expression would match world, worworld</td>
		    </tr>
			
		</table>
		<br>
		
		<h2>9) re module functions</h2>
		<p>
			Below is the list of some of the <b><i>re module</b></i> functions.
		</p>
		
		<h3>a) re.compile() </h3>
		<p>The re.compile() function compiles the pattern to pattern objects which can access methods for various operations like searching
		and subsitutions.</p>
		
<pre class="prettyprint">>>>import re
>>>p=re.compile('hel*')
</pre> 		

		<h3>b) re.match() & re.group()</h3>
		<p>
			The match function() is used to determine if the regular expression matches at the beginning of the string while group() 
			function is used to return the string matched the regular expression.
		</p>	
    

<pre class="prettyprint">>>>import re
>>>p=re.compile('hel*')
>>>m=re.match('hel*', 'hello world')
>>>m.group()
hell
</pre>   

		<h3>c) re.start() & re.end()</h3>
		<p>
			The start function returns the starting position of the match while the end function returns the end position of the match.
		</p>

		<pre class="prettyprint">>>>import re
>>>p=re.compile('hel*')
>>>m=re.match('hel*', 'hello world')
>>>m.start()
0
>>>m.end()
4	</pre> 

		<h3>d) re.search()</h3>
		<p>
			The search function traverses through the string and determines the position where the regular expression matches the string.
		</p>
	
<pre class="prettyprint">>>>import re
>>>m=re.search('hel*', 'hello world')
>>>m.start()
0
>>>m.end()
4	</pre> 

	<p>To view complete list of re functions, view this page</p>
		<a href="https://docs.python.org/3/library/re.html" target="_blank">https://docs.python.org/3/library/re.html</a>
	
	</div>
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>