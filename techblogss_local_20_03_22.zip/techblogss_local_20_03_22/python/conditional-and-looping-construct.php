<?php 
    include("header.htm");
?>

<head>
    <title>Conditional and Looping Construct</title>
	<meta name="description" content="Conditional and Looping Construct" />
	<link rel="canonical" href="https://www.techblogss.com/python/conditional-and-looping-construct" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Conditional and Looping Construct</h1>
	</div>
	<div id="solution">
	
				
		<h2>Control Flow Structure</h2>
		<p>
		Sometimes you need to make decision while execution of the program which is based on some condition. The decision evaluates to boolean true or false based
        on which you proceed with the rest of the code execution. You can have following types of <b><i>Control Flow Structure</b></i>:
		</p>
        
        <h4>a) Simple if statement</h4>
        
<pre class="prettyprint">
>>> marks = 90
>>> if (marks > 80):
        print ('Student got grade A')
Student got grade A
        
>>> marks = 70
>>> if (marks > 80):
        print ('Student got grade A')        
</pre> 
		
		<h4>b) Single if elif statement</h4>
        
<pre class="prettyprint">
>>> marks = 80
>>> if (marks > 80):
        print ('Student got grade A')
    else:
        print ('Student got grade B') 
Student got grade B        
</pre>  

    
        <h4>c) Multilpe if elif statements</h4>
        
<pre class="prettyprint">
>>> marks = 50
>>> if (marks > 80):
        print ('Student got grade A')
    elif (marks > 60):
        print ('Student got grade B') 
    elif (marks > 40):
        print ('Student got grade C') 
    else:
        print ('Student got grade D') 
Student got grade C
</pre>  

        <h4>d) Nested if elif statements</h4>
        
<pre class="prettyprint">
>>> marks = 50
>>> if (marks > 50):
        if (marks > 80):
            print ('Student got grade A')
        elif (marks > 60):
            print ('Student got grade B') 
        elif (marks > 40):
            print ('Student got grade C') 
    else:
        print ('Student got grade D') 
Student got grade D
</pre> 

		<h2>Looping Constructs</h2>
		<p>
		Loops are used to execute the same code repeatedly in a program. Python provides two types of looping constructs:
		</p>
        
        <h3>a) While statement</h3>
        
<pre class="prettyprint">
>>> counter = 1
>>> while (counter &lt;=10):
        print (counter)
        counter = counter+1
1
2
3
4
5
6
7
8
9
10        
</pre>  

        <h4>Nested loops</h4>
        <p>You can also have nested loops in a while loop</p>
        
 <pre class="prettyprint">
 >>> i = 1
 >>> j = 1
while (i &lt;=5):
    print('i = ', i)
    i=i+1
    j=1
    while (j &lt;= i):
        print('j = ', j)	
        j = j +1
i =  1
j =  1
j =  2
i =  2
j =  1
j =  2
j =  3
i =  3
j =  1
j =  2
j =  3
j =  4
i =  4
j =  1
j =  2
j =  3
j =  4
j =  5
i =  5
j =  1
j =  2
j =  3
j =  4
j =  5
j =  6      
</pre>     
<br>
        <h3>b) For statement</h3>
        
<pre class="prettyprint">
>>> # loop to print value 1 to 3
    digits = [1,2,3]
    for digit in digits:
        print (digit)
1
2
3

>>> for letter in 'Python':
        print ('Current Letter :', letter)
Current Letter : P
Current Letter : y
Current Letter : t
Current Letter : h
Current Letter : o
Current Letter : n
</pre>  

        <h4>Break Statement</h4>
        <p>Suppose you want to break the for loop at some condition, you can use break keyword</p>
<pre class="prettyprint">
>>> for letter in 'Python':
        if letter == 'h':
            break
        print ('Current Letter :', letter)
Current Letter : P
Current Letter : y
Current Letter : t
</pre>        
    </div>
    
        <h4>Continue Statement</h4>
        <p>Suppose you want to skip procesing the code for some condition, you can use continue keyword</p>
<pre class="prettyprint">
>>> for letter in 'Python':
        if letter == 'h':
            continue
        print ('Current Letter :', letter)
Current Letter : P
Current Letter : y
Current Letter : t
Current Letter : o
Current Letter : n
</pre>        
    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>