<?php 
    include("header.htm");
?>

<head>
    <title>Python Operators</title>
	<meta name="description" content="Python Operators" />
	<link rel="canonical" href="https://www.techblogss.com/python/python-operators" />
	<style>
		table, td, th {
		  border: 1px solid black;
		}
		th, td {
		  padding: 10px;
		  text-align: center;
		}
	</style>
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Python Operators</h1>
	</div>
	<div id="solution">
		<p>
		<b><i>Operators</b></i> are special symbols used to perform operations on variables and values. Same operator can behave differently on
		different data types. <b><i>Operators</b></i> are categorized as <b><i>Arithmetic, Relational, Logical and Assignment</b></i>.
		Value and variables when used with operator are known as <b><i>operands</b></i>.
		</p>
		
		<p>
		Following is the list of <b><i>operators</b></i>:
		</p>
		
		<h2>1. Arithmetic Operators </h2>
		<table>
			<tr>
				<th style="width:20%;">Symbol</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>+</td>
				<td>Addition</td>
				<td>>>>15+45<br>60</td>
		    </tr>
			<tr>
				<td>-</td>
				<td>Subtraction</td>
				<td>>>>45-15<br>30</td>
		    </tr>
			<tr>
				<td>*</td>
				<td>Multiplication</td>
				<td>>>>15*45<br>675</td>
		    </tr>
			<tr>
				<td>/</td>
				<td>Division</td>
				<td>>>>15/5<br>3.0</td>
		    </tr>
			<tr>
				<td>%</td>
				<td>Remainder/Modulo</td>
				<td>>>>15%4<br>3</td>
		    </tr>
			<tr>
				<td>**</td>
				<td>Exponentiation</td>
				<td>>>>3**4<br>81</td>
		    </tr>
			<tr>
				<td>//</td>
				<td>Integer Division</td>
				<td>>>>5//2<br>2</td>
		    </tr>
		</table>
		
		<br>
		
		<h2>2. Relational Operators </h2>
		<table>
			<tr>
				<th style="width:20%;">Symbol</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td><</td>
				<td>Less than</td>
				<td>>>>5<7<br>True</td>
		    </tr>
			<tr>
				<td>></td>
				<td>Greater than</td>
				<td>>>>4>5<br>False</td>
		    </tr>
			<tr>
				<td><=</td>
				<td>Less than equal to</td>
				<td>>>>5<=6<br>True</td>
		    </tr>
			<tr>
				<td>>=</td>
				<td>Greater than equal to</td>
				<td>>>>4>=6<br>False</td>
		    </tr>
			<tr>
				<td>!=, <></td>
				<td>Not equal to</td>
				<td>>>>10!=12<br>True<br>>>>10<>2<br>True</td>
		    </tr>
			<tr>
				<td>==</td>
				<td>Equal to</td>
				<td>>>>10==12<br>False<br>>>>2==2<br>True</td>
		    </tr>
		</table>
		
		<br>
		
		<h2>3. Logical Operators </h2>
		<table>
			<tr>
				<th style="width:20%;">Symbol</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>or</td>
				<td>If any one of the operand is true, then the condition becomes true.</td>
				<td>>>>2 < 5 or 2 < 10<br>True</td>
		    </tr>
			<tr>
				<td>and</td>
				<td>If both the operands are true, then the condition becomes true.</td>
				<td>>>>2 > 5 and 2 < 10<br>False</td>
		    </tr>
			<tr>
				<td>not</td>
				<td>Reverse the result, returns False if the result is true.</td>
				<td>>>>not (2 < 5 and 2 < 10)<br>False</td>
		    </tr>
		</table>
		
		<br>
		
		<h2>4. Assignment Operators </h2>
		<table>
			<tr>
				<th style="width:20%;">Symbol</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>=</td>
				<td>Assign values from right side operands to left variable</td>
				<td>>>>x=45</td>
		    </tr>
			<tr>
				<td>+=</td>
				<td>Add and assign back the result to left operand</td>
				<td>>>>x+=20<br>x=10 will become 30</td>
		    </tr>
			<tr>
				<td>-=</td>
				<td>Subtract and assign back the result to left operand</td>
				<td>>>>x-=3<br>x=10 will become 7</td>
		    </tr>
			<tr>
				<td>*=</td>
				<td>Multiply and assign back the result to left operand</td>
				<td>>>>x*=5<br>x=10 will become 50</td>
		    </tr>
			<tr>
				<td>/=</td>
				<td>Divide and assign back the result to left operand</td>
				<td>>>>x/=5<br>x=10 will become 2</td>
		    </tr>
			<tr>
				<td>%=</td>
				<td>Get modulus and assign back the result to left operand</td>
				<td>>>>x%=5<br>x=34 will become 4</td>
		    </tr>
			<tr>
				<td>**=</td>
				<td>Performed exponential and assign back the result to left operand</td>
				<td>>>>x**=3<br>x=2 will become 8</td>
		    </tr>
			<tr>
				<td>//=</td>
				<td>Performed floor division and assign back the result to left operand</td>
				<td>>>>x//=2<br>x=12 will become 6</td>
		    </tr>
		</table>
    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>