    <?php include("../header.htm");?>

    <head>
        <title>Spring Boot REST API CRUD example</title>
        <meta name="description" content="Spring Boot REST API CRUD example, Spring Boot REST API example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-rest-api" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot REST API CRUD example</h1>
        </div>
        <div id="solution">
            <p>
            <code>CRUD</code> stands for Create, Read, Update and Delete operations on backend. This example shows how to build a 
            User <code>CRUD</code> application using <b><i>Spring Boot REST API</b></i>. It will expose <code>REST</code> endpoints for performing 
            <code>CRUD</code> operations in a User repository. For backend we will use HashMap instead of using actual database. 
            </p> 
        </div>
        
        <h4>Step 1) Create pom.xml</h4>
        <p style="text-align:justify;">In the pom.xml add <b><i>spring-boot-starter-web</b></i> dependency</p>
        
        <div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
&lt;/dependency&gt;           </pre></div>
        <br>

        <div id="1">
        <h4>Step 2) Create User POJO class which contains a user details</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class User {

    private String id;
    private String firstName;
    private String lastName;
    private int age;
    
    // removed constructor, getter and setter for brevity

}    </pre></div><br>
        </div>
    
        <h4>Step 3) Create UserService interface which contains CRUD operations and will be used by UserController</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Collection;
import java.util.Optional;

public interface UserService {

    Collection&lt;User> getAll();
    User create(User user);
    Optional&lt;User> get(String id);
    void delete(String id);
}    </pre></div><br>

        <h4>Step 4) Create UserServiceImpl class that will implement UserService. Instead of calling DAO, it will simple return the user details
using a Collection.</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    
    private final Map&lt;String, User&gt; users =  new ConcurrentHashMap&lt;>();

    @Override
    public Collection&lt;User&gt;  getAll() {
        return users.values();
    }

    @Override
    public User create(User user) {
        users.put(user.getId(), user);
        return user;
    }

    @Override
    public Optional&lt;User&gt; get(String id) {
        return Optional.ofNullable(users.get(id));
    }
    
    @Override
    public void delete(String id) {
        users.remove(id);
    }
    
}    </div> </pre>    
<br>    
    
        <h4>Step 5) Create UserController class which will expose REST API for CRUD operations and expose User as a REST resource.</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;
import java.util.Collection;
import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping()
    public Collection&lt;User&gt; getAllUsers() {
        return userService.getAll();
    }
    
    @GetMapping("/{id}")
    public Optional&lt;User&gt; get(@PathVariable("id") String id) {
        return userService.get(id);
    }
    
    @PostMapping()
    public User create(@RequestBody User user) {
        return userService.create(user);
    }
    
    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        userService.delete(id);
    }
}      </div></pre><br>
        
        <h4>Step 6) Create UserApplication class</h4>
        <p>When run, Application class will start the embedded Tomcat server and will have a preconfigured Spring MVC setup.</p>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class UserApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }
    
    @Bean
    public ApplicationRunner userInitializer(UserService userService) {
        return args -> {
            userService.create(new User("ironman", "Robert", "Downey", 45));
            userService.create(new User("batman", "Christian", "Bale", 36));
            userService.create(new User("superman", "Henry", "Cavill", 28));
        };
    }
}        </div>
        </pre>
        <br>
             
        <div id="solution">
            <h4>Console Output : </h4>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2019-11-15 20:58:56.653  INFO 3584 --- [main] com.example.demo.UserApplication         : Started UserApplication in 3.092 seconds (JVM running for 3.533)
2019-11-15 20:58:59.569  INFO 3584 --- [nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring DispatcherServlet 'dispatcherServlet'
2019-11-15 20:58:59.569  INFO 3584 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet  : Initializing Servlet 'dispatcherServlet'
2019-11-15 20:58:59.581  INFO 3584 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet  : Completed initialization in 11 ms
         </pre></div><br>        
       

     <h4>Step 7) Testing UserApplication </h4>
     <p>Open any browser and launch <b>http://localhost:8080/users</b>. You will see list of users displayed in the broswer.</p>
     
        <div>
            <p><img src="../images/springboot/sb_rest-api_1.jpg" alt="Users" style="width:500px;height:500px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
     </p>
     <p>If you want to see details of a particular user, you need to pass user id in url as shown below</p>
        
         <div>
            <p><img src="../images/springboot/sb_rest-api_2.jpg" alt="User Details" style="width:500px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br>
        
        <p>If you want to add a user, then you need to send a <code>POST</code> request as below</p>
        
         <div>
            <p><img src="../images/springboot/sb_rest-api-post.png" alt="User Details" style="width:500px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br>

        <p>If you want to delete a user, then you need to send a <code>DELETE</code> request as below or send using POSTMAN</p>  

        <div id="code">
        <pre class="prettyprint">curl -X DELETE http://localhost:8080/users/ironman </pre></div>  <br><br>
        
        References : <br><br>
        <a href="https://spring.io/guides/gs/rest-service/">Spring Boot Building RESTFul Web Service</a>    <br><br>
        
        </div> <!-- blog div-->
        
        <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->    
        
        <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
        <?php include("share.htm"); ?>
    </body>

    <?php include("footer.htm");?>
    </html>