    <?php include("../header.htm");?>

    <head>
        <title>Spring Boot Micrometer Prometheus example</title>
        <meta name="description" content="Spring Boot Micrometer Prometheus example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-micrometer-prometheus" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
    <div id="content">
    <div id="blog">
        <div id="problem">
            <h1>Spring Boot Micrometer Prometheus example</h1>
        </div>
        <div id="solution">
            <p>
            <code>Spring Boot Actuator</code> offers basic metrics but <code>Micrometer</code> provides a way to collect the metrics, acts as a
            facade for these metrics and intergate them with any other third party system like <code>Prometheus, Netfloix Atlas</code> for monitoring. 
            You can also write custom metrics using <code>Micrometer</code>.
            </p>
            <p>
            <code>Prometheus</code> is a time-series metrics monitoring tool. In this example we will use the actuator metrics to be collected from
            <code>Micrometer</code> and then use <code>Prometheus</code> to read the metrics and create graph to monitor the application health.
            </p>    
        </div>
        
        <h4>Step 1) Add below dependencies to pom.xml</h4>
         <div id="code">
        <pre class="prettyprint">
&lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-actuator&lt;/artifactId>
    &lt;/dependency>

    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
    &lt;/dependency>

    &lt;!-- Micrometer Prometheus registry -->
    &lt;dependency>
        &lt;groupId>io.micrometer&lt;/groupId>
        &lt;artifactId>micrometer-registry-prometheus&lt;/artifactId>
    &lt;/dependency>

&lt;/dependencies>        </pre></div><br>

        <h4>Step 2) Create Player, PlayerController, PlayerService PlayerApplication classes</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class Player {

    private String id;
    private String firstName;
    private String lastName;

    public Player() {
    }

    public Player(String id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    //removed getter & setter

    @Override
    public String toString() {
        return "Player [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }

}      </div></pre><br>

        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class PlayerApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlayerApplication.class, args);
    }
    
    @Bean
    public ApplicationRunner playerInitializer(PlayerService playerService) {
        return args -> {
            playerService.create(new Player("leo", "Leonardo ", "Messi"));
            playerService.create(new Player("cristi", "Cristiano", "Ronaldo"));
            playerService.create(new Player("diego", "Diego", "Maradona"));
        };
    }
}       </div></pre><br>

        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/players")
public class PlayerController {

    @Autowired
    private PlayerService playerService;
    private static Logger logger = LoggerFactory.getLogger(PlayerController.class);

    @GetMapping("/{id}")
    public Player get(@PathVariable("id") String id) throws Exception {
        logger.info("getting player");
        return playerService.get(id);
    }

}    </div></pre><br>

        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PlayerService {

    private static Logger logger = LoggerFactory.getLogger(PlayerService.class);
    private Map&lt;String, Player> players = new HashMap<>();

    public Player get(String id) {
        logger.info("getting player");
        return players.get(id);
    }

    public void create(Player player) {
        players.put(player.getId(), player);
    }
}    </div></pre><br>

    <h4>Step 3) Expose prometheus as actuator endpoint in application.properties file as shown below</h4>

    <div id="code">
    <pre class="prettyprint">
logging.level.root=INFO
management.endpoints.web.exposure.include=health,info,prometheus </div></pre><br>

    <h4>Step 4) Launch PlayerApplication</h4>
    <div>
        After PlayerApplication starts, hit <a href="http://localhost:8080/players/leo" target="_blank">http://localhost:8080/players/leo</a>
        few times and then launch <a href="http://localhost:8080/actuator/prometheus" target="_blank">
        http://localhost:8080/actuator/prometheus</a> to see metrics exposed on the prometheus actuator endpoint.
        Observe that <code>http_server_requests_seconds_count</code> keeps increasing as you keep hitting the players endpoint.
    </div>
    
    <div>
    <p>
        <img src="../images/springboot/sb_actuator_prometheus.jpg" alt="Micrometer Prometheus" title="Micrometer Prometheus">
    </p>
        
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>

    <h4>Step 5) Checking metrics in <code>Prometheus</code></h4>
    <p>
    To check any metrics <code>Prometheus</code>, we will install <code>Prometheus</code> server where we can see the stats graphically.
    </p> 
    <div>
    You can download <code>Prometheus</code> from this link <a href="https://prometheus.io/download/" target="_blank">
    https://prometheus.io/download/</a>
    </div>
    <p>Go to the <code>Prometheus</code> installation directoy and open <code>prometheus.yml</code> file. Here you need to specify the actuator path 
    and the local server address as shown below.
    </p>
    
    <div id="code">
    <pre class="prettyprint">
scrape_configs:
  # The job name is added as a label `job=<job_name>` to any timeseries scraped from this config.
  - job_name: "prometheus"

    # metrics_path defaults to '/metrics'
    # scheme defaults to 'http'.

    static_configs:
      - targets: ["localhost:9090"]
      
  - job_name: 'spring-actuator'
    metrics_path: '/actuator/prometheus'
    scrape_interval: 5s
    static_configs:
      - targets: ["localhost:8080"]</pre></div><br>        
       
    <h4>Step 6) Launch <code>Prometheus</code> server </h4>
    <div>
    Launch <code>Prometheus</code> server by clicking prometheus.exe and then launch <a href="http://localhost:9090" target="_blank">
    http://localhost:9090</a>.
    </div>
    <div>You can check if the metrics published by actuator is received by  <code>prometheus</code> server or not using this link
    <a href="http://localhost:9090" target="_blank">http://localhost:9090</a>.
    </div>
    <p>Search for any metrics like <code>http_server_requests_seconds_count</code> and you will see the stats plotted as graph.</p>
    
    <div>
    <p>
        <img src="../images/springboot/sb_actuator_prometheus_2.jpg" alt="Micrometer Prometheus" title="Micrometer Prometheus">
    </p>
        
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
   <div id="content">
       <?php include '../blogs/entry.php';?>
   </div>
        
   <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>