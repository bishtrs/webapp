    <?php include("../header.htm");?>

    <head>
        <title>Spring Boot WebFlux example</title>
        <meta name="description" content="Spring Boot WebFlux" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-webflux" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot WebFlux example</h1>
        </div>
        <div id="solution">
            <p><b><i>Spring WebFlux</b></i> which is a reactive-stack web framework, is fully non-blocking, supports Reactive Streams back pressure, and runs on such servers as Netty, Undertow, and Servlet 3.1+ containers.</p>
            <p>The term, <b><i>"reactive"</b></i>, refers to programming models that are built around reacting to change like network components reacting to I/O events, UI controllers reacting to mouse events, etc. So non-blocking is reactive, because instead of being blocked, we are in the mode of reacting to notifications as operations complete or data becomes available.</p>
            <p>This example shows how to develop a simple reactive <b><i>Spring Boot WebFlux</b></i> application.</p> 
        </div>
        
        <h4>Step 1) Create pom.xml</h4>
        Add <b><i>spring-boot-starter-web</b></i> and <b><i>spring-boot-starter-webflux</b></i> to pom.xml file.
        <div id="code">
        <pre class="prettyprint">
    &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;	

    &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-webflux&lt;/artifactId&gt;
    &lt;/dependency&gt;	       </pre>
        </div>
        <br>
        
        <h4>Step 2) Create WebFluxApplication class</h4>
         <p>When run, WebFluxApplication class will start the embedded Tomcat server and will have a preconfigured Spring MVC setup.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebFluxApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebFluxApplication.class, args);
    }
		
}        </div>
        </pre>
        <br>
    <h4>Step 3) Create WebFluxController class</h4>
    <p>Note that Flux<lt;String> is a return type, instead of plain String. <b><i>Flux</b></i> makes it reactive. If you want streaming response, you need to set <b><i>produces = MediaType.TEXT_EVENT_STREAM_VALUE</b></i></p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;

@RestController
public class WebFluxController {
	
    @Autowired
    private QuotesService quotesService;
	
    @GetMapping(value = "/quotes", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux&lt;Quote> list() {
       return quotesService.quotes();
    }
   
}      </div></pre>	
        <br>
        
        <h4>Step 4) Create Quote, QutesServiceImpl classes</h4>
         <p>When run, WebFluxApplication class will start the embedded Tomcat server and will have a preconfigured Spring MVC setup.</p>
         
         <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class Quote {

    private long id;
    private String stock;
    private String type;
    private long currentPrice;
        
    public Quote(long id, String stock, String type, long currentPrice) {
        this.id = id;
        this.stock = stock;
        this.type = type;
        this.currentPrice = currentPrice;
    }

    public long getId() {
        return id;
    }

    public String getStock() {
        return stock;
    }

    public String getType() {
        return type;
    }

    public long getCurrentPrice() {
        return currentPrice;
    }

    @Override
    public String toString() {
        return "Quote [id=" + id + ", stock=" + stock + ", type=" + type
                + ", currentPrice=" + currentPrice + "]";
    }
	
}        </div></pre>

        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import reactor.core.publisher.Flux;

public interface QuotesService {

    Flux&lt;Quote> quotes();

}        </div>
        </pre>
        
<div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;

@Service
public class QutesServiceImpl implements QuotesService {
	
    private final Collection&lt;Quote> quotes =  new ArrayList<>();
    
    public QutesServiceImpl() {
    	quotes.add(new Quote(123, "Microsoft", "BUY" , 100));
    	quotes.add(new Quote(124, "Microsoft", "BUY" , 101));
    	quotes.add(new Quote(125, "Microsoft", "BUY" , 102));
    	quotes.add(new Quote(126, "Microsoft", "BUY" , 103));
    	quotes.add(new Quote(127, "Microsoft", "BUY" , 104));
    	quotes.add(new Quote(128, "Microsoft", "BUY" , 105));
    	quotes.add(new Quote(129, "Microsoft", "BUY" , 106));
    }

    @Override
    public Flux&lt;Quote> quotes() {
        return Flux.fromIterable(quotes).delayElements(Duration.ofMillis(500));
    }

	
}
        </div>
        </pre>        
        <br>
        
        
        <h4>Directory structure</h4>        
        <div>
            <p><img src="../images/sb_webflux_1.jpg" alt="Directory structure" style="width:400px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br>
        
        <div>
    	       <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    </div>
 
        <h4>Step 5) Run WebFluxApplication</h4>
    <div id="solution">
            <h4>Console Output : </h4>
        </div>
        
        <div id="code">
        <pre class="prettyprint"> 
2019-12-07 12:42:40.765  INFO 4044 --- [main] com.example.demo.WebFluxApplication      : Starting WebFluxApplication on ssss-PC with PID 4044 (C:\Dev\eclipse\workspace\SpringBoot\target\classes started by sss in C:\Dev\eclipse\workspace\SpringBoot)
2019-12-07 12:42:40.769  INFO 4044 --- [main] com.example.demo.WebFluxApplication      : No active profile set, falling back to default profiles: default
2019-12-07 12:42:42.681  INFO 4044 --- [main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.21]
2019-12-07 12:42:42.839  INFO 4044 --- [main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2019-12-07 12:42:42.839  INFO 4044 --- [main] o.s.web.context.ContextLoader            : Root WebApplicationContext: initialization completed in 1961 ms
2019-12-07 12:42:43.395  INFO 4044 --- [main] o.s.s.concurrent.ThreadPoolTaskExecutor  : Initializing ExecutorService 'applicationTaskExecutor'
2019-12-07 12:42:43.909  INFO 4044 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2019-12-07 12:42:43.913  INFO 4044 --- [main] com.example.demo.WebFluxApplication      : Started WebFluxApplication in 3.746 seconds (JVM running for 4.29)   </pre>
        </div>		
 
     <h4>Step 6) Testing WebFluxApplication </h4>
     <p>Open any browser and launch <b>http://localhost:8080/quotes</b>. You will see streaming quotes displayed in the broswer.</p><br> 
     
        <div>
            <p><img src="../images/sb_webflux_3.jpg" alt="Web Flux" style="width:500px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br>
        
        <div>
            <p><img src="../images/sb_webflux_2.jpg" alt="Web Flux" style="width:500px;height:400px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
       
    <br>
	<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
        
    References : <br><br>
    <a href="https://docs.spring.io/spring/docs/current/spring-framework-reference/web-reactive.html">Spring WebFlux</a>	<br><br>
        </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>