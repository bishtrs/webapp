<?php include("../header.htm");?>

<head>
    <title>Spring Boot Security REST API Basic authentication</title>
    <meta name="description" content="Spring Boot Security REST API Basic authentication " />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-basic-authentication" />
</head>

<body>
    <?php include("../navigation.htm");?>
        
    <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Security REST API Basic authentication</h1>
        </div>
        <div id="solution">
            <p>
            To protect a <code>REST API</code> being invoked by any unwanted users, you need to have a security mechanism like 
            <code>BASIC authenciation</code>. This tutorial explains how to secure a <code>REST API</code> with <code>Basic Authentication</code> using Spring 
            Boot security. We will use in-memory authentication configuration which means we will keep user credentials to verify in the memory.
            </p> 
        </div>
        
        <h4>Step 1) Create pom.xml</h4>
        <p>In the pom.xml add below dependencies</p>
        
        <div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
&lt;/dependency&gt;           </pre></div>
<div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-security&lt;/artifactId&gt;
&lt;/dependency&gt;           </pre></div>
        <br>

        <div id="1">
        <h4>Step 2) Create Novel POJO class which contains a Novel details</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class Novel {

    private String title;
	private String author;
    
    // removed constructor, getter and setter for brevity

}    </pre></div><br>
        </div>
    
        <h4>Step 3) Create NovelRestController class which exposes /novels GET API</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NovelRestController {
	
    List&lt;Novel> novels = new ArrayList&lt;>();
        
    public NovelRestController() {
    	novels.add(new Novel("The Fountainhead", "Ayn Rand"));
    	novels.add(new Novel("Murder on the Orient Express", "Agatha Christie"));
    }

    @GetMapping("/novels") 
    public List&lt;Novel> getNovels() {
        return novels;
    }
}  </pre></div><br>

        <h4>Step 4) Create NovelApplication class</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
@EnableWebSecurity
public class NovelApplication {

    public static void main(String[] args) {
        SpringApplication.run(NovelApplication.class, args);
    }
} </div></pre><br>    
    
        <h4>Step 5) Create CustomerSecurityConfig class which is used to configure security for the REST API.</h4>
        <div id="solution">
        <p>
        To enable basic authentication in the <code>REST API</code>, we need to override <code>WebSecurityConfigurerAdapter</code>. When a user submits user
        and password, <code>BasicAuthenticationFilter</code> creates a <code>UsernamePasswordAuthenticationToken</code> by extracting user/password from
        <code>HttpServletRequest</code>, <code>UsernamePasswordAuthenticationToken</code> is then authenciated by <code>AuthenticationManager</code>. 
        If authentication is successful, <code>BasicAuthenticationFilter</code> invokes FilterChain.dofilter to continue the flow.
        </p>
        <p>
        In configure method, we will enable http basic authenciation using <code>httpBasic()</code> call. Also csrf is disabled 
        using <code>csrf()</code> call.
        </p>
        </div>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class CustomerSecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable().authorizeRequests().anyRequest().authenticated().and().httpBasic();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication().withUser("user").password("{noop}password").roles("USER");
    }
	
    // The {noop} in the password field means that encryption has not been applied to the stored password

}      </div></pre><br>
       

     <h4>Step 7) Testing REST API Basic Authentication</h4>
     <p>
     Open any browser and launch <b>http://localhost:8080/novels</b>. You will get a login pop to enter user credentials.
     Enter the user, password as user & password, you will see list of novels. You can also post the request using POSTMAN.
     </p>
        <div id="largeimg">
            <p><img src="../images/springboot/basic.jpg" alt="basic" style="width:800px;height:200px;"></p>
        </div>
        <div id="smallimg">
            <p><img src="../images/springboot/basic.jpg" alt="basic" style="width:400px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br>
        <div id="largeimg">
            <p><img src="../images/springboot/basic2.jpg" alt="basic" style="width:600px;height:400px;"></p>
        </div>
        <div id="smallimg">
            <p><img src="../images/springboot/basic2.jpg" alt="basic" style="width:300px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <div id="largeimg">
            <p><img src="../images/springboot/basic3.jpg" alt="basic" style="width:800px;height:400px;"></p>
        </div>
        <div id="smallimg">
            <p><img src="../images/springboot/basic2.jpg" alt="basic" style="width:300px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
     
        
        References : <br><br>
        <a href="https://docs.spring.io/spring-security/reference/servlet/architecture.html">Spring Security Architecture</a>    <br><br>
        <a href="https://docs.spring.io/spring-security/reference/index.html">Spring Security</a>    <br><br>
        
        
        </div> <!-- blog div-->
        
        <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->    
        
        <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
        <?php include("share.htm"); ?>
    </body>

    <?php include("footer.htm");?>
    </html>