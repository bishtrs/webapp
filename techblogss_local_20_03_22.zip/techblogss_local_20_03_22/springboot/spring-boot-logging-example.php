    <?php include("../header.htm"); ?>

    <head>
        <title>Spring Boot Logging Logback SLF4J </title>
        <meta name="description" content="spring boot logging example, Logging in spring boot, spring boot debug logging, spring boot logging configuration, spring boot Logback example, spring boot logging SLF4J" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-logging-example" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
    <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Logging with Logback SLF4J </h1>
        </div>
        <div id="solution">
            <p>
            <b><i>Spring Boot</b></i> uses <code>commons-logging</code> for its internal logging & uses <b><i>SLF4J</b></i> as logging API but supports configuration for <b><i>Logback, Log4j2</b></i> and <b><i>Java Util</b></i> logging frameworks. By default <b><i>Spring Boot</b></i> uses <b><i>Logback</b></i> for logging. This <b><i>Spring Boot</b></i> logging example shows how to configure log levels in a <b><i>Spring Boot</b></i> application.
            </p> 
        </div>
        
         <h4>Step 1) Create application.properties file (under src/main/resources ) to set logging level. Note that root level logging level is 
         the default logging level.
         </h4>
        <div id="code">
        <pre class="prettyprint">
logging.level.root=INFO
logging.level.com.example.demo=INFO
logging.level.org.springframework.web=INFO        </div></pre><br>

    <div>
        <p><img src="../images/sb_logging.jpg" alt="Maven Build" style="width:400px;height:200px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br>
    
        <h4>Step 2) Create SpringBootLoggingExample class</h4>
        <p>We will use <code>SLF4J</code> logging API to log the messages, so that we can switch to any logging framework like logback or log4j2 without any code changes. When run, SpringBootLoggingExample class will print logs with the level set in application.properties file.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLoggingExample {
	
    private static Logger logger = LoggerFactory.getLogger(SpringBootLoggingExample.class);

    public static void main(String[] args) {
        SpringApplication.run(SpringBootLoggingExample.class, args);
        logger.trace("Spring Boot app started");
        logger.warn("Spring Boot app started");
        logger.info("Spring Boot Logging Example");
        logger.debug("Spring Boot app starting");    }
}        </div></pre><br>

        
        <h4>Step 3) Running SpringBootLoggingExample</h4>
       <p>To Run this Spring Boot application from command prompt, use following command &rarr; <b>java -jar demo-0.0.1-SNAPSHOT.jar</b></p>
       <div id="solution">
            <h4>Output : </h4>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2021-02-02 13:23:02.317  INFO 9304 --- [main] c.example.demo.SpringBootLoggingExample  : Started SpringBootLoggingExample in 1.601 seconds (JVM running for 2.34)
2021-02-02 13:23:02.320  WARN 9304 --- [main] c.example.demo.SpringBootLoggingExample  : Spring Boot app started
2021-02-02 13:23:02.321  INFO 9304 --- [main] c.example.demo.SpringBootLoggingExample  : Spring Boot Logging Example
</pre></div><br>        
 
   	       <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?> 
    
       <h4>Step 4) Change logging level in application.properties to DEBUG and rerun the application. </h4>
         <p>You can play with the root level logging as per your logging requirements. Try to change it to 
         <b><i>ERROR, WARN, INFO, DEBUG</b></i> and see the output.</p>
        <div id="code">
        <pre class="prettyprint">
logging.level.root=INFO
logging.level.com.example.demo=DEBUG
logging.level.org.springframework.web=INFO</div></pre>
        
        
<div id="solution">
        <h4>Output : </h4>
        </div>
 <div id="code">
            <pre class="prettyprint">
2021-02-02 13:24:57.373  INFO 16084 --- [main] c.example.demo.SpringBootLoggingExample  : No active profile set, falling back to default profiles: default
2021-02-02 13:24:58.248  INFO 16084 --- [main] c.example.demo.SpringBootLoggingExample  : Started SpringBootLoggingExample in 1.421 seconds (JVM running for 2.121)
2021-02-02 13:24:58.253  WARN 16084 --- [main] c.example.demo.SpringBootLoggingExample  : Spring Boot app started
2021-02-02 13:24:58.254  INFO 16084 --- [main] c.example.demo.SpringBootLoggingExample  : Spring Boot Logging Example
2021-02-02 13:24:58.255 DEBUG 16084 --- [main] c.example.demo.SpringBootLoggingExample  : Spring Boot app starting </pre></div><br>
        
     <h4>Step 5) In case you want to write the logs to a file, then you need to change application.properties as shown below</h4>
        <div id="code">
        <pre class="prettyprint">
logging.level.root=INFO
logging.level.com.example.demo=INFO
logging.level.org.springframework.web=INFO        
logging.file=application.log
logging.path=/tmp/log        </div></pre><br>
    
    <div id="solution">    
    <h2>Using logback-spring.xml to configure logging</h2>
    <p>You can use <code>application.properties</code> for basic configuration, but if you want advanced logging configuration, then you need to create a <code>logback-spring.xml</code> file. Using xml file you can specify whether you want to log to console or a file by providing the appropriate <code>appender</code>. You can also specify the log pattern using <code>pattern</code> and can set the log level.<br>
    Create logback-spring.xml file (under src/main/resources) to set advanced logging configuration for production enviornment.</p>
    To know details of log patterns you can visit this page <a href="http://logback.qos.ch/manual/layouts.html" target="_blank">Logback layouts</a>
    </div>
         
    <div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;configuration&gt;

    &lt;property name="HOME_LOG" value="logs/app.log"/&gt;

    &lt;appender name="FILE-ROLLING" class="ch.qos.logback.core.rolling.RollingFileAppender"&gt;
        &lt;file&gt;${HOME_LOG}&lt;/file&gt;

        &lt;rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy"&gt;
            &lt;fileNamePattern&gt;logs/archived/app.%d{yyyy-MM-dd}.%i.log&lt;/fileNamePattern&gt;
            &lt;maxFileSize&gt;10MB&lt;/maxFileSize&gt;
            &lt;totalSizeCap&gt;10GB&lt;/totalSizeCap&gt;
            &lt;maxHistory&gt;30&lt;/maxHistory&gt;
        &lt;/rollingPolicy&gt;

        &lt;encoder&gt;
            &lt;pattern&gt;%d [%thread] %-5level %logger{36} - %msg%n&lt;/pattern&gt;
        &lt;/encoder&gt;
    &lt;/appender&gt;

    &lt;logger name="com.example.demo" level="debug" additivity="false"&gt;
        &lt;appender-ref ref="FILE-ROLLING"/&gt;
    &lt;/logger&gt;

    &lt;root level="error"&gt;
        &lt;appender-ref ref="FILE-ROLLING"/&gt;
    &lt;/root&gt;

&lt;/configuration&gt;        </div></pre><br>

    <div id="solution">
        <h4>Log file Output (see app.log unders logs directory): </h4>
    </div>    
        
    <div id="code">
        <pre class="prettyprint">
2019-10-27 16:23:41,954 [main] INFO  c.e.demo.SpringBootLogbackExample - Starting SpringBootLogbackExample on ssss-PC with PID 5580 (C:\Dev\eclipse\workspace\SpringBoot\target\classes started by sss in C:\Dev\eclipse\workspace\SpringBoot)
2019-10-27 16:23:41,956 [main] INFO  c.e.demo.SpringBootLogbackExample - No active profile set, falling back to default profiles: default
2019-10-27 16:23:43,597 [main] INFO  o.s.b.w.e.tomcat.TomcatWebServer - Tomcat initialized with port(s): 8080 (http)
2019-10-27 16:23:43,622 [main] INFO  o.a.coyote.http11.Http11NioProtocol - Initializing ProtocolHandler ["http-nio-8080"]
2019-10-27 16:23:43,640 [main] INFO  o.a.catalina.core.StandardService - Starting service [Tomcat]
2019-10-27 16:23:43,640 [main] INFO  o.a.catalina.core.StandardEngine - Starting Servlet engine: [Apache Tomcat/9.0.21]
2019-10-27 16:23:43,783 [main] INFO  o.a.c.c.C.[Tomcat].[localhost].[/] - Initializing Spring embedded WebApplicationContext
2019-10-27 16:23:43,784 [main] INFO  o.s.web.context.ContextLoader - Root WebApplicationContext: initialization completed in 1759 ms
2019-10-27 16:23:44,107 [main] INFO  o.s.s.c.ThreadPoolTaskExecutor - Initializing ExecutorService 'applicationTaskExecutor'
2019-10-27 16:23:44,359 [main] INFO  o.a.coyote.http11.Http11NioProtocol - Starting ProtocolHandler ["http-nio-8080"]
2019-10-27 16:23:44,392 [main] INFO  o.s.b.w.e.tomcat.TomcatWebServer - Tomcat started on port(s): 8080 (http) with context path ''
2019-10-27 16:23:44,396 [main] INFO  c.e.demo.SpringBootLogbackExample - Started SpringBootLogbackExample in 3.22 seconds (JVM running for 3.707)
         </pre></div><br>		
   
    
    <h2>Using another logging provider</h2>
    <div id="solution">
    <p>Bu default, <b><i>Spring Boot</b></i> uses <b><i>Logback</b></i> as logging provider. You can also use another logging provider like <b><i>Log4J2</b></i> or <b><i>Java Util Logging</b></i>. To use another logging provider, you first need to exclude <b><i>spring-boot-starter-logger</b></i> maven dependency which is provided as default by <b><i>Spring Boot</b></i> framework. After that you need to add the requied dependency like <b><i>spring-boot-starter-log4j2</b></i>.
    Since we use <b><i>SLF4J</b></i> as logging API, it will automatically pick up <b><i>Log4J2</b></i> as logging provider as shown in below code.
    </p>
           
    </div>
    
    <div id="code"><pre class="prettyprint">private static Logger logger = LoggerFactory.getLogger(SpringBootLoggingExample.class);</pre></div>
    
    <div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
    &lt;exclusions&gt;
        &lt;exclusion&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-logging&lt;/artifactId&gt;
        &lt;/exclusion&gt;
    &lt;/exclusions&gt;
&lt;/dependency&gt;		
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-log4j2&lt;/artifactId&gt;
&lt;/dependency&gt;		</pre></div> <br>
		
	<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
        
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>