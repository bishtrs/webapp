<?php header_remove("X-Powered-By"); ?>
<?php include("../header.htm"); ?>



