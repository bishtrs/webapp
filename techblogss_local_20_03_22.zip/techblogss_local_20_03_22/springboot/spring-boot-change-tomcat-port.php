<?php include 'header.php';?>

<head>
    <title>Spring Boot Change Tomcat Port</title>
    <meta name="description" content="This tutorial explains how to change Tomcat Port in Spring Boot" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-change-tomcat-port" />
</head>

<body>
    <?php 
        include("navigation.htm");
    ?>
        
    <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Change Tomcat Port in a Spring Boot application</h1>
        </div>
        <div id="solution">
            <h2>
            By default Spring Boot uses Tomcat as the container and runs the server on 8080 port. However you can change the Tomcat 
            port in following ways:
            </h2> 
            
        </div><br>
        
        <h3>1) Change port by specifying the port in application.properties or application.yml file using server.port property.</h3>
        <h4>application.properties file</h4>
        <div id="code">
        <pre class="prettyprint">
server.port=8090       </pre>  </div>
        
        <h4>application.yml file</h4>
        <div id="code">
        <pre class="prettyprint">
server:
    port : 8090       </pre>     </div>
        <br>
         
         <h3>2) Change port using command line argument</h3>
         
        <div id="code">
        <pre class="prettyprint">
java -Dserver.port=8090 -jar yourapplication.jar         </div>        </pre>
        <br>
        
    <h3>3) Change port by implementing EmbeddedServletContainerCustomizer interface </h3>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.stereotype.Component;
 
@Component
public class WebServerFactoryCustomizerImpl implements WebServerFactoryCustomizer&lt;ConfigurableServletWebServerFactory&gt; {
 
    @Override
    public void customize(ConfigurableServletWebServerFactory server) {
        server.setPort(8090); // change tomcat port
    }
 
}       </div>
        </pre>	
        <br>
 
        
    References : <br><br>
    <a href="https://docs.spring.io/spring-boot/docs/current/reference/html/howto.html#howto-change-the-http-port">Spring Boot Docs how to change the http port</a>	<br><br>
       </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>