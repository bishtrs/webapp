<?php 
    include("header.htm");
?>

<head>
    <title>Spring Boot externalize properties</title>
	<meta name="description" content="Spring Boot externalize properties" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/sb_externalize" />
    <!--<script src="clipboard.min.js"></script>-->
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Spring Boot externalize properties</h1>
	</div>
    <div>
        <p>By default Spring Boot will load a file named <b><i>application.properties</b></i> (typically under src/main/resources)</p>
    </div>
    
	<div id="solution">
        <h3>1) The example shows how to keep application configuration in properties file packaged inside the application and use it in Spring Boot application.</h3> 
	</div>
    
    <h4>Step 1)</h4>
    Create a pom.xml file as mentioned here <a href="https://www.techblogss.com/springboot/spring-boot-print-all-beans#pom" target="_blank"/>pom.xml</a>

	
    <br>
	 <h4>Step 2) Create Component class, application.properties and ExternalizeApplication class</h4>
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

public interface Printer {
    void print(String data);
}
	</div>
	</pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class SimplePrinter implements Printer {
	
    public void print(String data) {
        System.out.println(data);
    }

}
	</div>
	</pre>

    <h4>application.properties file</h4>
	<div id="code">
    <pre class="prettyprint">
    name=test
    </div>
	</pre>
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ExternalizeApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExternalizeApplication.class, args);
    }
	
    @Bean
    public ApplicationRunner printRunner(Printer printer, @Value("${name}") String name) {
        return args -> {printer.print("name is " + name);};
    }
}
 	</div>
	</pre>
    
    <br>
    <div>
        <p><img src="../images/sb_externalize.jpg" alt="Maven Build" style="width:400px;height:400px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    <h4>Step 3) Building ExternalizeApplication</h4>
    a) To build this Spring Boot application in eclipse, you can right click on ExternalizeApplication project
    , select <b>Run as </b>&rarr; <b>Maven build </b>. In Goals provide <b>clean install</b><br>
    
    <div>
        <p><img src="../images/sb_maven.jpg" alt="Maven Build" style="width:600px;height:400px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
    b) To build this Spring Boot application from command prompt, use following command &rarr; <b>mvn clean install</b>.

    <h4>Step 4) Running ExternalizeApplication</h4>
    a) To Run this Spring Boot application in eclipse, you can right click on ExternalizeApplication class
    , select <b>Run as </b>&rarr; <b>Java Application</b><br><br>
    b) To Run this Spring Boot application from command prompt, use following command &rarr; <b>java -jar demo-0.0.1-SNAPSHOT.jar</b></h4>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">


  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.6.RELEASE)

2019-09-08 22:50:43.951  INFO 5464 --- [           main] com.example.demo.ExternalizeApplication  : Starting ExternalizeApplication on ssss-PC with PID 5464 (C:\Dev\eclipse\workspace\SpringBoot\target\classes started by sss in C:\Dev\eclipse\workspace\SpringBoot)
2019-09-08 22:50:43.956  INFO 5464 --- [           main] com.example.demo.ExternalizeApplication  : No active profile set, falling back to default profiles: default
2019-09-08 22:50:45.644  INFO 5464 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8080 (http)
2019-09-08 22:50:45.692  INFO 5464 --- [           main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
2019-09-08 22:50:45.692  INFO 5464 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.21]
2019-09-08 22:50:45.839  INFO 5464 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2019-09-08 22:50:45.840  INFO 5464 --- [           main] o.s.web.context.ContextLoader            : Root WebApplicationContext: initialization completed in 1782 ms
2019-09-08 22:50:46.180  INFO 5464 --- [           main] o.s.s.concurrent.ThreadPoolTaskExecutor  : Initializing ExecutorService 'applicationTaskExecutor'
2019-09-08 22:50:46.465  INFO 5464 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2019-09-08 22:50:46.468  INFO 5464 --- [           main] com.example.demo.ExternalizeApplication  : Started ExternalizeApplication in 3.084 seconds (JVM running for 3.568)
name is test

		</pre>
	</div>		
	<div id="comments">
	</div>

    <div id="solution">
        <h3>2) The example below shows how to keep application configuration in properties file packaged outside the application and use it in Spring Boot
        application.</h3> 
	</div>
    
    <h4>Step 1) Create pom.xml as in previous example</h4>
    
    <h4>Step 2) Create an application.properties file at the same place where artifact (demo-0.0.1-SNAPSHOT.jar) is kept</h4>
    
    <div>
        <p><img src="../images/sb_externalize_2.jpg" alt="Maven Build" style="width:700px;height:300px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    <h4>application.properties file</h4>
	<div id="code">
    <pre class="prettyprint">
name=test2
	</pre>
    </div>
    
	<br>
	 <h4>Step 3) Create Component class, application.properties and ExternalizeApplication class as in previous example</h4>
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

public interface Printer {
    void print(String data);
}
	</pre>
	</div>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class SimplePrinter implements Printer {
	
    public void print(String data) {
        System.out.println(data);
    }

}
	</div>
	</pre>

    <h4>application.properties file</h4>
	<div id="code">
    <pre class="prettyprint">
name=test
    </div>
	</pre>
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ExternalizeApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExternalizeApplication.class, args);
    }
	
    @Bean
    public ApplicationRunner printRunner(Printer printer, @Value("${name}") String name) {
        return args -> {printer.print("name is " + name);};
    }
}
 	</div>
	</pre>
    
    <br>
    <div>
        <p><img src="../images/sb_externalize.jpg" alt="Maven Build" style="width:400px;height:400px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    <h4>Step 4) Build ExternalizeApplication as shown in previous example</h4>

    <h4>Step 5) Running ExternalizeApplication</h4>
     Run this Spring Boot application from command prompt, using following command &rarr; <b>java -jar demo-0.0.1-SNAPSHOT.jar</b>. Observe that value of 
     name property has been overridden by the one provided in external application.properties file <b>(name=test2)</b>.</b></h4>
<div id="solution">
		<h4>Output : </h4>
        <div id="code">
		<pre class="prettyprint">
C:\Dev\eclipse\workspace\SpringBoot\target>java -jar demo-0.0.1-SNAPSHOT.jar

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.6.RELEASE)

2019-10-04 08:32:57.270  INFO 3468 --- [           main] com.example.demo.ExternalizeApplication  : Starting Externalize
Application v0.0.1-SNAPSHOT on ssss-PC with PID 3468 (C:\Dev\eclipse\workspace\SpringBoot\target\demo-0.0.1-SNAPSHOT.jar
 started by sss in C:\Dev\eclipse\workspace\SpringBoot\target)
2019-10-04 08:32:57.283  INFO 3468 --- [           main] com.example.demo.ExternalizeApplication  : No active profile se
t, falling back to default profiles: default
2019-10-04 08:32:59.214  INFO 3468 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized w
ith port(s): 8080 (http)
2019-10-04 08:32:59.268  INFO 3468 --- [           main] o.apache.catalina.core.StandardService   : Starting service [To
mcat]
2019-10-04 08:32:59.271  INFO 3468 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet eng
ine: [Apache Tomcat/9.0.21]
2019-10-04 08:32:59.431  INFO 3468 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring
embedded WebApplicationContext
2019-10-04 08:32:59.433  INFO 3468 --- [           main] o.s.web.context.ContextLoader            : Root WebApplicationC
ontext: initialization completed in 2046 ms
2019-10-04 08:32:59.898  INFO 3468 --- [           main] o.s.s.concurrent.ThreadPoolTaskExecutor  : Initializing Executo
rService 'applicationTaskExecutor'
2019-10-04 08:33:00.232  INFO 3468 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on po
rt(s): 8080 (http) with context path ''
2019-10-04 08:33:00.239  INFO 3468 --- [           main] com.example.demo.ExternalizeApplication  : Started ExternalizeA
pplication in 3.678 seconds (JVM running for 4.237)
name is test2

    </div>
    </pre>
	</div>
    <br>
	
References : <br><br>
<a href="https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-external-config.html">Spring Boot Externalize Configuration</a>	<br>

    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
    
</body>

<?php 
    include("footer.htm");
?>
</html>