<?php 
    include("header.htm");
?>

<head>
    <title>Read YAML file in Spring Boot</title>
    <meta name="description" content="Read YAML file in Spring Boot" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-read-yaml-file" />
</head>

<body>
    <?php 
        include("navigation.htm");
    ?>
       
    <div id="content">
    <div id="problem">
        <h2>Read YAML file in Spring Boot</h2>
    </div>
    <div id="solution">
        <p>This tutorial shows how to read a <b><i>YAML</b></i> file in a Spring Boot application using <b><i>@Configuration</b></i>
        & <b><i>@ConfigurationProperties</b></i> annotations.</p> 
     </div>

    <div id="pom">    
    <h4>1) Create pom.xml</h4>
    
    <div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
    
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;

    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
    
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Demo project for Spring Boot&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
        &lt;/dependency&gt;
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-test&lt;/artifactId&gt;
        &lt;/dependency&gt;
        &lt;scope&gt;test&lt;/scope&gt;
    &lt;/dependencies&gt;
    
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;    </pre>
    </div>
    </div>
    <br>
    

     <h4>2) Create application.yam file with key values and keep it under src/main/resources</h4>

    <div id="code">
    <pre class="prettyprint">
ldap:
  url: ldap://ldap.example.com:389/
  protocol: ssl
  bindDN: region1\\john.doe@example.coml
  baseFilters:
   - =CN={0}
   - =uid={0}
  servers:
    - ip: 127.0.0.1
      port: 8001
    - ip: 127.0.0.2
      port: 8002    </pre>
    </div>
    <br>
    
    <h4>3) Create <i>LDAPConfiguration</i> & <i>Server</i> classes to map values in yaml file. </p>
     
     
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties("ldap")
public class LDAPConfiguration {

    private String url;
    private String protocol;
    private String bindDN;
    private List&lt;String> baseFilters;
    private List&lt;Server> servers;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getBindDN() {
        return bindDN;
    }

    public void setBindDN(String bindDN) {
        this.bindDN = bindDN;
    }

    public List&lt;String> getBaseFilters() {
        return baseFilters;
    }

    public void setBaseFilters(List&lt;String> baseFilters) {
        this.baseFilters = baseFilters;
    }

    public List&lt;Server> getServers() {
        return servers;
    }

    public void setServers(List&lt;Server> servers) {
        this.servers = servers;
    }

    @Override
    public String toString() {
        return "LDAPConfiguration [url=" + url + ", protocol=" + protocol
                + ", bindDN=" + bindDN + ", baseFilters=" + baseFilters
                + ", servers=" + servers + "]";
    }

}    </div>
    </pre>
    <br>

    <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class Server {

    private String ip;
    private String port;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    @Override
    public String toString() {
        return "Server [ip=" + ip + ", port=" + port + "]";
    }

}    </pre>
    </div>        
    <br>

    <h4>4) Read key value from application.yaml file using <b><i>YAMLReader</b></i> class as shown below</h4>

    <div id="code">
    <pre class="prettyprint">
// Reads YAML file
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YAMLReader implements CommandLineRunner {

    @Autowired
    private LDAPConfiguration ldapConfiguration;

    public static void main(String[] args) {
        SpringApplication.run(YAMLReader.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println(ldapConfiguration);
    }
}   </div>
    </pre>
    <br>
    
    <h4>5) Run above application, you will see below message in console</h4>
     
    <div id="code">
    <pre class="prettyprint">

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.6.RELEASE)

2020-08-15 19:57:25.255  INFO 2172 --- [           main] com.example.demo.YAMLReader              : Starting YAMLReader on ssss-PC with PID 2172 (C:\Dev\eclipse\workspace_springboot\ReadYAML\target\classes started by sss in C:\Dev\eclipse\workspace_springboot\ReadYAML)
2020-08-15 19:57:25.255  INFO 2172 --- [           main] com.example.demo.YAMLReader              : No active profile set, falling back to default profiles: default
2020-08-15 19:57:26.755  INFO 2172 --- [           main] com.example.demo.YAMLReader              : Started YAMLReader in 2.061 seconds (JVM running for 2.532)
LDAPConfiguration [url=ldap://ldap.example.com:389/, protocol=ssl, bindDN=region1\\john.doe@example.coml, baseFilters=[=CN={0}, =uid={0}], servers=[Server [ip=127.0.0.1, port=8001], Server [ip=127.0.0.2, port=8002]]]
    </div>
    </pre>
    <br>

    
    <h4>6) Below is the Spring Boot Test class to test above application which reads application.yaml file.</h4>
    <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = LDAPConfiguration.class)
public class LDAPConfigurationTest {
    
    @Autowired
    private LDAPConfiguration ldapConfiguration;
    
    @Test
    public void testLDAPConfiguration() {
        assertEquals("ssl", ldapConfiguration.getProtocol());
    }

}       </pre>
    </div>        

    </div>
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
</body>

<?php 
    include("footer.htm");
?>
</html>