<?php include 'header.php';?>

<head>
    <title>Spring Boot Gradle Plugin example</title>
	<meta name="description" content="This example shows how to create a Spring Boot application using Spring Boot Gradle Plugin" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-gradle-plugin" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
		<div id="problem">
			<h1>Spring Boot Gradle Plugin example</h1>
		</div><br>
        
	<div id="solution">
        <p><b><i>Spring Boot Gradle Plugin</b></i> makes gradle possible to build Spring Boot application and create executable jar and war files for the application and also run the application. It also lets gradle use the dependency management of spring-boot-dependencies.</p>
        <p>The example below shows how to build and launch your first <b><i>Spring Boot</b></i> application using <b><i>Spring Boot Gradle Plugin</b></i> both in eclipse as well from command prompt.</p> 
	</div>
    <h2>Steps to create a Spring Boot application using gradle plugin</h2>
    
    <div id="gradle">    
		<h3>Step 1) Download gradle and set the directory in eclipse</h3>
		<p>You can download gradle from here</p><a href="https://gradle.org/install/" target="_blank">https://gradle.org/install/</a>
		<p><img src="../images/springboot/sb_gradle_5.png" alt="Install Gradle" title="Install Gradle" style="width:1000px;height:500px;"></p>
	</div>
	
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	
	<div id="gradle_2">    
		<h3>Step 2) Create Gradle project</h3>
		<p>Go to File &rarr; New &rarr; Project &rarr; Gradle &rarr; Gradle Project, Click Next, Click Finish</p>
		<p><img src="../images/springboot/sb_gradle.png" alt="Gradle Project" title="Gradle Project" style="width:1000px;height:400px;"></p>
		<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<p><img src="../images/springboot/sb_gradle_2.png" alt="Gradle Project" title="Gradle Project" style="width:1000px;height:600px;"></p>
		<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<p><img src="../images/springboot/sb_gradle_4.png" alt="Gradle Project" title="Gradle Project" style="width:400px;height:400px;"></p>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
	
    <h3>Step 3) Update build.gradle file for Spring Boot application</h3>
    <p>Spring Boot requires a buildscript task to use Spring Boot Gradle plugin and to extend the default dependency management capabilities of Gradle.</p>
    
    <p>Also as this is Java project, you need <b><i>Java</i></b> plugin and <b><i>org.springframework.boot</i></b> plugin & 
    <b><i>io.spring.dependency-management</i></b> to let Spring Boot starters mangage the dependencies.
    </p>
     
	<div id="code">
    <pre class="prettyprint">
buildscript {
    ext {
        springBootVersion = '2.1.6.RELEASE'
    }
  
    repositories {
	    mavenCentral()
    }
  
    dependencies {
	    classpath ("org.springframework.boot:spring-boot-gradle-plugin:${springBootVersion}")
    }
}
  
apply plugin: 'java'
apply plugin: 'org.springframework.boot'
apply plugin: 'io.spring.dependency-management'

dependencies {
    compile 'org.springframework.boot:spring-boot-starter'
}

repositories {
    mavenCentral()
} 	</div>
	</pre>
    <br>
	
	<h3>Step 4) Create SpringBootGradleApplication class</h3>
     This Class prints number of beans provided by Spring Boot and also bean names.
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringBootGradleApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(SpringBootGradleApplication.class, args);
			
        System.out.println("Number of beans --> " + ctx.getBeanDefinitionCount());
        String[] beanNames = ctx.getBeanDefinitionNames();
        for (String beanName : beanNames) {
            System.out.println("Bean --> "+ beanName);
        }
    }

} 	</div>
	</pre>
    <br>

    <div id="1">
    
    <h3>Step 5) Building SpringBootGradleApplication class using gradle build</h3>
    <h4>Build using eclipse</h4>
    <p>To build this Spring Boot application in eclipse, you can click build under gradle tasks (Gradle Task View)</p>
    
        <p><img src="../images/springboot/sb_gradle_6.png" alt="Gradle Tasks" title="Gradle Tasks" style="width:600px;height:400px;"></p>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<p>If you see any class is not compiled, then right click on <b><i>project</b></i> directory and select <b><i>Gradle</b></i>
        and then select <b><i>Refresh Gradle Project</b></i></p>
    <h4>Build using gradle</h4>  
    <p>To build this Spring Boot application using gradle command <i>./gradlew bootJar</i> which will generate executable jar</p>    

    </div>
    
            
    <div id="2">
    <h3>Step 6) Running SpringBootGradleApplication</h3>
    <h4>Run using eclipse</h4>
    <p>To Run this Spring Boot application in eclipse, you can right click on SpringBootGradleApplication class
    , select <b>Run as </b>&rarr; <b>Java Application</b>. You will see below messages in console.</p>
    
    <h4>Run using gradle</h4>  
    <p>To Run this Spring Boot application from command prompt, you can use <i>java -jar demo.jar</i> or you can also use <i>./gradlew bootRun</i>
    </p>
    </div>
<div id="solution">
		<h3>Output : </h3>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.0.RELEASE)

2020-07-09 16:42:36.812  INFO 276 --- [           main] hello.SpringBootGradleApplication : Starting SpringBootGradleApplication on ssss-PC with PID 276 (C:\Dev\eclipse\workspace\SpringBootGradle\bin\main started by sss in C:\Dev\eclipse\workspace\SpringBootGradle)
2020-07-09 16:42:36.818  INFO 276 --- [           main] hello.SpringBootGradleApplication : No active profile set, falling back to default profiles: default
2020-07-09 16:42:38.316  INFO 276 --- [           main] hello.SpringBootGradleApplication : Started SpringBootGradleApplication in 2.15 seconds (JVM running for 3.056)
Number of beans --> 27
Bean --> org.springframework.context.annotation.internalConfigurationAnnotationProcessor
Bean --> org.springframework.context.annotation.internalAutowiredAnnotationProcessor
Bean --> org.springframework.context.annotation.internalCommonAnnotationProcessor
Bean --> org.springframework.context.event.internalEventListenerProcessor
Bean --> org.springframework.context.event.internalEventListenerFactory
Bean --> SpringBootGradleApplication
Bean --> org.springframework.boot.autoconfigure.internalCachingMetadataReaderFactory
Bean --> org.springframework.boot.autoconfigure.AutoConfigurationPackages
Bean --> org.springframework.boot.autoconfigure.context.PropertyPlaceholderAutoConfiguration
Bean --> org.springframework.boot.autoconfigure.condition.BeanTypeRegistry
Bean --> propertySourcesPlaceholderConfigurer		</pre>
	</div><br>		


References : <br><br>
<a href="https://docs.spring.io/spring-boot/docs/current/gradle-plugin/reference/html/" target="_blank">Spring Boot Gradle Plugin Reference</a>	<br><br>
	</div>
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
</body>

<?php 
    include("footer.htm");
?>
</html>