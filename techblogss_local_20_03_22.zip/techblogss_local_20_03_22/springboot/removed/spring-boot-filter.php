<?php include 'header.php';?>

    <head>
        <title>Spring Boot Filter example</title>
        <meta name="description" content="This Spring Boot Filter example shows how to add a Spring Boot filter" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-filter" />
    </head>

    <body>
        <?php 
            include("navigation.htm");
        ?>
        
        <div id="content">
        <div id="blog" style="float:left;">
        
        <div id="problem">
            <h1>Spring Boot Filter example</h1>
        </div><br>
        <h2>This Spring Boot Filter example shows how to add a Spring Boot filter</h2>
        <div id="solution">
            <p>
            A <b><i>filter</b></i> is an object that performs filtering tasks on either the request to a resource (a servlet or static content),
            or on the response from a resource, or both. <b><i>Filters</b></i> perform filtering in the <b><i>doFilter</b></i> method. 
            </p> 
            <p>
            Below are few examples of <b><i>filters</b></i> you can use in your Spring Boot web application:
            <ul>
                <li>Authentication Filters</li>
                <li>Logging and Auditing Filters</li>
                <li>Image conversion Filters</li>
                <li>Data compression Filters</li>
                <li>Encryption Filters</li>
                <li>Tokenizing Filters</li>
                <li>Mime-type chain Filter</li>
            </ul>            
            <h3>Implementing Filter</h3>
            <p>
            To add a Spring Boot <b><i>filter</b></i>, you need to implement the <b><i>Filter</b></i> interface.
            The following are the three methods defined in <b><i>Filter</b></i> interface:
            <ul>
                <li>
                <b><i>init()</b></i> method - Called by the web container to indicate to a filter that it is being placed into service.
                The servlet container calls the init method exactly once after instantiating the filter.
                </li>
                <li>
                <b><i>doFilter()</b></i> method - The doFilter method of the Filter is called by the container each time a request/response pair
                is passed through the chain due to a client request for a resource at the end of the chain.
                </li>
                <li>
                <b><i>destroy()</b></i> method - Called by the web container to indicate to a filter that it is being taken out of service.
                </li>
            </ul>
        </div>
        <p>In the example below we will create a Spring Boot Logging <b><i>Filter</b></i> & a profiling <b><i>Filter</b></i> and see how these get invoked in a Spring Boot application</p>
        
        <h4>Step 1) Create pom.xml</h4>
        Create a pom.xml file as below and keep it in Java project directory.
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
       
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
        
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
        
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Demo project for Spring Boot&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;		
                   
    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;
        
&lt;/project&gt;        </pre>
        </div>
        <br>
         <h4>Step 2) Create HelloWorldApplication class</h4>
         <p>When run, HelloWorldApplication class will start the embedded Tomcat server and will have a preconfigured Spring MVC setup.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelloWorldApplication.class, args);
    }
}       </pre>
        </div>
        <br>
    <h4>Step 3) Create HelloWorldController class</h4>
    <p>@GetMapping maps the hello method to every GET request that arrives at /</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    @GetMapping("/")
    public String hello() {
        System.out.println("Returning response");
        return "Hello World";
    }
}        </pre>
        </div>	
        <br>
    <h4>Step 4) Create ProfilingFilter class</h4>
    <p>ProfilingFilter will calculate the time taken by the server for processing the request. Observe that @Order annotation is used
    to specify order in which servlet filter will be invoked.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Order(1)
@Component
public class ProfilingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
		FilterChain chain) throws IOException, ServletException {

        long startTime = System.currentTimeMillis();
        chain.doFilter(request, response);
        System.out.printf("Time taken %d millisec \n", System.currentTimeMillis()- startTime);
    }

}    </pre>
        </div>	
        <br>        

            <h4>Step 5) Create LoggingFilter class</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Order(2)
@Component
public class LoggingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        System.out.printf("\nLogging Request  %s %s\n", req.getMethod(), req.getRequestURI());
        chain.doFilter(request, response);
        System.out.printf("\nLogging Response %s \n", res.getContentType());
    }

}    </pre>
        </div>	
        <br>  
 
        
      <h4>Step 6) Building HelloWorldApplication</h4>
    
       <p>
       Build this Spring Boot application using this command &rarr; <b><i>mvn clean install</b></i>
       </p>
        
       <h4>Step 7) Running HelloWorldApplication</h4>
        <p>
        Run this Spring Boot application using following command &rarr; <b><i>java -jar demo-0.0.1-SNAPSHOT.jar</b></i>
        </p>

         <h4>Step 8) Testing HelloWorldApplication </h4>     
     Open any browser and launch <a href="http://localhost:8080" target="_blank">http://localhost:8080</a>. You will see 'Hello World' message 
     displayed in the broswer.<br>
     
        <div>
            <p><img src="../images/sb_helloworld.jpg" alt="Spring Boot Filter" title="Spring Boot Filter"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
     
    <p>Observe the logs below which shows the log messages from the ProfilingFilter & LoggingFilter. It shows that these Spring Boot Filters were
    invoked.</p>    
        <div id="code">
        <pre class="prettyprint">
Logging Request  GET /
Returning response

Logging Response text/html;charset=UTF-8 
Time taken 55 millisec 

Logging Request  GET /favicon.ico

Logging Response image/x-icon 
Time taken 28 millisec     </pre>
        </div>	
        <br><br>        
        
    References : <br><br>
    <a href="https://docs.oracle.com/javaee/7/api/javax/servlet/Filter.html?is-external=true" target="_blank">
    Servlet Filter</a>	<br><br>
    
   <?php include("../sidebar/ad.htm"); ?>   
        
      </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>