<?php 
    include("header.htm");
?>

<head>
    <title>Spring Boot Active Profile</title>
	<meta name="description" content="Spring Boot Active Profile, Spring Boot run with Profile" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-active-profile" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
    
	<div id="problem">
		<h1>Spring Boot Active Profile</h1>
	</div>
    
	<div id="solution">
        <p>
        Sometimes you need different configuration for different environments like local, dev, uat, prod, etc. To avoid manually creating
        and changing configuration like database configuation for different environments, you can simply create different profiles for
        different environments & invoke the <b><i>active profile</b></i>. 
        </p>
        <p>
        You just need to provide the profile name in runtime arguments to invoke the <b><i>active profile</b></i>.
        Below example shows how to create database configuation for local & non-local environment and invoke the <b><i>active profile</b></i>.
        </p>
	</div>

    <h4>Step 1)</h4>
        Create a pom.xml file as below and keep it in Java project directory. It contains Spring Boot starter maven dependencies.

    <div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
	
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
	
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
	
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Demo project for Spring Boot&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;
    </pre>
	</div>
    
	<br>
	 <h4>Step 2) Create DataBaseConfigInterface interface & DataBaseConfig classes for local and non-local enviornments.</h4>
          
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

public interface DataBaseConfigInterface {

}
	</div>
	</pre>
    <br>
<p>To enable <b><i>local active profile</b></i>, you need to use <b><i>@Profile</b></i> annotation as shown below</p>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("local")
public class LocalDataBaseConfig implements DataBaseConfigInterface {

    public LocalDataBaseConfig() {
        System.out.println("Creating DataBase Config for local");
    }

}
	</div>
	</pre>
    <br>
    <div id="solution">
<p>
To enable any other active profile than <b><i>local</b></i>, you need to use <b><i>!local</b></i> as shown below. 
</p>
<p>
If you want to use a active profile say for <b><i>dev</b></i> or <b><i>uat</b></i> or <b><i>prod</b></i>, you can specify like <b><i>@Profile("dev"),
 @Profile("uat"), @Profile("prod")</b></i>.
</p>
</div>
    
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("!local")
public class DataBaseConfig implements DataBaseConfigInterface {

    public DataBaseConfig() {
        System.out.println("Creating dataBase config");
    }
}
 	</div>
	</pre>
    <br>
    
    <h4>Step 3) Create DemoService & ActivePofileDemoApplication classes.</h4>
    <p>When application is launched using ActivePofileDemoApplication, DemoService dataBaseConfig variable will be instantiated
    based on the active profile (local, dev, etc) .</p>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DemoService {
	
    @Autowired
    DataBaseConfigInterface dataBaseConfig;

    public List&lt;String> getUsers() {
        System.out.println("getting users");
        return Arrays.asList("Mark", "John", "David"); 
    }

}
 	</div>
	</pre>
    <br>


<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivePofileDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ActivePofileDemoApplication.class, args);
    }

}
 	</div>
	</pre>
    <br>
    
    <h4>Step 4) Building ActivePofileDemoApplication</h4>
     
        <p> Build this Spring Boot application using this command &rarr; <b><i>mvn clean install</b></i></p>

        <h4>Step 5) Running ActivePofileDemoApplication</h4>
        <p>Run this Spring Boot application using following command &rarr; <b><i>java -Dspring.profiles.active=local -jar demo-0.0.1-SNAPSHOT.jar</b></i></p>
    <div id="solution">
            <h4>Console output : </h4>
        </div>
	
	<div id="code">
		<pre class="prettyprint">
   .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.6.RELEASE)

2020-01-27 22:39:03.691  INFO 3480 --- [main] c.e.demo.ActivePofileDemoApplication : Starting ActivePofil
eDemoApplication v0.0.1-SNAPSHOT on ssss-PC with PID 3480 (C:\Dev\eclipse\workspace\SpringBoot\target\demo-0.0.1-SNAPSHO
T.jar started by sss in C:\Dev\eclipse\workspace\SpringBoot\target)
2020-01-27 22:39:03.691  INFO 3480 --- [main] c.e.demo.ActivePofileDemoApplication : The following profiles are active: local
Creating DataBase Config for local
2020-01-27 22:39:04.565  INFO 3480 --- [main] c.e.demo.ActivePofileDemoApplication     : Started ActivePofile
DemoApplication in 1.451 seconds (JVM running for 2.003)
		</pre>
	</div>	
<br>	
    
    <p>If you pass active profile as dev, (java -Dspring.profiles.active=dev -jar demo-0.0.1-SNAPSHOT.jar), you will see below console output</p>
<div id="code">
		<pre class="prettyprint">
   .   ____          _            __ _    
	  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.6.RELEASE)

2020-01-27 22:39:11.585  INFO 1276 --- [main] c.e.demo.ActivePofileDemoApplication : Starting ActivePofil
eDemoApplication v0.0.1-SNAPSHOT on ssss-PC with PID 1276 (C:\Dev\eclipse\workspace\SpringBoot\target\demo-0.0.1-SNAPSHO
T.jar started by sss in C:\Dev\eclipse\workspace\SpringBoot\target)
2020-01-27 22:39:11.600  INFO 1276 --- [main] c.e.demo.ActivePofileDemoApplication : The following profiles are active: dev
Creating dataBase config
2020-01-27 22:39:12.458  INFO 1276 --- [main] c.e.demo.ActivePofileDemoApplication     : Started ActivePofile
DemoApplication in 1.435 seconds (JVM running for 1.989)
</pre>
	</div>	
    <br>
   
 
    
    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>