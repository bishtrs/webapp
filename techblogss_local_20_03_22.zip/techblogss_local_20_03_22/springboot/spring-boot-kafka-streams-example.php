<?php 
    include("../header.htm");
?>

<head>
    <title>Spring Boot Kafka Streams example</title>
    <meta name="description" content="Spring Boot Kafka Streams example" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-kafka-streams-example" />
</head>

<body>
        <?php include("../navigation.htm"); ?>
        
    <div id="content">
    <div id="blog">
        <div id="problem">
            <h1>Spring Boot Kafka Streams example</h1>
        </div>
        <div id="solution">
            <p>
            Stream processing means processing the data as it continuosly arrives as a stream. <code>Kafka Streams</code> is a library to process stream of records.<code>Kafka Streams DSL</code> is high-level API to build <code>Kafka Streams</code>. It uses <code>KStream</code> object which represents the streaming key/value pair. <code>Kafka Streams</code> are typically used to process, transform the records and then send to another topic.
            </p> 
        </div>
        
        <h4>Step 1) Launch zookeeper and kafka server</h4>
        View this page for details on launching zookeeper & kafka server <a href="https://www.techblogss.com/springboot/spring-boot-kafka-example" target="_blank">Spring Boot Kafka example</a>
        
        <h4>Step 2) Create topic where stream data will be published</h4>
        <p>Creata topic named "data" where a stream of records will be send and which will be consumed by the Kafka stream processor</p>
        <code>
        kafka-topics.bat --create --topic data --partitions 1 --replication-factor 1 --bootstrap-server localhost:9092
        </code>
        
        <h4>Step 3) Publish data to "data" topic using kafka console</h4>
        <p>We will send data as key value pair using below command. Press Ctrl+C to stop sending the data.</p>
        <code>
        kafka-console-producer.bat --topic data --broker-list localhost:9092 --property "parse.key=true"  --property "key.separator=":"
        </code>

        <div id="code">
        <pre class="prettyprint">
C:\Dev\kafka_2.11-2.3.1\bin\windows>kafka-console-producer.bat --topic data --broker-list localhost:9092 --property "parse.key=true"  --property "key.separator=":"
>1:asia
>2:europe
>3:australia</pre></div><br>
        
        <h4>Step 4) Create pom.xml for Spring Boot Kafka Streams Processor application</h4>
        <p style="text-align:justify;">Create a pom.xml file as below and keep it in Java project directory. It contains Spring Boot Kafka maven dependencies.
        </p>
        
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
        
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
        
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
        
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Demo project for Spring Boot Kafka Streams&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
        &lt;/dependency&gt;

        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.kafka&lt;/groupId&gt;
            &lt;artifactId&gt;spring-kafka&lt;/artifactId&gt;
        &lt;/dependency&gt;

        &lt;dependency&gt;
            &lt;groupId&gt;org.apache.kafka&lt;/groupId&gt;
            &lt;artifactId&gt;kafka-streams&lt;/artifactId&gt;
        &lt;/dependency&gt; 
                   
    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;
        
&lt;/project&gt;        </pre></div> <br>

    <div id="solution">
    <h4>Step 5) Create KafkaStreamsConfig class which contains kafka streams configuration</h4>
    <p>To configure Kafka Streams, you need to provide at least <code>BOOTSTRAP_SERVERS_CONFIG</code> & <code>APPLICATION_ID_CONFIG</code> properties. <code>BOOTSTRAP_SERVERS_CONFIG</code> points the Kafka Streams application to the Kafka cluster while <code>APPLICATION_ID_CONFIG</code>  identifies the Kafka Streams application, which should be unique per cluster.
    </p>
    <p>
    In this example we are using high level Streams DSL API. First we create a <code>StreamsBuilder</code> and use it to build a <code>Topology</code> which is a DAG - a directed graph of transformations applied to stream of events. In this example we are dpoing only processing that is printing to console and not really doing any transformations.
    </p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">    
package com.example;

import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaStreamsConfig {

    @Bean
    public KafkaStreams kafkaStreams() {
        final Topology topology = getTopology();
        final KafkaStreams streams = new KafkaStreams(topology, streamsConfiguration());
        streams.cleanUp();
        streams.start();

        // Add shutdown hook to respond to SIGTERM and gracefully close Kafka Streams
        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));

        return streams;
    }

    public Properties streamsConfiguration() {
        Properties streamsConfiguration = new Properties();
        streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, "my-app");
        streamsConfiguration.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        streamsConfiguration.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        streamsConfiguration.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        streamsConfiguration.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 10 * 1000);
        return streamsConfiguration;
    }

    private Topology getTopology() {
        final StreamsBuilder builder = new StreamsBuilder();
        final KStream&lt;String, String> input = builder.stream("data");

        input.foreach((k, v) -> System.out.println("Key = " + k + " value = " + v));

        return builder.build();
    }
} </div></pre><br>

    <h4>Step 6) Create KafkaStreamsProcessorApplication class which launches the Spring Boot application</h4>

    <div id="code">
    <pre class="prettyprint">    
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaStreamsProcessorApplication {

    public static void main(String[] args) {
        SpringApplication.run(KafkaStreamsProcessorApplication.class, args);
    }

}</div></pre><br>

        
     <h4>Step 7) Running KafkaStreamsProcessorApplication </h4>
     <p>
     Start KafkaStreamsProcessorApplication, you will see the list of records printed on console as key value pair.
     </p>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>
   
    <div id="code">
    <pre class="prettyprint">
2021-03-07 20:29:24.736  INFO 16936 --- [-StreamThread-1] o.a.k.c.c.internals.ConsumerCoordinator  : [Consumer clientId=my-app-52667270-7861-4e1d-bdfc-3e590673faf1-StreamThread-1-consumer, groupId=my-app] Setting offset for partition data-0 to the committed offset FetchPosition{offset=5, offsetEpoch=Optional.empty, currentLeader=LeaderAndEpoch{leader=Optional[LAPTOP-L5SL049K:9092 (id: 0 rack: null)], epoch=absent}}
Key = 1 value = asia
Key = 2 value = europe
Key = 3 value = australia
2021-03-07 20:29:25.406  INFO 16936 --- [           main] o.s.s.c.ThreadPoolTaskScheduler          : Initializing ExecutorService 'taskScheduler'
2021-03-07 20:29:25.437  INFO 16936 --- [           main] o.s.c.f.c.c.SimpleFunctionRegistry       : Looking up function '' with acceptedOutputTypes: []    </div></pre> <br>

    <div id="solution">
    <h3>Configuring Streams using application.yml</h3>
    <p>In case you do not want to keep the Streams configuration in Java class, you can also use <code>application.yml</code> to specify the Streams configurations shown below. You also need to provide a bean to process the streams as shown below in <code>KafkaStreamsProcessorApplication</code>.</p>
    </div>

<div id="code">
    <pre class="prettyprint">
spring:
  cloud:
    stream:
      bindings:
        process-in-0.destination: data
      kafka:
        streams:
          binder:
            applicationId: my-app
            brokers: localhost:9092
            configuration:
              default:
                key:
                  serde: org.apache.kafka.common.serialization.Serdes$StringSerde
                value:
                  serde: org.apache.kafka.common.serialization.Serdes$StringSerde   </div></pre> 

    <div id="code">
    <pre class="prettyprint">
package com.example;

import org.apache.kafka.streams.kstream.KStream;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class KafkaStreamsProcessorApplication {
	
    public static void main(String[] args) {
        SpringApplication.run(KafkaStreamsProcessorApplication.class, args);
    }

    @Bean
    public java.util.function.Consumer&lt;KStream&lt;String, String>> process() {
        return stream -> stream.foreach((key, value) -> {
            System.out.println(key + ":" + value);
        });
    }
		
}    </div></pre><br> 

    <div id="solution">
    <h3>Creating Topology</h3>
    <p>
    In below example we create a <code>Topology</code> where we first create <code>firstStream (KStream)</code> form source stream, then we create another <code>KStream upperCaseStream</code> which converts the data to uppercase and finally it sends the data to sink which is another topic.
    </p>
    </div>
    
        <div id="code">
    <pre class="prettyprint">
private Topology getTopology() {
    final StreamsBuilder builder = new StreamsBuilder();
    final KStream&lt;String, String> firstStream = builder.stream("data");

    firstStream.foreach((k, v) -> System.out.println("Key = " + k + " value = " + v));

    final KStream&lt;String, String> upperCaseStream = firstStream.mapValues(data
        -> data.toUpperCase());
    upperCaseStream.foreach((k, v) -> System.out.println("Key = " + k + " value = " + v));
		
    upperCaseStream.to("data-out", Produced.with(Serdes.String(), Serdes.String()));
    return builder.build();
}   </div></pre> 

    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php include("footer.htm"); ?>
    
    </html>