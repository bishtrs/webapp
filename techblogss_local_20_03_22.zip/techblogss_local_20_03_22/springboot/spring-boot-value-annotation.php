<?php 
    include("header.htm");
?>

<head>
    <title>Spring Boot Value Annotation</title>
	<meta name="description" content="Spring Boot Value Annotation example, Spring Boot ConfigurationProperties example" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-value-annotation" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h2>Spring Boot Value & ConfigurationProperties Annotation examples</h2>
	</div>
	<div id="solution">
        <p>This tutorial shows how to use <b><i>@Value</b></i> & <b><i>@ConfigurationProperties</b></i> annotations to read configuration
        from properties file.</p> 
        <h3>@Value vs @ConfigurationProperties Annotation</h3>
        <p><b><i>@Value</b></i> annotation is provide by Spring Bean factory & is used at the field or method/constructor parameter level that
        indicates a default value expression for the annotated element. It supports SpEL (Spring Expression Language) expressions for setting the value.</p>
        </p>
        <p><b><i>@ConfigurationProperties</b></i> annotation is provided by SpringBoot & is used for externalized configuration. You can add this to 
        a class definition or a @Bean method in a @Configuration class if you want to bind and validate some external Properties 
        (e.g. from a .properties file or .yml file). Contrary to @Value, SpEL expressions are not evaluated since property values are externalized.</p>

	</div>

    <div id="pom">    
    <h4>Create pom.xml</h4>
    
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
	
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
	
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
	
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Demo project for Spring Boot&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;    </pre>
	</div>
    </div>
    <br>
    

	 <h3>1) Read key value from properties file using <b><i>@Value</b></i> annotation</h3>

	 <p>Create application.properties file with key values and keep it under src/main/resources</p>
	<div id="code">
    <pre class="prettyprint">
db.username=scott
db.password=tiger
listOfTables=Students,Subjects,Teachers
valuesMap={John: '1', Mark: '2', David: '3'}    </div>
	</pre>
    <br>
    
    <div id="solution">
     <p>Create <i>AppConfig</i> & <i>ConfigurationApplication</i> classes. <i>AppConfig</i> class will read the application.properties with the 
     help of <b><i>@PropertySource</b></i> and uses <b><i>@Value</b></i> annotation to store the value into attributes. It reads simple key value 
     pair using username, password attributes, reads list of tables into a string array, and map into valuesMap attribute.</p>
     </div>
     
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;
    
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class AppConfig {

    @Value("${db.username}")
    private String username;

    @Value("${db.password}")
    private String password;
    
    // reads data into a string array
    @Value("${listOfTables}")
    private String[] tableValues;
        
    // reads data into a map    
    @Value("#{${valuesMap}}")
    private Map&lt;String, Integer> valuesMap;
    
    // reads single value from key value pair
    @Value("#{${valuesMap}['John']}")
    private Integer value1;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
        
    public String[] getTableValues() {
        return tableValues;
    }

    public Map&lt;String, Integer> getValuesMap() {
        return valuesMap;
    }

    public Integer getValue1() {
        return value1;
    }
	
}	</div>
	</pre>
    <br>

   <div id="code">
    <pre class="prettyprint">
package com.example.demo;    
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ConfigurationApplication {

    @Autowired
    private AppConfig appConfig;

    public static void main(String[] args) {
        SpringApplication.run(ConfigurationApplication.class, args);
    }

    @Bean
    public ApplicationRunner printDataBaseConfig() {
        return args -> {
            System.out.println(appConfig.getUsername());
            System.out.println(appConfig.getPassword());
            System.out.println(Arrays.toString(
                appConfig.getTableValues()));
            System.out.println(appConfig.getValuesMap());
            System.out.println(appConfig.getValue1());            
        };
    }

}	</div>
	</pre>
    <br>
	<div id="code">
		<pre class="prettyprint">
scott
tiger
[Students, Subjects, Teachers]
{John=1, Mark=2, David=3}
1		</pre>
	</div>		
    <br>
    
    <?php include("../sidebar/ad.htm"); ?>    

<h3>2) Read key value from properties file using <b><i>@ConfigurationProperties</b></i> annotation</h3>

	 <p>Create application.properties file with key values and keep it under src/main/resources</p>
	<div id="code">
    <pre class="prettyprint">
app.username=scott
app.password=tiger
app.tableValues[0]=Students
app.tableValues[1]=Subjects
app.tableValues[2]=Teachers
app.valuesMap.John=1
app.valuesMap.Mark=2
app.valuesMap.David=3
app.value1=1    </div>
	</pre>
    <br>
    
    <div id="solution">
     <p>Create AppProperties & ConfigurationApplication classes. AppProperties class will read the application.properties with the help of 
     <b><i>@ConfigurationProperties</b></i> annotation to store the value into attributes. It reads simple key value 
     pair using username, password attributes, reads list of tables into a string array, and map into valuesMap attribute.</p>
     </div>
     
	<div id="code">
    <pre class="prettyprint">
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("app")
public class AppProperties {
	
    private String username;

    private String password;
        
    private String[] tableValues;
        
    private Map&lt;String, Integer> valuesMap;
        
    private Integer value1;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
	
    public String[] getTableValues() {
        return tableValues;
    }

    public Map&lt;String, Integer> getValuesMap() {
        return valuesMap;
    }

    public Integer getValue1() {
        return value1;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setTableValues(String[] tableValues) {
        this.tableValues = tableValues;
    }

    public void setValuesMap(Map&lt;String, Integer> valuesMap) {
        this.valuesMap = valuesMap;
    }

    public void setValue1(Integer value1) {
        this.value1 = value1;
    }

}
	</div>
	</pre>
    <br>

   <div id="code">
    <pre class="prettyprint">
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ConfigurationApplication {

    @Autowired
    private AppProperties appProperties;

    public static void main(String[] args) {
        SpringApplication.run(ConfigurationApplication.class, args);
    }

    @Bean
    public ApplicationRunner printDataBaseConfig() {
        return args -> {
            System.out.println(appProperties);
            System.out.println(appProperties.getUsername());
            System.out.println(appProperties.getPassword());
            System.out.println(Arrays.toString(
                appProperties.getTableValues()));
            System.out.println(appProperties.getValuesMap());
            System.out.println(appProperties.getValue1());
        };
    }

}	</div>
	</pre>
    <br>
	<div id="code">
		<pre class="prettyprint">
scott
tiger
[Students, Subjects, Teachers]
{John=1, Mark=2, David=3}
1		</pre>
	</div>		

	</div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
</body>

<?php 
    include("footer.htm");
?>
</html>