<?php include "../header.htm";?>

<head>
    <title>Spring boot print all beans at startup</title>
	<meta name="description" content="This tutorial shows how to get and print all Spring Boot Beans at startup" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-print-all-beans" />
</head>

<body>
	<?php include("../navigation.htm");?>
   	
	<div id="content">
	<div id="problem">
		<h1>Print all Beans in Spring Boot at startup</h1>
	</div>
    
	<div id="solution">
        <p>
        During <code>Spring Boot</code> application startup, many beans are created, some by <code>Spring Boot</code> framework while some that
        are configured for application. In case you need to print all the beans created for dubugging purpose, you can use 
        <code>ConfigurableApplicationContext getBeanDefinitionNames()</code> method.
        </p>
        <h2> Below example shows how to get and print all Beans in a Spring Boot Application at startup.</h2> 
	</div>

    <div id="pom">    
    <h4>Step 1) Create pom.xml and add below maven dependency</h4>
    
	<div id="code">
    <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;
</pre>
	</div>
    </div>
    
    <br>
	
	 <h3>Step 2) Create PrintBeansApplication class</h3>
     <p>This Class prints name of all beans provided by Spring Boot and also the beans count.</p>
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class PrintBeansApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(PrintBeansApplication.class, args);
			
        System.out.println("Number of beans --> " + ctx.getBeanDefinitionCount());
        String[] beanNames = ctx.getBeanDefinitionNames(); // get beans
        for (String beanName : beanNames) {
            System.out.println("Bean --> "+ beanName); // print bean
        }
    }

} 	</div>
	</pre>
    <br>

    <div id="2">
    <h3>Step 3) Running PrintBeansApplication</h3>
    <p>When you run PrintBeansApplication, you will see the list of beans printed in the console as shown below.</p>
   
    </div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Number of beans --> 27
Bean --> org.springframework.context.annotation.internalConfigurationAnnotationProcessor
Bean --> org.springframework.context.annotation.internalAutowiredAnnotationProcessor
Bean --> org.springframework.context.annotation.internalCommonAnnotationProcessor
Bean --> org.springframework.context.event.internalEventListenerProcessor
Bean --> org.springframework.context.event.internalEventListenerFactory
Bean --> printBeansApplication
Bean --> org.springframework.boot.autoconfigure.internalCachingMetadataReaderFactory
Bean --> org.springframework.boot.autoconfigure.AutoConfigurationPackages
Bean --> org.springframework.boot.autoconfigure.context.PropertyPlaceholderAutoConfiguration
Bean --> org.springframework.boot.autoconfigure.condition.BeanTypeRegistry
Bean --> propertySourcesPlaceholderConfigurer
Bean --> org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration
Bean --> mbeanExporter
Bean --> objectNamingStrategy
Bean --> mbeanServer
Bean --> org.springframework.boot.autoconfigure.context.ConfigurationPropertiesAutoConfiguration
Bean --> org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor
Bean --> org.springframework.boot.context.properties.ConfigurationBeanFactoryMetadata
Bean --> org.springframework.boot.autoconfigure.info.ProjectInfoAutoConfiguration
Bean --> spring.info-org.springframework.boot.autoconfigure.info.ProjectInfoProperties
Bean --> org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration
Bean --> taskExecutorBuilder
Bean --> applicationTaskExecutor
Bean --> spring.task.execution-org.springframework.boot.autoconfigure.task.TaskExecutionProperties
Bean --> org.springframework.boot.autoconfigure.task.TaskSchedulingAutoConfiguration
Bean --> taskSchedulerBuilder
Bean --> spring.task.scheduling-org.springframework.boot.autoconfigure.task.TaskSchedulingProperties
		</pre>
	</div><br>		

	
References : <br><br>
<a href="https://docs.spring.io/spring-framework/docs/current/spring-framework-reference/core.html#beans-definition target="_blank">Spring Beans</a>	<br><br>
	</div>
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
</body>

<?php 
    include("footer.htm");
?>
</html>