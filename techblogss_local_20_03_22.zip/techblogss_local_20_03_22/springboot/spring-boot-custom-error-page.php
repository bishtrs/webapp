<?php include("../header.htm"); ?>

    <head>
        <title>Spring Boot custom error page using thymeleaf</title>
        <meta name="description" content="Spring Boot custom error page using Thymeleaf" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-custom-error-page" />
    </head>

    <body>
        <?php include("../navigation.htm"); ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Custom Error Page using Thymeleaf</h1>
        </div>
        <div id="solution">
            <p>
            By default <b><i>exception or error handling</b></i>  is enabled in <code>Spring Boot</code> and it shows a default error page in case any
            <code>Exception</code> occurs.
            </p>
            <p>This example shows how to create a custom error page in case any exception occurs during tuntime. You can control details of the 
            <code>Exception</code> you want to show to use using following properties.</p>
            <h3>Error handling properties</h3>
            <ul>
                <li><b><i>server.error.whitelable.enabled</b></i> : if whitelabel error page is enabled, default is true</li>
                <li><b><i>server.error.path</b></i> : error page path, default is /error</li>
                <li><b><i>server.error.include-exception</b></i> : whether name of exception should be shown in error page, default is false</li>
                <li><b><i>server.error.include-stacktrace</b></i> : whether stacktrace should be shown in error page, default is never</li>
            </ul>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        
<div id="code">
   <pre class="prettyprint">
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
        &lt;/dependency&gt;		
          
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-thymeleaf&lt;/artifactId&gt;
        &lt;/dependency&gt;	 
    &lt;/dependencies&gt;        </pre></div><br>
    
         <h4>Step 2) Create Book, BookRestController, BookServiceApplication classes</h4>
         
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookServiceApplication {
	
	public static void main(String[] args) {
        SpringApplication.run(BookServiceApplication.class, args);
    }

}        </div></pre>

<div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class Book {
	
    private String title;
    private String author;
    private String genre;
        
    public Book(String title, String author, String genre) {
        this.title = title;
        this.author = author;
        this.genre = genre;
    }

    // removed getter, setters

    @Override
    public String toString() {
        return "Book [title=" + title + ", author=" + author + ", genre="
                + genre + "]";
    }
	
}        </div></pre><br>

    <p>
    Note that @GetMapping("/100") is added in BookRestController below which throws exception and is gracefully handled by error.html page.
    </p>
<div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/books")
public class BookRestController {
	
    private List&lt;Book> books = new ArrayList&lt;>();
        
    public BookRestController() {
        books.add(new Book("The Silence of the Lambs", "Thomas Harris", "Thriller"));
        books.add(new Book("Murder on the Orient Express", "Agatha Christie", "Thriller"));
        books.add(new Book("A Midsummer Night's Dream", "William Shakespeare", "Comedy"));
    }

    @GetMapping("/{id}") 
    public Book get(@PathVariable("id") int id) {
        return books.get(id);
    }
	
    @GetMapping("/100") 
    public void error() {
        throw new IllegalArgumentException("invalid book id");
    }
		
}       </div></pre><br>
    
    <h4>Step 3) Create error.html file and put it under src/main/resources/templates directory</h4>
    <p>
    <code>error.html</code> page serves as the error page for BookServiceApplication. By default all errors are mapped
    to <code>error.html</code> page in Spring Boot, but this behavior can be modified also. Now in the custom error.html page, we can choose what
    error message we want to display to user, for example whether we want to show user frienfly message or actual exception with full stacktrace.
    </p>
        <div id="code">
        <pre class="prettyprint">
&lt;!DOCTYPE html>
&lt;html xmlns:th="http://www.thymeleaf.org">
&lt;head>
    &lt;meta charset="UTF-8">
    &lt;title>Spring Boot Exception Handling example&lt;/title>
&lt;/head>

&lt;body>
    &lt;h1>Failed to process your request&lt;/h1>

    &lt;div>
        &lt;div>
            &lt;span>&lt;strong>Status&lt;/strong>&lt;/span>
            &lt;span th:text="${status}">&lt;/span>
        &lt;/div>
        &lt;div>
            &lt;span>&lt;strong>Error&lt;/strong>&lt;/span>
            &lt;span th:text="${error}">&lt;/span>
        &lt;/div>
        &lt;div>
            &lt;span>&lt;strong>Message&lt;/strong>&lt;/span>
            &lt;span th:text="${message}">&lt;/span>
        &lt;/div>
        &lt;div th:if="${exception != null}">
            &lt;span>&lt;strong>Exception&lt;/strong>&lt;/span>
            &lt;span th:text="${exception}">&lt;/span>
        &lt;/div>
        &lt;div th:if="${trace != null}">
            &lt;span>&lt;strong>Stacktrace&lt;/strong>&lt;/span>
            &lt;span th:text="${trace}">&lt;/span>
        &lt;/div>
		
    &lt;/div>

&lt;/body>
&lt;/html>
        </div>
        </pre>	
        <br>

    <h4>Step 4) Create application.properties file and put it under src/main/resources directory</h4>
    <p>You can hide exception and its stacktrace in the error page by using <b><i>server.error.include-exception</b></i> 
    & <b><i>server.error.include-exception</b></i> flags.<p>
        <div id="code">
        <pre class="prettyprint">
server.port=8080
server.error.include-exception=true
server.error.include-stacktrace=always    </div></pre><br>        
        
        <h4>Directory structure</h4>        
        <div>
            <p><img src="../images/springboot/exception_1.jpg" alt="Directory structure" style="width:300px;height:400px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

 
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
     <h4>Step 5) Testing BookServiceApplication </h4>
     <p>Open any browser and launch</p> <a href="http://localhost:8080/books/100" target="_blank">http://localhost:8080/books/100</a> <p>You will see
     below page.</p>
     
     <div>
         <p><img src="../images/springboot/exception_2.jpg" alt="Maven Build" style="width:800px;height:500px;"></p>
     </div>
        
     <br><br><br><br><br><br><br><br><br>

    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->

        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>