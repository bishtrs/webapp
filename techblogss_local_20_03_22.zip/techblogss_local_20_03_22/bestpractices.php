<?php 
    include("header.htm");
?>

<body>
    <?php 
		include("navigation.htm");
	?>

	<div id="title">	
		<h3>Java</h3>
		<ul id="problems">
			<li><a href="dependencyinjection.php">Prefer to use composition over inheritence.</a></li><br>
            <li><a href="dependencyinjection.php">Prefer to use immutable objects instead of mutable objects.</a></li><br>
			<li><a href="injectMap.php">In multithreaded environment, use ConcurrentHashMap instead of HashMap or Hashtable.</a></li><br>
			<li><a href="beaninheritance.php">Always override toString.</a></li><br>
			<li><a href="beaninheritance.php">Do not use Interface to define constants, instead use enums or Class.</a></li><br>
			<li><a href="beaninheritance.php">Use checked exceptions for conditions from which the caller can recover, else use unchecked exceptions.</a></li><br>
			<li><a href="beaninheritance.php">Always handle an exception that is caught in try catch block, do not skip it.</a></li><br>
			<li><a href="beaninheritance.php">Use standard exception build in Java instead of creating new one for different scenario.</a></li><br>
            <li><a href="avoidnull.php">Try to avoid returning null from methods whenever possible.</a></li><br>
            <li><a href="avoidnull.php">Try to make local variables final unless you are going to modify them.</a></li><br>
            <li><a href="avoidnull.php">Try to make local methods final unless you are going to override them.</a></li><br>
		</ul>
		
		<h3>Spring</h3>
		<ul id="problems">
			<li><a href="dependencyinjection.php">Use constructor injection for mandatory dependencies while use setter injection for optional dependencies.</a></li>
			<br>
			<li><a href="injectMap.php">In multithreaded environment, use ConcurrentHashMap instead of HashMap or Hashtable.</a></li>
			<br>
		</ul>
		
		
	</div>
	
	<div id="content">
		<h3>Below are listed best practices of Java & Spring, click on the topic below to see details.</h3>
		<br>
	</div>	
	
	
</body>
</html>
