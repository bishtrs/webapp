<?php 
    include("header.htm");
?>

<head>
    <title>Factory Design Pattern Java</title>
	<meta name="description" content="Factory Design Pattern Java" />
	<link rel="canonical" href="https://www.techblogss.com/designpatterns/factory-design-pattern" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Factory Design Pattern in Java</h1>
	</div>
    
	<div id="solution">
        <p>
        <b><i>Factory Design Pattern</b></i> is a creational pattern that uses factory methods to create objects without having to specify the 
        exact class of the object that will be created. The <b><i>factory Design Pattern</b></i> encapsulates object creation by letting subclasses
        decide what objects to create.
        </p>
	</div>
    
    <p>Below example shows how to implement <b><i>Factory Design Pattern.</b></i></p>
    <p>First we create an abstract parent  <b><i>Vehicle</b></i> class & then create 3 sub classes Car, Bus, & Truck.</p>    
    <div>
            <p><img src="../images/dp/factory.jpg" alt="Factory" style="width:700px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>    
	<div id="code">
    <pre class="prettyprint">
public abstract class Vehicle {
	
    final String type;
    
    public abstract void start();

    public Vehicle(String type) {
        this.type = type;
    }
	
    public String getType() {
        return this.type;
    }
}</pre>
	</div>
    <br>
  
	
	<div id="code">
		<pre class="prettyprint">
public class Bus extends Vehicle {
	
    public void start() {
    	System.out.println("Bus started");
    }

    public Bus(String type) {
        super(type);
    }
	
}	</pre>
	</div>

    	<div id="code">
		<pre class="prettyprint">
public class Car extends Vehicle {
	
    public void start() {
    	System.out.println("Car started");
    }

    public Car(String type) {
        super(type);
    }
	
}	</pre>
	</div>
    
	<div id="code">
		<pre class="prettyprint">
public class Truck extends Vehicle {
	
    public void start() {
    	System.out.println("Truck started");
    }

    public Truck(String type) {
        super(type);
    }
	
}	</pre>
	</div>  
 <br>
    <p>Now we create an <b><i>abstract factory</b></i> class for  creating <b><i>Vehicle</b></i> type class & then create sub class
    <b><i>VehicleFactory</b></i> which actually creates a Car/Bus/Truck.</p>    
	<div id="code">
		<pre class="prettyprint">
public abstract class AbstractVehicleFactory  {

    public abstract Vehicle createVehicle(String vehicleType);
}	</pre>
	</div>      

<div id="code">
		<pre class="prettyprint">
public class VehicleFactory extends AbstractVehicleFactory {

    public Vehicle createVehicle(String vehicleType) {
        if (vehicleType == null) {
            return null;
        }
        if ("Car".equalsIgnoreCase(vehicleType)) {
            return new Car(vehicleType);
        } else if ("Bus".equalsIgnoreCase(vehicleType)) {
            return new Bus(vehicleType);
        } else if ("Truck".equalsIgnoreCase(vehicleType)) {
            return new Truck(vehicleType);
        }

        return null;
    }
}	</pre>
	</div>  

	<div id="code">
		<pre class="prettyprint">
public class VehicleTest {
	
    public static void main(String[] args) {
    	AbstractVehicleFactory vehicleFactory = new VehicleFactory();
    	Vehicle vehicle = vehicleFactory.createtVehicle("Car");
    	System.out.printf("Vehicle of type %s created ", vehicle.getType());

    	vehicle = vehicleFactory.createtVehicle("Bus");
    	System.out.printf("\nVehicle of type %s created ", vehicle.getType());

    	vehicle = vehicleFactory.createtVehicle("Truck");
    	System.out.printf("\nVehicle of type %s created ", vehicle.getType());

    }
}	</pre>
	</div>    

<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Vehicle of type Car created 
Vehicle of type Bus created 
Vehicle of type Truck created 
	</pre>
	</div>	
    <br>    
<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
	
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>