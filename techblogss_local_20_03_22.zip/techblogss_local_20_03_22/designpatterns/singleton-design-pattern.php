<?php include("../header.htm"); ?>

<head>
    <title>Singleton Design Pattern in Java</title>
    <meta name="description" content="Singleton Design Pattern Java." />
    <link rel="canonical" href="https://www.techblogss.com/designpatterns/singleton-design-pattern" />
</head>

<body>
    <?php include("../navigation.htm");    ?>
       
    <div id="content">
    <div id="blog">
    <div id="problem">
        <h1>Singleton Design Pattern in Java</h1>
    </div>
    
    <div id="solution">
        <p>
        <b><i>Singleton Design Pattern</b></i> is a software design pattern that makes sure you have only one instance of a 
        class in the application or JVM. This is required when creating single instance of thread pool, cache manager,
        logging objects, printer objects, etc.
        </p>
    </div>
       
    
    <h3>1) Implement <i>Singleton Design Pattern</i> with eagerly creating the instance</h3> 
    <p>If your application always creates and uses an instance of the <code>Singleton</code> or there is no overhead in
    creating the instance, you can create your <code>Singleton</code> eagerly, like below.</p>
    
    <div id="code">
        <pre class="prettyprint">
public class Singleton {
    private static Singleton singleton = new Singleton();
    private Singleton() {}
        
    public static Singleton getInstance() {
        return singleton;
    }
}    </pre></div><br>

   <h3>2) Implement <i>Singleton Design Pattern</i> with lazy loading approach</h3> 
   <p>Sometimes the instance creation of a class may be expensive so you can create <code>Singleton</code> instance lazily, like below.</p>
   <p> However if multiple threads call <code>getInstance()</code> they may end up with different instances of <code>Singleton</code> class 
   which we want to avoid.</p>
    
    <div id="code">
        <pre class="prettyprint">
public class Singleton {
    private static Singleton singleton;
    private Singleton() {}
        
   public static Singleton getInstance() {
        if (singleton == null) {
            singleton = new Singleton();
        }
        return singleton;
    }

    public static void main(String[] args) {
        System.out.println(Singleton.getInstance());
        System.out.println(Singleton.getInstance());
    }
}   </pre></div><br>
    <div id="solution">
        <h4>Output : </h4>
    </div>
        
    <div id="code"><pre class="prettyprint">
    Singleton@7852e922
    Singleton@7852e922 </pre></div><br>
  
    <h3>3) Implement <i>Singleton Design Pattern</i> with lazy loading approach and double-checked locking</h3>
    <p>To solve concurreny issue, we will mark the block that creates instance as <code>synchronized</code>. Note that we could have marked
    getInstance() method as <code>synchronized</code> but it will have performance penalty.</p>   
    
    <div id="code">
    <pre class="prettyprint">
public class Singleton {
    private volatile static Singleton singleton;
    private Singleton() {}
        
    public static Singleton getInstance() {
        if (singleton == null) {
            synchronized (Singleton.class) {
                if (singleton == null) {
                    singleton = new Singleton();
                }
            }
        }
        return singleton;
    }
}    </pre></div><br>

   <h3>4) Implement <i>Singleton Design Pattern</i> using enum.</h3> 
   <p>An <code>enum</code> is instantiated only once, hence you can also create an <code>enum</code> to create a Singleton class.</p>
    
    <div id="code">
        <pre class="prettyprint">
public enum SingletonEnum {
    INSTANCE;

    public static void main(String[] args) {
        System.out.println(SingletonEnum.INSTANCE);
        System.out.println(SingletonEnum.INSTANCE);
    }

} </pre></div><br>
    <div id="solution">
        <h4>Output : </h4>
    </div>
        
    <div id="code"><pre class="prettyprint">
    Singleton@7852e922
    Singleton@7852e922 </pre></div><br>

<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>