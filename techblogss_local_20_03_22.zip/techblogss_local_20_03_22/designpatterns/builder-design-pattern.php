<?php include("../header.htm");?>

<head>
    <title>Builder Design Pattern in Java</title>
	<meta name="description" content="Java Builder Design Pattern Java, Builder Design Pattern in Java" />
	<link rel="canonical" href="https://www.techblogss.com/designpatterns/builder-design-pattern" />
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Builder Design Pattern in Java</h1>
	</div>
    
	<div id="solution">
        <p>
        <b><i>Builder Design Pattern</b></i> is a creational design pattern which separates the construction of a complex object from its representation. The builder is generally a static member class of the class it builds.
        </p>
        <p>
        Suppose you have a class with multiple constructors (say more than 4) which take different number of arguments. It is confusing which
        constructor to invoke with which arguments. In this case <b><i>Builder Design Pattern</b></i> makes it easy to identify with what
        parameters we need to create the class object.
        </p>
        <p>
        Another advantage of using <b><i>Builder Design Pattern</b></i> is that it will never leave the object in inconsistent state.
        For example suppose you have multiple Java beans to set the properties, when you create the object and don't set some of the required
        properties, it may leave the object in inconsistent state.
        </p>
	</div>
    
    <h4>1) Below example shows how to implement Builder Design Pattern</h4> 
<p>In Below Pizza class, there are 2 mandatory parameters while there are 4 optional paramters. Each parameter has a cost associated.</p>    
	<div id="code">
    <pre class="prettyprint">
public class Pizza {
        
    private final String size;
    private final String type;        
    
    private final int plain;
    private final int cheese;
    private final int sauce;
    private final int chicken;

    public static class PizzaBuilder {
        private String size;
        private String type;
            
        // Optional parameters
        private int plain;
        private int cheese;
        private int sauce;
        private int chicken;
		
        public PizzaBuilder(String size, String type) {
            this.size = size;
            this.type = type;
        }
		
        public PizzaBuilder plain(int plain) {
            this.plain = plain;
            return this;
        }
                
        public PizzaBuilder cheese(int cheese) {
            this.cheese = cheese;
            return this;
        }
            
                
        public PizzaBuilder chicken(int chicken) {
            this.chicken = chicken;
            return this;
        }
                
        public Pizza build() {
            return new Pizza(this);
        }
    }
	
    private Pizza(PizzaBuilder pizzaBuilder) {
        size = pizzaBuilder.size;
        type = pizzaBuilder.type;    
        plain = pizzaBuilder.plain;
        cheese = pizzaBuilder.cheese;
        sauce = pizzaBuilder.sauce;
        chicken = pizzaBuilder.chicken;
    }
    
    @Override
    public String toString() {
        return "Pizza [size=" + size + ", type=" + type + ", plain=" + plain
            + ", cheese=" + cheese + ", sauce=" + sauce + ", chicken="
            + chicken + "]";
    }    
	
    public static void main(String[] args) {
        Pizza pizza = new Pizza.PizzaBuilder("pan", "thinCrust").plain(10).cheese(20).build();
        System.out.println(pizza);
        pizza = new Pizza.PizzaBuilder("medium", "cheezeBurst").plain(10).chicken(12).build();
        System.out.println(pizza);
    }

} </pre></div><br>
 
<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Pizza [size=pan, type=thinCrust, plain=10, cheese=20, sauce=0, chicken=0]
Pizza [size=medium, type=cheezeBurst, plain=10, cheese=0, sauce=0, chicken=12]		</pre></div>		
	<br>
    
    <p>2) Below example shows how to implement <b><i>Builder Design Pattern</b></i> for class hierarchies.</p> 

           
	<div id="code">
		<pre class="prettyprint">
public abstract class Pizza {
	
    final String size;
    final String type;  

    abstract static class PizzaBuilder {
        String size;
        String type;
        abstract Pizza build();
    }

    Pizza(PizzaBuilder pizzaBuilder) {
        size = pizzaBuilder.size;
        type = pizzaBuilder.type;
    }
}
		</pre>
	</div>


<div id="code">
		<pre class="prettyprint">
public class ItalianPizza extends Pizza {

    private int olives;

    public static class ItalianPizzaBuilder extends Pizza.PizzaBuilder {

        private int olives;

        public PizzaBuilder olives(int olives) {
            this.olives = olives;
            return this;
        }

        @Override
        ItalianPizza build() {
            return new ItalianPizza(this);
        }

        public ItalianPizzaBuilder(String size, String type) {
            this.size = size;
            this.type = type;
        }

    }

    ItalianPizza(ItalianPizzaBuilder italianPizzaBuilder) {
        super(italianPizzaBuilder);
        olives = italianPizzaBuilder.olives;
    }

    @Override
    public String toString() {
        return "ItalianPizza [size=" + size + ", type=" + type + ", olives=" + olives + "]";
    }
	
}

		</pre>
	</div>  

<div id="code">
		<pre class="prettyprint">
public class AustralianPizza extends Pizza {

    private int pepperoni;

    public static class AustralianPizzaBuilder extends Pizza.PizzaBuilder {

        private int pepperoni;

        public PizzaBuilder pepperoni(int pepperoni) {
            this.pepperoni = pepperoni;
            return this;
        }

        @Override
        AustralianPizza build() {
            return new AustralianPizza(this);
        }

        public AustralianPizzaBuilder(String size, String type) {
            this.size = size;
            this.type = type;
        }

    }

    AustralianPizza(AustralianPizzaBuilder italianPizzaBuilder) {
        super(italianPizzaBuilder);
        pepperoni = italianPizzaBuilder.pepperoni;
    }

    @Override
    public String toString() {
        return "AustralianPizza [size=" + size + ", type=" + type + ", pepperoni=" + pepperoni + "]";
    }
	
}
		</pre>
	</div>        

    
    <div id="code">
		<pre class="prettyprint">
public class TestPizzaBuilder {

    public static void main(String[] args) {
        Pizza pizza = new ItalianPizza.ItalianPizzaBuilder("pan", "thinCrust").olives(10).build();
        System.out.println(pizza);
        pizza = new AustralianPizza.AustralianPizzaBuilder("pan", "thinCrust").pepperoni(15).build();
        System.out.println(pizza);
    }
}
	</pre>
	</div>   
    
<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
	
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>