<?php include("../header.htm");?>

<head>
    <title>Java DOM4J parser</title>
	<meta name="description" content="Java DOM4J parser, parse xml using dom4j parser" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_dom4jparser">
</head>

<body>
	<?php include("../navigation.htm");	?>

    <div id="content">
    <div id="blog">
    <div id="problem">
		<h1>How to parse and write XML file using DOM4J parser in Java ?</h1>
	
		<h4>DOM4J is a Java-based library to parse XML documents. You can parse XML file using DOM4J parser as following:</h4>
        First you need to download following jars<br><br>
        <a href="https://mvnrepository.com/artifact/org.dom4j/dom4j/2.1.1">dom4j-2.1.1.jar</a><br><br>
        <a href="https://mvnrepository.com/artifact/jaxen/jaxen/1.2.0">jaxen-1.2.0.jar</a><br><br>
	</div>
	
	<div id="solution">
		XML file that you want to parse: <b>employees.xml</b>
	</div>
	<br>
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
    &lt;employees>
	&lt;employee id="123">
	    &lt;firstname>Mohit&lt;/firstname>
	    &lt;lastname>Bisht&lt;/lastname>
	&lt;/employee>
	&lt;employee id="124">
	    &lt;firstname>Samit&lt;/firstname>
	    &lt;lastname>Ahlawat&lt;/lastname>
	&lt;/employee>
	&lt;employee id="125">
	    &lt;firstname>Vikram&lt;/firstname>
	    &lt;lastname>Raheja&lt;/lastname>
	&lt;/employee>
    &lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Parses XML using DOM4J Parser        
import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

public class TestDOM4J {
    public static void main(String[] args) {
        try {
            File inputFile = new File("C://employees.xml");
            SAXReader reader = new SAXReader();
            Document document = reader.read( inputFile );
            System.out.println("Root element:" + document.getRootElement().getName());

            List&lt;Node&gt; nodes = document.selectNodes("/employees/employee" );
         
            for (Node node : nodes) {
                System.out.println("\nCurrent Element :" + node.getName());
                System.out.println("Employee id : "+ node.valueOf("@id") );
                System.out.println("First Name : " 
                    + node.selectSingleNode("firstname").getText());
                System.out.println("Last Name : "  
                    + node.selectSingleNode("lastname").getText());
         }
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
Root element :employees

Current Element :employee
Employee id : 123
First Name : Mohit
Last Name : Bisht

Current Element :employee
Employee id : 124
First Name : Samit
Last Name : Ahlawat

Current Element :employee
Employee id : 125
First Name : Vikram
Last Name : Raheja

    </pre>
	</div><br><br>

   <div id="problem">
		<h2>Write XML file using DOM4J parser in Java </h2>
	</div>
	
	<div id="solution">
		XML file that you want to create: <b>actors.xml</b>
	</div>
	<br>
	
	<div id="code">
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
&lt;actors>
    &lt;actor type="Action">
        &lt;firstname>Sylvester&lt;/firstname>
        &lt;lastname>Stallone&lt;/lastname>
    &lt;/actor>
    &lt;actor type="Comedian">
        &lt;firstname>Adam&lt;/firstname>
        &lt;lastname>Sandler&lt;/lastname>
    &lt;/actor>
    &lt;actor type="Romantic">
        &lt;firstname>Huge&lt;/firstname>
        &lt;lastname>Grant&lt;/lastname>
    &lt;/actor>
&lt;/actors>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package xml;

//Write XML using DOM4J Parser        
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

public class DOM4JWriteXML {
    public static void main(String[] args) {
        try {
            Document document = DocumentHelper.createDocument();
            Element root = document.addElement("actors");
			
            Element actorElement1 = root.addElement("actor").addAttribute("type", "Action");
            actorElement1.addElement("firstname").setText("Sylvester");
            actorElement1.addElement("lastname").setText("Stallone");
			
            Element actorElement2 = root.addElement("actor").addAttribute("type", "Comedian");
            actorElement2.addElement("firstname").setText("Adam");
            actorElement2.addElement("lastname").setText("Sandler");

            Element actorElement3 = root.addElement("actor").addAttribute("type", "Romantic");
            actorElement3.addElement("firstname").setText("Huge");
            actorElement3.addElement("lastname").setText("Grant");

            OutputFormat format = OutputFormat.createPrettyPrint();
            XMLWriter writer = new XMLWriter(new FileWriter( new File("C://actors.xml")), format);
            writer.write(document);
            writer.close();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Following xml file is generated: </h4>
	</div>
	
<div id="code">
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
&lt;actors>
    &lt;actor type="Action">
        &lt;firstname>Sylvester&lt;/firstname>
        &lt;lastname>Stallone&lt;/lastname>
    &lt;/actor>
    &lt;actor type="Comedian">
        &lt;firstname>Adam&lt;/firstname>
        &lt;lastname>Sandler&lt;/lastname>
    &lt;/actor>
    &lt;actor type="Romantic">
        &lt;firstname>Huge&lt;/firstname>
        &lt;lastname>Grant&lt;/lastname>
    &lt;/actor>
&lt;/actors>
	</pre>
	</div>
    <br>
    
    <?php include("../sidebar/ad.htm"); ?><br>
	
References : <br><br>
<a href="https://dom4j.github.io/" target="_blank">DOM4J</a>	<br><br>

    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
</body>

<?php 
    include("footer.htm");
?>
</html>
