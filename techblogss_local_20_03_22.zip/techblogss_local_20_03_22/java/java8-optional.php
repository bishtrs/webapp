<?php include("../header.htm");?>

<head>
    <title>Java 8 Optional examples for null check</title>
	<meta name="description" content="Optional in Java 8, Optional class in Java 8, Java 8 Optional examples for null check" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-optional" />
</head>

<body>
	<?php include("../navigation.htm");	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h1>Java 8 Optional examples for null check</h1>
        <p>
        An <code>Optional</code> class introduced in Java 8 is used to prevent <code>NullPointerException</code> by acting as a holder
        for an object that may be a <code>null</code> value. There are various methods provided in <code>Optional</code> class which can be used in
        checking <code>null</code> value. Note that if a class attribute is never going to be <code>null</code>, then you don't need to
        use <code>Optional</code>.  
        </p>
	</div>
	
	<div id="solution">
		<h2>1) Optional of(), ofNullable() & empty() example</h2>
        <p>
        You can create an <code>Optional</code> type by using <code>Optional.of()</code> method. But if the value passed is <code>null</code>,
        it will throw <code>NullPointerException</code>. In those scenarios you can use <code>ofNullable()</code> instead.
        Below example hows how to avoid <code>NullPointerException</code> using <code>Optional empty()</code> & <code>ofNullable()</code>.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Java 8 Optional ofNullable() example
import java.util.Optional;

public class TestOptional {

    public static void main(String[] args) {

        Optional&lt;String&gt; fruit = Optional.of("APPLE");

        System.out.println("Non-Empty Optional --> " + fruit);
        System.out.println("Non-Empty Optional: fruit value --> " + fruit.get());

        System.out.println("Empty Optional: " + Optional.empty());

        String fruit2 = "Mango";
        System.out.println("Optional: " + Optional.ofNullable(fruit2));
        
        fruit2 = null;
        System.out.println("Optional: " + Optional.ofNullable(fruit2));
        
        // java.lang.NullPointerException
        System.out.println("Optional: " + Optional.of(fruit2));

    }

}	</pre>
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
 	</div>
	
	<div id="code">
		<pre class="prettyprint">
Non-Empty Optional: fruit value --> APPLE
Empty Optional: Optional.empty
Optional: Optional[Mango]
Optional: Optional.empty
Exception in thread "main" java.lang.NullPointerException
	at java.util.Objects.requireNonNull(Unknown Source)
	at java.util.Optional.<init>(Unknown Source)
	at java.util.Optional.of(Unknown Source)
	at TestOptional.main(TestOptional.java:21)
        </pre>
	</div>	
    <br>
    
	<div id="solution">
		<h2>2) Optional map() example</h2>
        <p>
        <code>map()</code> will check if a value is present and then only will apply function on it, else will return an empty <code>Optional</code>
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Java 8 Optional map() example
import java.util.Optional;

public class TestOptional {

    public static void main(String[] args) {

        Optional&lt;String&gt; fruit = Optional.of("APPLE");
        Optional&lt;String&gt; emptyFruit = Optional.empty();

        System.out.println("Non-Empty Optional:: " + fruit.map(String::toUpperCase));
        System.out.println("Empty Optional    :: " + emptyFruit.map(String::toUpperCase));

    }

}	</pre>
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Non-Empty Optional:: Optional[APPLE]
Empty Optional    :: Optional.empty        </pre>	</div>	 <br>   

		<div id="solution">
		<h2>3) Optional filter(Predicate predicate) example</h2>
       
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Java 8 Optional filter() example
import java.util.Optional;

public class TestOptional {

    public static void main(String[] args) {

        Optional&lt;String&gt; fruit = Optional.of("APPLE");
        Optional&lt;String&gt; emptyFruit = Optional.empty();

        System.out.println(fruit.filter(f -> f.equals("MANGO"))); 
        System.out.println(fruit.filter(f -> f.equalsIgnoreCase("APPLE"))); 
        System.out.println(emptyFruit.filter(f -> f.equalsIgnoreCase("APPLE")));

    }

}	</pre>
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Optional.empty
Optional[APPLE]
Optional.empty
        </pre>	</div>	<br>	
        
	<div id="solution">
		<h2>4) Optional orElse(), orElseGet() & orElseThrow() examples</h2>
     </div>
	
	<div id="code">
	<pre class="prettyprint">
// Java 8 Optional orElse(), orElseGet() & orElseThrow() examples
import java.util.Optional;

public class TestOptional {

    public static void main(String[] args) {

        Optional&lt;String&gt; fruit = Optional.of("APPLE");
        Optional&lt;String&gt; emptyFruit = Optional.empty();

        System.out.println(fruit.orElse("&lt;N/A&gt;")); 
        System.out.println(emptyFruit.orElse("&lt;N/A&gt;")); 
        
        System.out.println(fruit.orElseGet(() -> "&lt;N/A&gt;")); 
        System.out.println(emptyFruit.orElseGet(() -> "&lt;N/A&gt;")); 
        
        System.out.println(fruit.orElseThrow (IllegalArgumentException::new));
        System.out.println(emptyFruit.orElseThrow (IllegalArgumentException::new));

    }

}
	</pre>
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
APPLE
&lt;N/A&gt;
APPLE
&lt;N/A&gt;
APPLE
Exception in thread "main" java.lang.IllegalArgumentException
	at java.util.Optional.orElseThrow(Unknown Source)
	at TestOptional.main(TestOptional.java:18)        </pre>
	</div>	
<br>	
	<div id="solution">
		<h2>5) Optional isPresent(), ifPresent(Consumer consumer) examples</h2>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Java 8 Optional isPresent(), ifPresent() examples
import java.util.Optional;

public class TestOptional {

    public static void main(String[] args) {

        Optional&lt;String&gt; fruit = Optional.of("APPLE");
        
        if (fruit.isPresent()) {
            System.out.println(fruit);
        } else {
            System.out.println("fruit is not available.");
        }

        Optional&lt;String&gt; string = Optional.of(" the quick fox ");
        string.map(String::trim).ifPresent(System.out::println);
        
        Optional&lt;String&gt; emptyFruit = Optional.empty();
        emptyFruit.ifPresent(f -> System.out.println("fruit is not available."));

    }

}	</pre>
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Optional[APPLE]
the quick fox       </pre>
	</div>	    
 <br>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Optional.html" target="_blank">Oracle Docs Optional</a>	<br><br>
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
	
<?php include("footer.htm");?>
	
</body>
</html>
