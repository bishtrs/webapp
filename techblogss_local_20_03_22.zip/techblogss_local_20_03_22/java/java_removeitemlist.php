<?php 
    include("../header.htm");
?>

<head>
    <title>Remove element from ArrayList in Java</title>
	<meta name="description" content="Java remove element from ArrayList in Java while iterating, remove element from ArrayList in Java using Iterator remove(), List remove(), etc. Remove all elements from ArrayList using List clear(), List removeall()" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_removeitemlist">
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
	
	<div id="problem">
		<h2>Examples below show how to remove element from a ArrayList</h2>
         <p>There are various ways of removing an item from a <code>ArrayList</code> type in Java as explained below.</p>
	</div>
    
        <div id="solution">
        <h4>1) Remove element from ArrayList using Java 8</h4>
        <p>Java 8 provides <code>removeIf(Predicate)</code> method in <code>Collection</code> interface that takes <code>Predicate</code> as an argument and it removes all the entries in the <code>ArrayList</code> which match the given <code>Predicate</code>. In below example <code>users.removeIf(u -> u.equals("Harry"));</code> removes the <code>String</code> "Harry" from the <code>ArrayList</code>.</p>
	</div>

	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Removes element from a ArrayList    
public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; users = new ArrayList&lt;String&gt;();
        users.add("Harry");
        users.add("IronMan");
        users.add("Batman");
        
        users.removeIf(u -> u.equals("Harry"));
        
        System.out.println("users " + users);
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
users [IronMan, Batman]		</pre></div>	
    
    <br>

    <div id="solution">
        <h4>2) Remove element from ArrayList while iterating using Iterator remove()</h4>
        <p>While looping over an <code>ArrayList</code>, it is recommended to use <code>Iterator remove()</code> for removing an element from <code>ArrayList</code> as you will not get <code>ConcurrentModificationException</code>. If the underlying <code>ArrayList</code> is modified while removing the element, then the results are not predictable.</p>

	</div>

	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Removes element from a List    
public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; users = new ArrayList&lt;String&gt;();
        users.add("Harry");
        users.add("IronMan");
        users.add("Batman");
        
        Iterator&lt;String&gt; itr = users.iterator();
        
        while (itr.hasNext()) {
            String user = itr.next();
            if (user.equalsIgnoreCase("Harry")) {
               itr.remove(); // Remove entry from ArrayList
            }
        }
		
        System.out.println("users " + users);
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
users [IronMan, Batman]		</pre></div><br>	
	
	<p>Code below throws <code>ConcurrentModificationException</code></p>
    
    <div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Removes element from a List    
public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; users = new ArrayList&lt;String&gt;();
        users.add("Harry");
        users.add("IronMan");
        users.add("Batman");
        
        for (String user : users) {
            if (user.equalsIgnoreCase("Harry")) {
                users.remove(user);
            }
        }
		
        System.out.println("users " + users);
    }
}	</pre></div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">Exception in thread "main" java.util.ConcurrentModificationException
	at java.util.ArrayList$Itr.checkForComodification(Unknown Source)
	at java.util.ArrayList$Itr.next(Unknown Source)
	at MyClass.main(MyClass.java:12)		</pre></div>	
    
    <br>

    
	<div id="solution">
		<h4>3) Using List remove(int index)</h4>
        <p>
        You can remove element from <code>ArrayList</code> by using <code>List remove(int index)</code> method. It will use the index at which the element is stored in the <code>ArrayList</code> to remove the element. Below example shows how to remove entry from List using <code>List remove(int index)</code> method.
        </p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

// Removes entry from ArrayList	using remove()
public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; celebrities = new ArrayList&lt;String&gt;();
        celebrities.add("Harry");
        celebrities.add("IronMan");
        celebrities.add("Batman");
        celebrities.remove(1); // Remove entry from ArrayList
		
        System.out.println("celebrities " + celebrities);
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
celebrities [Harry, Batman]	</pre></div><br>

	<div id="solution">
		<h4>4) Using List remove(Object object)</h4>
        <p>You can remove element from <code>ArrayList</code> by using <code>List remove(Object object)</code> method. It checks the existence of element by using: <code>Object equals()</code> and removes the first element that matches the element in <code>ArrayList</code>.<br>
        Below example shows how to remove entry from List using <code>List remove(Object object)</code> method.</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

// Removes element from ArrayList using List remove(Object object)		
public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; celebrities = new ArrayList&lt;String&gt;();
        celebrities.add("Harry");
        celebrities.add("IronMan");
        celebrities.add("Batman");
        celebrities.remove("Harry"); // Remove entry from ArrayList
        celebrities.forEach(System.out::println);
    }
}	</pre></div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
IronMan
Batman		</pre></div><br>

    <div id="solution">
        <h4>5) Remove all elements from ArrayList using List removeAll()</h4>
		<p>
        You can remove all elements from <code>ArrayList</code> by using <code>List removeAll()</code> method. It removes all of the elements from the <code>ArrayList</code>. <code>List removeAll()</code> has time complexity of O(N^2)Below example shows how to remove all the elements from a List using <code>List removeAll()</code> method.
        </p>
	</div>

	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

// Remove all elements from ArrayList    
public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; users = new ArrayList&lt;String&gt;();
        users.add("Harry");
        users.add("IronMan");
        users.add("Batman");
        
        users.removeAll(users);
		
        System.out.println("users " + users);
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
users []		</pre></div>
	

	<br>
	   <div id="solution">
        <h4>6) Remove all elements from ArrayList using List clear()</h4>
		<p>
        You can remove element from <code>ArrayList</code> by using <code>List clear()</code> method. It removes all of the elements from the list . The list will be empty after this call returns. List clear() has time complexity of O(N). Below example shows how to remove all the elements from a <code>ArrayList</code> using <code>List clear()</code> method.
        </p>
	</div>

	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

// Remove all elements from ArrayList    
public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; users = new ArrayList&lt;String&gt;();
        users.add("Harry");
        users.add("IronMan");
        users.add("Batman");
        
        users.clear();
		
        System.out.println("users " + users);
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
users []		</pre></div><br>
	

    

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/List.html#remove-int-" target="_blank">Oracle Docs List remove()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html#remove--" target="_blank">Oracle Docs Iterator remove()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/List.html#remove-java.lang.Object-" target="_blank">Oracle Docs List remove(Object object) </a> <br><br>	
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/List.html#removeAll-java.util.Collection-" target="_blank">Oracle Docs List removeAll()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/List.html#clear--" target="_blank">Oracle Docs List clear() </a> <br><br>	

    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
<?php include("share.htm"); ?>

 </body>

<?php 
    include("footer.htm");
?>	

</html>
