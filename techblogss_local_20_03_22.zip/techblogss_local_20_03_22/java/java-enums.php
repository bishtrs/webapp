<?php include("../header.htm"); ?>

<head>
    <title>Java enum with values</title>
	<meta name="description" content="How to use enum in java, java enum examples with values, enums with constructors, comparing enums, enums with switch case, convert enum to string" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-enums" />
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Java enum with values</h1>
        <p>Enums help in reducing defects by restricting the type of value a variable can hold. Enums typically hold only few types of values. For example if you declare an <code>enum</code> below, you will observe that WeekDay <code>enum</code> can have values as days of a week that can be accessed like WeekDay.MONDAY. An <code>enum</code> like WeekDay.MONDAY is neither an int or String, its just an instance of WeekDay class.
        </p>
        <div id="code"><pre class="prettyprint"> enum WeekDay { MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY };</pre></div>
    </div><br>
   
	<div id="solution">
		<h4>1) Declaring private enum with no behavior</h4>
        <p>An <code>enum</code> can be created inside a class but not inside a class method.  You can iterate through an <code>enum</code> values using <code>values()</code> method.</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
//Java enum example    
public class Test {
    private enum WeekDay { MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY,
        SATURDAY, SUNDAY };
    
    public static void main(String[] args) {
        System.out.println(WeekDay.MONDAY);
        
        // iteratos and prints all enum values
        for (WeekDay day : WeekDay.values()) {
            System.out.println(day); 
        } 
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
MONDAY
MONDAY
TUESDAY
WEDNESDAY
THURSDAY
FRIDAY
SATURDAY
SUNDAY		</pre></div><br>
	
    <div id="solution">
		<h4>2) Declaring public enum with no behavior</h4>
        <p>
        An <code>enum</code> can be created outside a class but with only <code>public</code> or <code>default</code> access modifier. Also note that semicolon after closing brace is optional.
        </p>
	</div>
	<div id="code">
	<pre class="prettyprint">
//Java enum example    
public enum WeekDay { MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY }; 

public class Test {
    
    public static void main(String[] args) {
        for (WeekDay day : WeekDay.values()) {
            System.out.println(day); 
        } 
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
MONDAY
TUESDAY
WEDNESDAY
THURSDAY
FRIDAY
SATURDAY
SUNDAY		</pre></div><br>
	

    <div id="solution">
		<h4>3) Public enum with data and behavior. </h4>
        <p>
         Apart from the enum values, you might want to associate an <code>enum</code> with other kind of value, for example you may wish to associate each weekday with a number say 1 for Monday, 2 for Tuesday, etc. For this type of scenario, you can create an instance variable in the <code>enum</code> say dayNumber which can hold this value. This instance value will be set in the <code>enum</code> constructor, however you do not need to call the <code>enum</code> constructor explicitly. You can retrieve this value by exposing a getter method.
        </p>
	</div>
	<div id="code">
	<pre class="prettyprint">
//java enum constructor example , java enum example with values   
public enum WeekDay { MONDAY(1), TUESDAY(2), WEDNESDAY(3), THURSDAY(4), FRIDAY(5),
        SATURDAY(6), SUNDAY(7);
   
    private final int dayNumber;
	
    WeekDay(int dayNumber) {
        this.dayNumber = dayNumber ;
    } 
	
    public int getDayNumber() {
        return this.dayNumber; 
    } 
}
	
public class Test {
    public static void main(String[] args) {
        for (WeekDay day : WeekDay.values()) { 
            System.out.println(day +" : " +day.getDayNumber());
        }
    }			
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
MONDAY : 1
TUESDAY : 2
WEDNESDAY : 3
THURSDAY : 4
FRIDAY : 5
SATURDAY : 6
SUNDAY : 7		</pre></div><br>

	<div id="solution">
		<h4>4) Java compare enum values example</h4>
        <p>You can compare two enums either by using <code>enum</code> reference or by calling <code>equals()</code> on the <code>enum</code>. An enum <code>equals()</code> method will internally use == only. However if the reference variable is null and <code>equals()</code> is invoked on reference variable, then <code>equals()</code> will throw <code>NullPointerException</code>.</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
//compare enum values    
public class CompareEnums {
    private enum Color { BLUE, GREEN, YELLOW, ORANGE};
    
    public static void main(String[] args) {
    	Color color = Color.BLUE;

    	if (color == Color.BLUE) {
            System.out.println("color == Color.BLUE " + true);
    	}
    	
    	if (color.equals(Color.BLUE)) {
            System.out.println("color.equals(Color.BLUE) " + true);
    	}

    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
color == Color.BLUE true
color.equals(Color.BLUE) true		</pre></div><br>
	
	<div id="solution">
		<h4>5) Java enum switch case example</h4>
        <p>You can also use <code>enum</code> in switch case statment to check values.</p>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
//enum switch case example   
public class Test {
    private enum WeekDay { MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY,
        SATURDAY, SUNDAY };
    
   public static void main(String[] args) {
    	WeekDay day = WeekDay.MONDAY;

    	switch (day) {
            case MONDAY:
                System.out.println("This is MONDAY");
                break;
            case TUESDAY:
                System.out.println("This is TUESDAY");
                break;
            case WEDNESDAY:
                System.out.println("This is WEDNESDAY");
                break;
            default:
                throw new AssertionError("Invalid WeekDay " + day);
    }
}	</pre></div>
	
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">This is MONDAY		</pre>	</div><br>
    
	<div id="solution">
		<h4>6) Java EnumMap example</h4>
        <p>
        An <code>EnumMap</code> is a special <code>Map</code> which has key as enum type. All the keys are of same <code>enum</code> type and <code>EnumMap</code> maintains the order by the natural order of the key. Below example shows how to create an <code>EnumMap</code>.
        </p>
	</div>
        
	<div id="code">
	<pre class="prettyprint">
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;


public class EnumMapTest {
	
    public enum PLANET { MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE, PLUTO };
    public enum TYPE { ROCKY, GAS, ICE};

    public static void main(String[] args) {
        EnumMap&lt;PLANET, String> planetColorMap = new EnumMap<>(PLANET.class);
        planetColorMap.put(PLANET.MERCURY, "GREY");
        planetColorMap.put(PLANET.VENUS, "YELLOW");
        planetColorMap.put(PLANET.EARTH, "BLUE");
        planetColorMap.put(PLANET.MARS, "BROWN");
        System.out.println(planetColorMap);
		
        planetColorMap.forEach((k,v)->System.out.printf("key = %s :: value = %s %n", k, v));
		
        EnumMap&lt;PLANET, TYPE> planetTypeMap = new EnumMap<>(PLANET.class);
        planetTypeMap.put(PLANET.MERCURY, TYPE.ROCKY);
        planetTypeMap.put(PLANET.EARTH, TYPE.ROCKY);
        planetTypeMap.put(PLANET.JUPITER, TYPE.GAS);
        System.out.println(planetTypeMap);
		
        planetTypeMap.forEach((k,v)->System.out.printf("key = %s :: value = %s %n", k, v));
		
    }

}	</pre>	</div><br>
	
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{MERCURY=GREY, VENUS=YELLOW, EARTH=BLUE, MARS=BROWN}
key = MERCURY :: value = GREY 
key = VENUS :: value = YELLOW 
key = EARTH :: value = BLUE 
key = MARS :: value = BROWN 
{MERCURY=ROCKY, EARTH=ROCKY, JUPITER=GAS}
key = MERCURY :: value = ROCKY 
key = EARTH :: value = ROCKY 
key = JUPITER :: value = GAS 		</pre></div>  <br>

    <div id="solution">
		<h4>7) Convert Enum to String using String()</h4>
        <p>
        Below example shows how to convert <b><i>Enum</b></i> to <b><i>String</b></i>. By default <b><i>Enum</b></i> name is printed when you print enum (by using name() method). But if you implement <code>toString()</code> method in an <b><i>Enum</i></b>, you can override default behavior and the description of <b><i>Enum</i></b> will be printed which is same as the one returned by to <code>toString()</code> method.
        </p>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
// converts enum to string    
public class Test {
    private enum LOB { 
        AWM {
            @Override
            public String toString() {
                return "Asset & Wealth Management";
            }
        },
        WM {
            @Override
            public String toString() {
                return "Wealth Management";
            }
        },
        CIB {
            @Override
            public String toString() {
                return "Consumer & Invetment banking";
            }
        },
        CCB {
            @Override
            public String toString() {
                return "Consumer and coporate banking";
            }
        }
    }
    
   public static void main(String[] args) {
        System.out.println(LOB.AWM);
        System.out.println(LOB.WM);
        System.out.println(LOB.CIB);
        System.out.println(LOB.CCB);
    }
}	</pre></div>
	
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Asset & Wealth Management
Wealth Management
Consumer & Invetment banking
Consumer and coporate banking		</pre></div><br>
    
    <div id="solution">
		<h4>8) Convert Enum to String using constructor</h4>
        <p>Another way to convert <code>Enum</code> to <code>String</code> is by keeping the enum description in a String variable that will be instantiated when enum constructor is invoked. Below is another example that shows how to convert <code>Enum</code> to <code>String</code>. </p>
	</div>
        
	<div id="code">
	<pre class="prettyprint">
// converts enum to string    
public class Test {
    private enum LOB { 
        AWM ( "Asset & Wealth Management"),
        WM ("Wealth Management"),
        CIB ("Consumer & Invetment banking"),
        CCB ("Consumer and coporate banking");
    
        private String description;
        
        private LOB(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
   public static void main(String[] args) {
        System.out.println(LOB.AWM);
        System.out.println(LOB.WM);
        System.out.println(LOB.CIB);
        System.out.println(LOB.CCB);
    }
}	</pre></div><br>	
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Asset & Wealth Management
Wealth Management
Consumer & Invetment banking
Consumer and coporate banking		</pre>	</div>	    <br>

<div id="solution">
		<h4>9) Convert String to Enum using valueOf()</h4>
        <p>Sometimes its required to look up an <code>Enum</code> by using its corresponding string value. This can be done by using <code>valueOf</code> method in <code>Enum</code>. Below example shows how to convert <code>String</code> to <code>Enum</code>. </p>
	</div>
    
    
	<div id="code">
	<pre class="prettyprint">
// converts enum to string    
public class Test {
    private enum LOB { 
        AWM ( "Asset & Wealth Management"),
        WM ("Wealth Management"),
        CIB ("Consumer & Invetment banking"),
        CCB ("Consumer and coporate banking");
    
        private String description;
        
        private LOB(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
   public static void main(String[] args) {
        System.out.println(LOB.valueOf("AWM"));
        System.out.println(LOB.valueOf("WM"));
        System.out.println(LOB.valueOf("CIB"));
        System.out.println(LOB.valueOf("CCB"));
    }
}	</pre>	</div>
	
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
AWM
WM
CIB
CCB		</pre></div><br>	

       
      <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
    References:<br><br>
    <a href ="https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html">https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html</a><br><br>
    <a href ="https://docs.oracle.com/javase/8/docs/api/java/util/EnumMap.html">Oracle Docs EnumMap</a>
	
     </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>	
</body>

<?php 
    include("footer.htm");
?>

</html>
