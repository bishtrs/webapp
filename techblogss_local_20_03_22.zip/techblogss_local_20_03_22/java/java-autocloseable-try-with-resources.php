<?php include("../header.htm");?>

<head>
    <title>Java Autocloseable try with resources</title>
	<meta name="description" content="Java Autocloseable try with resources" />
	<link rel="canonical" href="https://www.techblogss.com/java/java-autocloseable-try-with-resources" />
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
   	<div id="content">
	<div id="blog">
	
	<div id="problem">
		<h1>Java Autocloseable try-with-resources</h1>
        <p>Java <b><i>try-with-resources</b></i> was introduced with Java 7. Using <b><i>try-with-resources</b></i>, you can get rid of resource 
        clean up in finally block. For example if you use <b><i>try-with-resources</b></i>, you no longer need to add finally block to close a 
        <code>BufferedReader</code>.</p>
	</div> 
    
    <div id="solution">
    <h2>1) try-with-resources in java 7, example of BufferedReader</h2>
    <p>
    <ul>
        <li>
        Note that in below example closing of resources (<code>BufferedReader</code>) is not required in finally block. When the try block
        finishes the <code>BufferedReader</code> will be closed automatically. In earlier versions of Java before JDK 1.7, the  was done using
        the finally block.
        </li>
        <li>
        Above is possible because <code>BufferedReader</code> implements the Java interface <code>java.lang.AutoCloseable</code>.
        All classes implementing  this interface can be used inside the try-with-resources construct.
        </li>
    </ul>
    </p>
    </div>
    
    <h4>Before Java 7</h4>
	<div id="code">
    <pre class="prettyprint">	
// Before Java 7, you had to close BufferedReader manually in finally block.

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MyClass {
    public static void main(String[] args) {
        String filePath = "C://File.txt";  
        BufferedReader br = null;
        try {
            br =  new BufferedReader(new FileReader(filePath)); 
            String s; 
            while ((s = br.readLine()) != null) {
                System.out.println(s); 
            } 
        } catch (IOException e) { 
            e.printStackTrace(); 
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }          
    }
}</pre>	</div>

<h4>try-with-resources in Java 7</h4>

<div id="code">
    <pre class="prettyprint">
/*In Java 7, with try-with-resources, BufferedReader will be closed automatically after try block. */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MyClass {
    public static void main(String[] args) {
        String filePath = "C://File.txt";  
        // try-with-resources statement is logically calling a finally block to close the reader.
        try (BufferedReader b = new BufferedReader(new FileReader(filePath))) {
            String s; 
            while ((s = b.readLine()) != null) {
                System.out.println(s); 
            } 
        } catch (IOException e) { 
            e.printStackTrace(); 
        } 
        // BufferedReader will be closed automatically        
    }
}    </pre>	</div> <br>
	
    <div id="solution">
    <h2>2) try with multiple resources in java, example of JDBC Connection & PreparedStatement</h2>
    <p>
    <ul>
        <li>
        Note that in below example closing of resources (Connection & PreparedStatement) is not required in finally block. When the try block finishes the <code>Connection & PreparedStatement</code> will be closed automatically. In earlier versions of Java before JDK 1.7, the  was done using the finally block.
        </li>
        <li>
        Above is possible because <code>Connection & PreparedStatement</code> implement the Java interface java.lang.AutoCloseable. All classes
        implementing this interface can be used inside the try-with-resources construct.
        </li>
    </ul>
    </p>
    </div>

<h4>Before Java 7</h4>
	<div id="code">
    <pre class="prettyprint">

// Before Java 7, you had to close Connection & PreparedStatement manually in finally block.

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MyClass {
    public static void main(String[] args) {
        Connection connection = null;
        PreparedStatement  ps  = null;
        String url, user, pwd; 
        
        try {
            connection = DriverManager.getConnection(url, user, pwd);
            ps = connection.prepareStatement("SELECT UnitPrice from Book WHERE Title LIKE ?");
            ps.setString(1, "%Java%");
            ResultSet rs = ps.executeQuery();
            // ... process the results
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }     
               
    }
    
}

</pre>
	</div>

    <h4>try with multiple resources in Java 7</h4>
    <div id="code">
    <pre class="prettyprint">
/*In Java 7, with try with resources, Connection & PreparedStatement will be closed automatically after try block. */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MyClass {
    public static void main(String[] args) {
        Connection connection = null;
        PreparedStatement  ps  = null;
        String url, user, pwd; 
        
        try {
            connection = DriverManager.getConnection(url, user, pwd);
            ps = connection.prepareStatement("SELECT UnitPrice from Book WHERE Title LIKE ?");
            ps.setString(1, "%Java%");
            ResultSet rs = ps.executeQuery();
            // ... process the results
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
        // Connection & PreparedStatement will be closed automatically         
    }
}    </pre>	</div>    <br>

<h4>3) Usual try block</h4>
    <p>The actual try block still works the same way, i.e. if you don't use <b><i>try-with-resources</b></i>, you still need catch or finally block. Below code will not work.</p>
    <div id="code">
		<pre class="prettyprint">
try {
    // access a file
}    </pre></div><br>

<h4>4) Implementing AutoCloseable interface</h4>
    <p>You can't instantiate any Class inside <b><i>try-with-resources</b></i>, for example below code will not compile.</p>
    <div id="code">
		<pre class="prettyprint">
try (String str = new String("")) {
}    </pre></div><br>

    <div id="solution">
    <p>
    If you want to perform code cleanup for your class, then that class must implement <code>AutoCloseable</code> interface as shown below.
    <code>AutoCloseable</code> interface has only one method close() which throws Exception. Any resource cleaup should be performed inside
    this method.
    </p>
    </div>
		
<div id="code">
		<pre class="prettyprint">
public class MyResource implements AutoCloseable {
	
    public void print() {
        System.out.println("print called");
    }
	
    @Override
    public void close() throws Exception {
        System.out.println("closed");
    }
	
    public static void main(String[] args) {
        try (MyResource myResource = new MyResource()) {
            myResource.print();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}  </pre></div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
print called
closed
</pre></div><br><br>

	  <!-- ADU1 -->
	<?php include("../sidebar/ad.htm"); ?>
    
    References : <a href="https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html" target="_blank">https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html</a>
	
	
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->


    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>	
</body>

<?php 
    include("footer.htm");
?>
</html>
