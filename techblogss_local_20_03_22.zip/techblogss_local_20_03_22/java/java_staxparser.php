<?php 
    include("../header.htm");
?>

<head>
    <title>StAX parser example</title>
	<meta name="description" content="StAX parser example, stax parser vs sax parser, write xml file in Java using StAX parser" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_staxparser">
</head>


<body>
	<?php 
		include("navigation.htm");
	?>

    <div id="content">
	<div id="blog">
    <div id="problem">
		<h1>StAX parser example</h1>
	    <p>
        <b><i>StAX</b></i> stands for Streaming API for XML. Traditionally, XML APIs are either <b><i>DOM</b></i> based (e.g. DOM Parser) or event based (e.g. SAX parser). <b><i>StAX</b></i> was designed as a median between these two opposites. <b><i>StAX</b></i> uses streaming pull mechanism to parse XML, in which a client application calls methods on an XML parsing library when it needs to interact with an XML infoset--that is, the client only gets (pulls) XML data when it explicitly asks for it.
        </p>
        
        <h3>StAX vs SAX parser</h3>
        
         <ul>
            <li><b><i>StAX</b></i> parser uses streaming pull parsing mechanism while SAX uses streaming push parsing mechanism to parse XML documents.</li>
			<li><b><i>StAX</b></i> parser can be used to read and write XML documents while SAX can be used only to read XML documents.</li>
            <li><b><i>StAX</b></i> parser has no support for Schema Validation while SAX Parser provides support for schema validation.</li>
        </ul>
		<h4>You can parse XML file using StAX parser as show below:</h4>
	</div>

	<div id="solution">
		XML file that you want to parse: <b>employees.xml</b>
	</div>
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
    &lt;employees>
	&lt;employee id="123">
	    &lt;firstname>Mohit&lt;/firstname>
	    &lt;lastname>Bisht&lt;/lastname>
	&lt;/employee>
	&lt;employee id="124">
	    &lt;firstname>Samit&lt;/firstname>
	    &lt;lastname>Ahlawat&lt;/lastname>
	&lt;/employee>
	&lt;employee id="125">
	    &lt;firstname>Vikram&lt;/firstname>
	    &lt;lastname>Raheja&lt;/lastname>
	&lt;/employee>
    &lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Parses XML using StAX Parser    
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Iterator;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class StaxParserTest {
    public static void main(String[] args) {
        boolean bFirstName = false;
        boolean bLastName = false;
      
      try {
         XMLInputFactory factory = XMLInputFactory.newInstance();
         XMLEventReader eventReader =
         factory.createXMLEventReader(new FileReader("C://employees.xml"));

         while(eventReader.hasNext()) {
            XMLEvent event = eventReader.nextEvent();
               
            switch(event.getEventType()) {
               
               case XMLStreamConstants.START_ELEMENT:
                  StartElement startElement = event.asStartElement();
                  String qName = startElement.getName().getLocalPart();

               if (qName.equalsIgnoreCase("employee")) {
                  System.out.println("Start Element : employee");
                  Iterator&lt;Attribute&gt; attributes = startElement.getAttributes();
                  String id = attributes.next().getValue();
                  System.out.println("Id : " + id);
               } else if (qName.equalsIgnoreCase("firstname")) {
                  bFirstName = true;
               } else if (qName.equalsIgnoreCase("lastname")) {
                  bLastName = true;
               } 
               break;

               case XMLStreamConstants.CHARACTERS:
                  Characters characters = event.asCharacters();
               if(bFirstName) {
                  System.out.println("First Name: " + characters.getData());
                  bFirstName = false;
               }
               if(bLastName) {
                  System.out.println("Last Name: " + characters.getData());
                  bLastName = false;
               }
               break;

               case XMLStreamConstants.END_ELEMENT:
                  EndElement endElement = event.asEndElement();
                  
               if(endElement.getName().getLocalPart()
                   .equalsIgnoreCase("employee")) {
                  System.out.println("End Element : employee");
                  System.out.println();
               }
               break;
            } 
         }
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      } catch (XMLStreamException e) {
         e.printStackTrace();
      } 
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
Start Element : employee
Id : 123
First Name: Mohit
Last Name: Bisht
End Element : employee

Start Element : employee
Id : 124
First Name: Samit
Last Name: Ahlawat
End Element : employee

Start Element : employee
Id : 125
First Name: Vikram
Last Name: Raheja
End Element : employee    </pre></div><br>

    <div id="problem">
		<h1>How to write xml file in Java using StAX parser</h1>
        
		<h4>Below example shows how to write xml file in Java using StAX parser</h4>
	</div>
    
	<div id="solution">
		XML file that you want to generate: <b>employees.xml</b>
	</div>
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
    &lt;employees>
	&lt;employee id="123">
	    &lt;firstname>Peter&lt;/firstname>
	    &lt;lastname>Parker&lt;/lastname>
	&lt;/employee>
	&lt;employee id="124">
	    &lt;firstname>Harry&lt;/firstname>
	    &lt;lastname>Potter&lt;/lastname>
	&lt;/employee>
    &lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// WRite XML using StAX Parser    
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;


public class StaxParserTest {
    public static void main(String[] args) {
   
        try {
            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter writer = factory.createXMLStreamWriter(
                new FileWriter("C://employees.xml"));

            writer.writeStartDocument();
            writer.writeStartElement("employees");
      
            writer.writeStartElement("employee");

            writer.writeAttribute("id", "123");
            writer.writeStartElement("firstname");
            writer.writeCharacters("Peter");
            writer.writeEndElement();
          
            writer.writeStartElement("lastname");
            writer.writeCharacters("Parker");
            writer.writeEndElement();
            writer.writeEndElement();
          
            writer.writeStartElement("employee");

            writer.writeAttribute("id", "124");
            writer.writeStartElement("firstname");
            writer.writeCharacters("Harry");
            writer.writeEndElement();
          
            writer.writeStartElement("lastname");
            writer.writeCharacters("Potter");
            writer.writeEndElement();

            writer.writeEndElement();
            writer.writeEndDocument();

            writer.flush();
            writer.close();

        } catch (IOException | XMLStreamException e) {
            e.printStackTrace();
        } 
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Generated XML : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" ?&gt;&lt;employees&gt;
&lt;employee id="123"&gt;
&lt;firstname&gt;Peter&lt;/firstname&gt;
&lt;lastname&gt;Parker&lt;/lastname&gt;
&lt;/employee&gt;
&lt;employee id="124"&gt;
&lt;firstname&gt;Harry&lt;/firstname&gt;
&lt;lastname&gt;Potter&lt;/lastname&gt;
&lt;/employee&gt;
&lt;/employees&gt;
    </pre>
	</div>

        <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
References : <a href="https://docs.oracle.com/cd/E17802_01/webservices/webservices/docs/1.6/tutorial/doc/SJSXP2.html">StAX parsing</a>    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
    
</body>

<?php 
    include("footer.htm");
?>
</html>
