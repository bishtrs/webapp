<?php include("../header.htm");?>

<head>
    <title>JSON schema validation in Java</title>
    <meta name="description" content="json schema validation in java" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-json-schema-validation">
</head>

<body>
    <?php include("../navigation.htm");?>
    
    <div id="content">
    <div id="blog">
    <div id="problem">
        <h2>JSON schema validation in Java</h2>
    </div>
    
    <div id="solution" style="text-align: justify;">
        <p>
        Sometimes it is required to validate <code>JSON</code> objects before the processing as it helps in catching error early and to make sure
        valid data is received by application. You can validate a <code>JSON</code> object by providing <code>JSON</code> schema definition and then using
        it in Java.
        </p>
        <p>
        In this example we will show how to validate a <code>JSON</code> object using Java. We will use <code>org.everit.json.schema</code> library
        to validate <code>JSON</code> object. You can check list of <code>JSON</code> types that can be used by <code>JSON</code> schema here  
        </p>
        <a href="https://cswr.github.io/JsonSchema/spec/basic_types/">JSON Schema types</a> 
    </div><br>
    
    <p>First you need to download below dependencies</p>
<div id="code">
    <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.everit.json&lt;/groupId>
    &lt;artifactId>org.everit.json.schema&lt;/artifactId>
    &lt;version>1.11.1&lt;/version>
&lt;/dependency>

&lt;dependency>
    &lt;groupId>org.json&lt;/groupId>
    &lt;artifactId>json&lt;/artifactId>
    &lt;version>20160810&lt;/version>
&lt;/dependency>    </pre></div></br>
    
    <p>Below is the JSON data & schema to validate the JSON</p>
    <div id="code">    
    <pre class="prettyprint">
{
    "id":12345, 
    "name":"Huge Grant",
    "age":35,
    "profession":"Actor"
}</pre></div><br>

<div id="code">    
    <pre class="prettyprint">
{
    "$schema": "http://json-schema.org/draft-07/schema",
    "title" : "Person",
    "type": "object",
    "properties": {
        "id": {"type": "integer", "minLength": 4, "maxLength": 64},
        "name": {"type": "string"},
        "age": {"type": "integer", "minimum": 18},
        "profession": {"type": "string", "enum": ["Actor","Professor"]}
    },
    "required": ["id", "name"]
}    </pre></div><br>

    <p>
        <ul>
            <li><code>$schema</code> keyword describes specification version 7</li>
            <li><code>$title</code> keyword describes json</li>
            <li><code>$type</code> means its a JSON object</li>
            <li><code>$properties</code> defined that array of properties in JSON</li>
            <li><code>$required</code> means these proeprties are mandatory in JSON</li>
        </ul>
    </p><br>

    <div id="solution">
        <h4>Validating JSON in Java</h4>
        <p>Below example shows how to validate a JSON object in Java</p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
package json;

import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonValidator {

    public static void main(String[] args) {
        JSONObject jsonSchema = new JSONObject(new JSONTokener(
            JsonValidator.class.getResourceAsStream("/schema.json")));
        JSONObject jsonData = new JSONObject(new JSONTokener(
            JsonValidator.class.getResourceAsStream("/data.json")));

        Schema schema = SchemaLoader.load(jsonSchema);
        try {
            schema.validate(jsonData);
        } catch (ValidationException e) {
            System.out.println("schema validation failed");
            e.printStackTrace();
        }
        System.out.println("schema validated successfully");
        
    }

}    </pre></div>
    
    <div id="solution">
        <h4>Console Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">schema validated successfully    </pre></div><br>

    <p>Suppose you pass invalid value in json data "profession":"Actors" instead of "profession":"Actor", code will throw below
    Exception</p>
    <div id="code">
        <pre class="prettyprint">
schema validation failed
org.everit.json.schema.ValidationException: #/profession: Actors is not a valid enum value
at org.everit.json.schema.ValidationException.prepend (ValidationException.java:333)
at org.everit.json.schema.ValidationException.prepend (ValidationException.java:312)    </pre></div>
    
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
</body>

<?php 
    include("footer.htm");
?>

</html>
