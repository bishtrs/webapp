<?php include("../header.htm");?>

<head>
    <title>Try catch multiple Exceptions in Java</title>
    <meta name="description" content="Try catch multiple Exceptions in Java" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_trycatchmultiple" />
</head>

<body>
    <?php include("../navigation.htm");?>
       
       <div id="content">
    <div id="blog">
    
    <div id="problem">
        <h1>Try catch multiple Exceptions in Java</h1>
        <p>
        Sometimes we want to process various kinds of <code>Exceptions</code> in the same way, for example simply printing stack trace or
        do some logging. In this scenario we don't want to execute same code again and again. Prior to Java 7, we had to handle each exception
        in its catch block as shown below.
        </p>
    </div>

    <h4>1) Prior to Java 7</h4>

    <div id="code">
    <pre class="prettyprint">

//  Prior to Java 7, you had to add one catch block to handle one exception
public class TestClass {
    public static void main(String[] args)  {
        try {
            int array[] = new int[5];
            array[5] = 10/0; 
        } catch (ArithmeticException ae) {
            ae.printStackTrace();
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        } 
    }
}    </pre></div>
    
    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">
java.lang.ArithmeticException: / by zero
    at MyClass.main(MyClass.java:5)        </pre></div><br>

    <h4>2) Java 7 multi-catch</h4>
    <p>
    With Java 7, you can use multi-catch feature which lets you remove duplicate code, you just need to specify the list of
    <code>Exceptions</code> as shown below.
    </p>
    
    <div id="code">
    <pre class="prettyprint">
// In Java 7, with try  multi-catch, you can merge multiple Exceptions in same catch block.    
public class TestClass {
    public static void main(String[] args)  {
        try {
            int array[] = new int[5];
            array[5] = 10/0; 

            // catches multiple exceptions java
        } catch (ArithmeticException | ArrayIndexOutOfBoundsException ae) {
            ae.printStackTrace();
        } 
    }
}    </pre></div>
    
    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">
java.lang.ArithmeticException: / by zero
    at MyClass.main(MyClass.java:6)        </pre>    </div><br>    
    
    <h4>3) Variable name in a multi-catch block</h4>
    <p>Note that we can't use variable name more than once in a multi-catch block. Below will not compile</p>
    <div id="code">
        <pre class="prettyprint">
catch (ArithmeticException e1 | IOException e2)
catch (ArithmeticException e | IOException e)        </pre></div><br>

    
    <h4>4) Types in a multi-catch list must not extend one another</h4>
    <p>
    With mutli-catch, you have to make sure a given <code>Exception</code> can match only one type. The <code>Exception</code> types in a 
    multi-catch list should not extend one another. For example, following will not compile:
    </p>
    <div id="code">
        <pre class="prettyprint">
catch (FileNotFoundException | IOException e)
catch (IOException | FileNotFoundException e)       </pre></div><br>
        
    <h4>You will get below compiler error:</h4>
    <p>The exception <code>FileNotFoundException</code> is already caught by the alternative <code>IOException</code>
    
    <h4>5) Multi-catch and catch parameter</h4>
    <p>Following code works when you try to assign a new value to catch parameter:</p>
    <div id="code">
    <pre class="prettyprint">
try {
    // access a file
} catch (IOException e) {
    e = new IOException()
}    </pre></div><br>        
    
    <p>Following code doesn't work when you try to assign a new value to catch parameter:</p>
    <div id="code">
    <pre class="prettyprint">
try {
    // access a file & db
} catch (SQLException | IOException ex) {
    e = new IOException()
}    </pre></div><br>    
    
    <h4>You will get below compiler error:</h4>
    <p>The parameter ex of a multi-catch block cannot be assignment.</p> 
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    References : <a href="https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html" target="_blank">https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html</a>
    
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->


    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>    
</body>

<?php 
    include("footer.htm");
?>
</html>
