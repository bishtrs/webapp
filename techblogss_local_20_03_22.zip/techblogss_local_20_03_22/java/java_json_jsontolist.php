<?php 
    include("header.htm");
?>

<head>
    <title>Convert JSON Array String to List in Java</title>
	<meta name="description" content="Convert JSON Array String to List in Java"/>
	<link rel="canonical" href="https://www.techblogss.com/java/java_json_jsontolist">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h2>Convert JSON Array String to List</h2>
		<p>You can convert a JSON Array String to List using Jackson API.</p>
	</div>
	
	<div id="solution">
		<h4>First you need to download following jars<br><br>
        <a href="https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-databind/2.9.8">jackson-databind-2.9.8</a><br>
        <a href="https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-annotations/2.9.8">jackson-annotations-2.9.8</a><br>
		<a href="https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-core/2.9.8">jackson-core-2.9.8</a><br>
        
        </h4>

	</div>
	
	<div id="solution">
		<h4>Below example shows how to convert JSON Array String to List</h4>
	</div> 
	
	<div id="solution">
		<p>Java class used to convert JSON Array String to List.</p>
	</div>
	
    <div id="code">
	<pre class="prettyprint">
	
public class Employee {
    
    private int id;
    private String name;
    private int age;
        
    public void setId(int id) {
        this.id = id;
    }
        
    public int getId() {
        return this.id;
    }
        
    public void setName(String name) {
        this.name = name;
    }
        
    public String getName() {
        return this.name;
    }
        
    public void setAge(int age) {
        this.age = age;
    }
        
    public int getAge() {
        return this.age;
    }
        
    @Override
	public String toString() {
        return "Employee [id=" + id + ", name=" + name + "," +" age=" + age + "]";
    }  
   
}

</code>
</div>

 <div id="code">
	<pre class="prettyprint">
// Converts JSON Array String to List  
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
	
public class TestJsonJackson {
    public static void main(String[] args) {
        String jsonString = "[{\"id\":\"12345\", \"name\":\"Jason Bourne\", \"age\":\"35\"},"
			+ "{\"id\":\"12346\", \"name\":\"James Bond\", \"age\":\"38\"}]";
            
        ObjectMapper mapper = new ObjectMapper();

        try {
            Employee[] employee = mapper.readValue(jsonString, Employee[].class);
            System.out.println(Arrays.toString(employee));			
			
            List&lt;Employee&gt; employeeList = Arrays.asList(mapper.readValue(jsonString, Employee[].class));
            System.out.println(employeeList);
			
            employeeList = mapper.readValue(jsonString, new TypeReference&lt;List&lt;Employee&gt;&gt;() {});
            System.out.println(employeeList);
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } 
    }
}
	</pre>
	</div>

	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
[Employee [id=12345, name=Jason Bourne, age=35], Employee [id=12346, name=James Bond, age=38]]
[Employee [id=12345, name=Jason Bourne, age=35], Employee [id=12346, name=James Bond, age=38]]
[Employee [id=12345, name=Jason Bourne, age=35], Employee [id=12346, name=James Bond, age=38]]
    </pre>
	</div>


    </div>            
</body>

<?php 
    include("footer.htm");
?>

</html>
