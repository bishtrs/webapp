<?php 
    include("../header.htm");
?>

<head>
    <title>How to acquire Lock in Java</title>
	<meta name="description" content="Acquire lock in java using synchronized keyword, ReentrantLock lock, tryLock method." />
	<link rel="canonical" href="https://www.techblogss.com/java/java-acquire-lock">
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to acquire Lock in Java</h1>
        <p>When multiple threads access an object and try to read the object or modify its state, we need to make sure that only one <code>Thread</code> can do that at a time, else you may get inconsistent result or object state may get corrupted.</p> 
        
        <h3>Java lock vs synchronized</h3>
        <p>
		<ul>
            <li>One of the very powerful features of using Java <b><i>lock</b></i> is the ability to attempt (and fail) to acquire a <b><i>lock</b></i>.
            With traditional synchronization, once you hit a <b><i>synchronized</b></i> block, your thread either immediately acquires the 
            <b><i>lock</b></i> or blocks until it can.</li>
			<li>There is also a variation of the <b><i>tryLock</b></i> method that allows you to specify an amount of time you are willing to wait to 
            acquire the <b><i>lock</b></i>.</li>
			<li>Another benefit of the <b><i>tryLock</b></i> method is you can avoid deadlock. With traditional synchronization, you must acquire locks 
            in the same order across all threads. You can always check if <b><i>lock</b></i> is acquired when using Java <b><i>lock</b></i> by calling
            <b><i>tryLock</b></i>.</li>
			<li>One drawback of using Java <b><i>lock</b></i> is that you always follow the <b><i>lock()</b></i> method with a try-finally block, 
            which releases the <b><i>lock</b></i>.</li>
        </ul>
        
        </p>
	</div>
	<h3>Below examples how to acquire lock in Java</h3>
	<div id="solution">
		<h4>1) Acquire a <b><i>lock</b></i> in Java using <code>synchronized</code> keyword </h4>
        <p>You can acquire a lock in Java by making the method or a code of block using <code>synchronized</code> keyword. In below example, you can see that when one <b><i>thread (Thread-0)</b></i> is executing setCounter() method, other <b><i>thread (Thread-1)</b></i> cannot enter other <code>synchronized</code> method getCounter(). This is because once one <code>Thread</code> acquires lock on Counter class object by entering any <code>synchronized</code> method or block of Counter class method, any other <code>Thread</code> cannot access any other <code>synchronized</code> method or block. This makes sure that when one <code>Thread</code> is reading the counter value, another <code>Thread</code> cannot modify its value. If a <code>Thread</code> do not acquire lock here, then the reader <code>Thread</code> may not get correct value of counter variable.</p>
	</div>
    
    <div id="code">
    <pre class="prettyprint">
public class Counter {
    private int counter;
			
    public synchronized int getCounter() {
        System.out.println(Thread.currentThread().getName() + " in getCounter method");    
        return counter;
    }
    
    public synchronized void setCounter(int counter) {
        System.out.println(Thread.currentThread().getName()  + " in setCounter method");   
        this.counter = counter;
        try {
            Thread.sleep(2000); // takes lock with it
        } catch (InterruptedException e) {
            e.printStackTrace();
        }        
    }
    
    public static void main(String[] args) {
        Counter counter = new Counter();
    	
        Thread t1 = new Thread(() -&gt; {
            for (int i=0; i&lt;5; i ++) {
                counter.setCounter(i++);
            }
        });
   		
        Thread t2 = new Thread(() -&gt; {
            for (int i=0; i&lt;5; i ++) {
                System.out.println("Counter value " + counter.getCounter());
            }
        });
        
        t1.start();
        t2.start();    
    }
}    </pre></div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread-0 in setCounter method
Thread-0 in setCounter method
Thread-1 in getCounter method
Thread-0 in setCounter method
Counter value 2
Thread-1 in getCounter method
Counter value 4
Thread-1 in getCounter method
Counter value 4
Thread-1 in getCounter method
Counter value 4
Thread-1 in getCounter method
Counter value 4		</pre></div><br>
    
	<div id="solution">
		<h4>2) Acquire a <b><i>lock</b></i> in Java using ReentrantLock lock()</h4>
        <p>A thread can also acquire a <b><i>lock</b></i> on a block of code using <code>java.util.concurrent.locks.ReentrantLock lock()</code> method. <br>
        It has following signature : <code>public void lock()</code> & it acquires the <b><i>lock</b></i> if it is not held by another thread and returns immediately. <br><br>
        In below example multiple threads cannot execute the block of code (after <code>lock.lock()</code>) of instance for which lock has been acquired. It can only be accessed once you release the lock using <code>lock.unlock()</code>. 
        It is recommended that you always follow the <code>lock()</code> method with a try-finally block, which releases the <b><i>lock</b></i>.
        </p> 
	</div>
	
	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class MyThread implements Runnable {
    private Producer producer;
    private Lock lock = new ReentrantLock();
    
    public MyThread(Producer producer) {
        this.producer = producer;
    }
	
    public void run() { 
        try {
            lock.lock(); // blocks until acquired
            System.out.println(Thread.currentThread().getName()  + " running");
            producer.setData("data");
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
    
    public static void main(String[] args) {
        MyThread myThread = new MyThread(new Producer());
        Thread threadOne = new Thread(myThread);
        Thread threadTwo = new Thread(myThread);
        Thread threadThree = new Thread(myThread);
        threadOne.start();
        threadTwo.start();
        threadThree.start();
    }
}

class Producer {
    private String data;
			
    public void setData(String data) {
        this.data = data;
    }
}	</pre></div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread-1 running
Thread-0 running
Thread-2 running			</pre></div><br>    

    <div id="solution">
		<h4>3) Acquire a <b><i>lock</b></i> in Java using ReentrantLock tryLock()</h4>
        <p>The previous example doesn't really provide a compelling reason for you to choose to use a <code>Lock</code> instance instead of traditional
		synchronization. One of the very powerful features is the ability to attempt (and fail) to acquire a lock.<br><br>
		A thread can also acquire a <b><i>lock</b></i> on a block of code using <code>java.util.concurrent.locks.ReentrantLock tryLock()</code> method.<br>
        It has following signature : <code>public boolean tryLock()</code> & it acquires the <b><i>lock</b></i> only if it is not held by another thread at the time of invocation. <code>tryLock()</code> will return boolean that indicate whether the lock was acquired successfully.<br><br>
        In below example multiple threads cannot execute the block of code of instance for which lock has been acquired.
        However those threads will not be blocked and could do something else in the meantime.
        </p> 
	</div>
	
	<div id="code">
    <pre class="prettyprint">
public void run() {
    boolean locked = false;    
    try {
        locked = lock.tryLock(); // try without waiting
        if (locked) {
            System.out.println(Thread.currentThread().getName()  + " running");
            producer.produce();
            Thread.sleep(2000);
        }
    } catch (InterruptedException e) {
        e.printStackTrace();
    } finally {
       if (locked) {        
           lock.unlock();
       }
    }
}    </pre></div><br>

    <div id="solution">
    <p>There is another variant of <code>tryLock(long timeout, TimeUnit unit)</code> where you can pass the duration for which thread can wait to acquire the lock. If the lock is not acquired within the time specified, then the thread will give up waiting.</p>
    </div>

	<div id="code">
    <pre class="prettyprint">
public void run() {
    boolean locked = false;    
    try {
        locked = lock.tryLock(2, TimeUnit.SECONDS); 
        if (locked) {
            System.out.println(Thread.currentThread().getName()  + " running");
            producer.produce();
            Thread.sleep(2000);
        }
    } catch (InterruptedException e) {
        e.printStackTrace();
    } finally {
       if (locked) {        
           lock.unlock();
       }
    }
}    </pre></div>    
    
    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code"><pre class="prettyprint">Thread-0 running</pre></div><br>	    	
	
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
References : <br>
	<ul>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/ReentrantLock.html" target="_blank">Oracle Docs ReentrantLock </a>
        </li><br>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/ReentrantLock.html#lock--" target="_blank">Oracle Docs ReentrantLock lock()
        </a>	</li><br>	
        <li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/ReentrantLock.html#tryLock--" target="_blank">Oracle Docs ReentrantLock tryLock()  </a>	</li><br><br>
	</ul>

	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
	
</body>
</html>
