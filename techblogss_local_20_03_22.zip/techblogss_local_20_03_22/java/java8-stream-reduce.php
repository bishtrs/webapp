<?php 
    include("../header.htm");
?>

<head>
    <title>Java 8 Stream Reduce</title>
	<meta name="description" content="Java 8 Stream reduce, stream reduce java, java stream reduce example" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-stream-reduce" />
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h1>Java 8 Stream reduce examples</h1>
	</div>

	<div id="solution">
		<h4>1) <i>Stream reduce()</i> example to sum the ages of persons</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;

public class StreamReduce {

    public static void main(String[] args) {
        List&lt;Person> persons = new ArrayList&lt;>();
        persons.add(new Person("Rambo", 74));
        persons.add(new Person("John", 45));
        persons.add(new Person("Mark", 35));
		
        OptionalInt sum = persons.stream().mapToInt(Person::getAge).reduce((a1, a2) -> a1 + a2);
        System.out.println("Sum of ages " + sum.getAsInt());
    }
}	</pre>
	</div>

<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Sum of ages 154
	</pre>
	</div>	
    <br>
	
	<div id="solution">
		<h4>2) <i>Stream reduce() example to sum the numbers </i></h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.OptionalInt;

public class StreamReduce {

    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        OptionalInt sum = Arrays.stream(numbers).reduce((a, b) -> a + b);
        System.out.println("Sum of numbers " + sum.getAsInt());
    }
}	</pre>
	</div>

<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Sum of numbers 15
	</pre>
	</div>	
    <br>

	<div id="solution">
		<h4>3) <i>Stream reduce() example to find max of the numbers </i></h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.OptionalInt;

public class StreamReduce {

    public static void main(String[] args) {
        int[] numbers = {1, 2, 5, 4, 3};
        OptionalInt sum = Arrays.stream(numbers).reduce(Integer::max);
        System.out.println("max number is " + max.getAsInt());
    }
}	</pre>
	</div>

<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
max number is 5
	</pre>
	</div>	
    <br>
	
	<div id="solution">
		<h4>4) Below example shows how to concatenate list of names using <i>Stream reduce()</i></h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StreamReduce {

    public static void main(String[] args) {
        List&lt;Person> persons = new ArrayList&lt;>();
        persons.add(new Person("Rambo", 74));
        persons.add(new Person("John", 45));
        persons.add(new Person("Mark", 35));
		
        Optional&lt;String> name = persons.stream().map(Person::getName)
            .reduce((n1, n2) -> n1 + "," + n2);
        System.out.println("All names :: " + name.get());    
    }
}	</pre>
	</div>

<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
All names :: Rambo,John,Mark
	</pre>
	</div>	
    
	<br>
	<div id="solution">
		<h4>5) <i>Stream reduce()</i> with identity example</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.ArrayList;
import java.util.List;

public class StreamReduce {

    public static void main(String[] args) {
        List&lt;Double> readings = new ArrayList<>();
        readings.add(10.3);
        readings.add(20.5);
        readings.add(30.6);

        double sum = readings.stream().reduce(0.0, (v1, v2) -> v1 + v2);
        System.out.println("Sum of readings " + sum);
    }
}
	</pre>
	</div>

<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Sum of readings 61.400000000000006
	</pre>
	</div>	
    
	<br>
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#reduce-java.util.function.BinaryOperator-" target="_blank">Oracle Docs Stream reduce()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#reduce-T-java.util.function.BinaryOperator-" target="_blank">Oracle Docs Stream reduce with identity()</a>	<br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
