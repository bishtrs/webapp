<?php include("../header.htm");?>

<head>
    <title>Lambda Expressions examples in Java 8</title>
	<meta name="description" content="Lambda Expressions examples in Java 8" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_lambda" />
</head>

<body>
	<?php include("../navigation.htm");?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Lambda Expressions in Java</h1>
	    <p>
		A <b>Lambda expression</b> (introduced in Java 8) is a concise way of writing an instance of a class that implements a functional interface.
        An interface with single abstract method is called functional interface. For example <code>Runnable</code> interface. It has just one method run().
        To implement a <b>Lambda Expression</b>, use an &rarr; symbol with paremeters on the left and a method body on the right.
        </p>
	</div>
	
    <div id="solution">
		<h4>1) Following Java Lambda Expressions example shows how to implement a simple interface without actually creating the concrete class. </h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// A sample functional interface (An interface with single abstract method)
public interface Calculator {  
    int add(int a,int b);  
}  			
</pre>
	</div>

<p>Without Lambda Expressions</p>

<div id="code">
	<pre class="prettyprint">
public class LambdaExpressionsTest {
    public static void main(String[] args) {
        Calculator calculator = new Calculator() { 
            public int add(int a,int b) {
                return a+b;
            }
        };
        System.out.println(calculator.add(1,2)); // prints 3  
       
   }
}

</pre>
	</div>

<p>With Lambda Expressions in Java</p>

<div id="code">
	<pre class="prettyprint">	
public class LambdaExpressionsTest {
    public static void main(String[] args) {
        Calculator calculator = (a,b)->(a+b);
        System.out.println(calculator.add(1,2)); // prints 3  
			
        calculator =(int a,int b)->{return (a+b);   
        };
        System.out.println(calculator.add(20,30));  // prints 50
        
        calculator = (a,b)-> {return (a+b);};
        System.out.println(calculator.add(20,40));  // prints 60
        
        // following will not compile
        calculator = (a,b)-> return (a+b);
   }
}
	</pre>
	</div>
	
		
	<div id="solution">
		<h4>2) Following Java Lambda Expressions example shows how to pass Lambda expressions as method argument. </h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// A sample functional interface (An interface with single abstract method)   
public interface EmployeeQuery {
    public boolean queryEmployee(Employee employee);
}    

import java.util.ArrayList;
import java.util.List;
	
class Employee {  

    private int age;
    private String name;
		
    public Employee(String name, int age) {
        this.name = name;
        this.age = age;
    }
		
    // getter, setter removed    
	
}  			

public class Test {
    public static void main(String[] args) {
        Employee e1 = new Employee("Mark", 30); 
        Employee e2 = new Employee("Harry", 40);
        Employee e3 = new Employee("Johnny", 50);
        List&lt;Employee&gt; employees = new ArrayList&lt;>();
        employees.add(e1);
        employees.add(e2);
        employees.add(e3);
            
        for (Employee employee : employees) {
           printEmployeeName(employee, e -> e.getAge() > 30);
        }
    }
		
    private static void printEmployeeName(Employee employee, EmployeeQuery employeeQuery) {
        if (employeeQuery.queryEmployee(employee)) {
            System.out.println(employee.getName());
        }
    }
		
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Harry
Johnny		</pre></div>
	
	<div id="solution">
		<h4>3) Following Java Lambda Expressions example shows how to use Lambda Expressions using for loop for iterating a list</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
	
public class TestClass { 
    public static void main(String[] args) {
      
        List&lt;String&gt; fruits = new ArrayList<>();
        fruits.add("Apple");
        fruits.add("Banana");
        <span class="highlight">fruits.stream().forEach((string) -> {System.out.println(string);</span>
        }  );
    }
}
	</pre>
	</div>
    
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Apple
Banana		</pre></div>
	
	<div id="solution">
		<h4>4) Sorting by Using Comparator Interface</h4>
	</div>
	<div id="code">
    <pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
	
class Celebrity  {

    private String name;
    private int rank;
    private int networth;

    Celebrity (String name, int rank, int networth) {
        this.name = name;
        this.rank = rank;
        this.networth = networth;
    }
        
    // getter setter removed
	
    @Override
    public String toString() {
        return "Celebrity [name=" + name + ", rank=" + rank + ", networth="+ networth + "]";
    }
		
}
						
public class MyClass {
    public static void main(String[] args) {
        List&lt;Celebrity&gt; celebrities = new ArrayList&lt;Celebrity&gt;();
        Celebrity celebrity1 = new Celebrity("Harry", 1, 100000);
        Celebrity celebrity2 = new Celebrity("IronMan", 3, 2000000);
        Celebrity celebrity3 = new Celebrity("Batman", 2, 50000);
            
        celebrities.add(celebrity1);
        celebrities.add(celebrity2);
        celebrities.add(celebrity3);
		
        celebrities.sort( (Celebrity c1, Celebrity c2)-> c1.getNetworth()- c2.getNetworth() );		
        celebrities.forEach( (celebrity)->System.out.println(celebrity) );
       
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Celebrity [name=Batman, rank=2, networth=50000]
Celebrity [name=Harry, rank=1, networth=100000]
Celebrity [name=IronMan, rank=3, networth=2000000]
		</pre>
	</div>
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

    References : <br><br>
    <a href="https://docs.oracle.com/javase/tutorial/java/javaOO/lambdaexpressions.html">Oracle Docs Lambda Expressions</a><br><br>
    <a href="https://docs.oracle.com/javase/8/docs/api/java/util/function/package-summary.html">Oracle Docs Functional Interface</a>
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
	
</body>
<?php 
    include("footer.htm");
?>
</html>