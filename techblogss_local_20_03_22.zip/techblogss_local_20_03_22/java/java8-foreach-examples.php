<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 forEach examples</title>
	<meta name="description" content="This tutorial shows how to use Java 8 forEach to iterate over a List, Map, etc." />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-foreach-examples" />
</head>


<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content">
     <div id="blog">
	<div id="problem">
		<h1>Java 8 forEach examples</h1>
            <b><i>forEach</b></i> was introduced in Java 8 & is defined in Iterable interface. foreach is used to loop over an List, Map, or any 
            other Collection.
	</div>
	<div id="solution">
		<h2>1) Prior to Java 8, for loop was used to iterate over a List</h2>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
	
public class TestClass { 
    public static void main(String[] args) {
        List&lt;String&gt; fruits = new ArrayList&lt;&gt;();
        fruits.add("mango");
        fruits.add("apple");
        fruits.add("pineapple");
        fruits.add("orange");
    
        for (String fruit : fruits){
            System.out.println(fruit);
        }
    }
}  	</pre>
	</div><br>
	
	<div id="solution">
		<h2>2) Java 8 forEach example to iterate over a List with Lambda expression</h2>
	</div>
    To use Java forEach List, you need specify forEach after the list object
	<div id="code">
	<pre class="prettyprint">
// Loops over List using Java 8 forEach
import java.util.Arrays;
import java.util.List;
	
public class TestClass { 
    public static void main(String[] args) {
        List&lt;String&gt; fruits = Arrays.asList("mango", "apple", "pineapple", "orange", "apple");
        
        fruits.forEach(item->System.out.println(item));
    }
}  	</pre>
	</div><br>
	
	
<div id="solution">
		<h2>3) Java 8 forEach example to iterate over a List with method reference</h2>
	</div>
	<div id="code">
	<pre class="prettyprint">
// Loops over List using Java forEach method reference 
import java.util.Arrays;
import java.util.List;
	
public class TestClass { 
    public static void main(String[] args) {
        List&lt;String&gt; fruits = Arrays.asList("mango", "apple", "pineapple", "orange", "apple");
        
        // Java forEach method reference
        fruits.forEach(System.out::println);
    }
}  	</pre>
	</div><br>
	
	<div id="solution">
		<h2>4) Example below shows how to iterate over Map Prior to Java 8</h2>
	</div>
	<div id="code">
	<pre class="prettyprint">
// Loops over Map using forEach   
import java.util.HashMap;
import java.util.Map;
	
public class TestClass { 
    public static void main(String[] args) {
        Map&lt;Integer, String&gt; map = new HashMap<>();
        map.put(1, "Apple");
        map.put(2, "Orange");
        map.put(3, "PineApple");
        for (Map.Entry&lt;Integer, String&gt; entry : map.entrySet()) {
            System.out.println("Item : " + entry.getKey() + " Value : " + entry.getValue());
        }        
        
    }		
} 	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Item : 1 Value : Apple
Item : 2 Value : Orange
Item : 3 Value : PineApple		</pre>
	</div><br>
	
	
	<div id="solution">
		<h2>5) Java 8 forEach example to iterate over a Map</h2>
	</div>
    To use Java forEach Map, you need specify forEach after the map object
	<div id="code">
	<pre class="prettyprint">
// Loops over list using Lambda expression 
import java.util.HashMap;
import java.util.Map;
	
public class TestClass { 
    public static void main(String[] args) {
        Map&lt;Integer, String&gt; map = new HashMap<>();
        map.put(1, "Apple");
        map.put(2, "Orange");
        map.put(3, "PineApple");
        map.forEach((k,v)->System.out.println("Index [" + k + "] Fruit  [" + v + "]"));
    }		
}  	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Index [1] Fruit  [Apple]
Index [2] Fruit  [Orange]
Index [3] Fruit  [PineApple]		</pre>
	</div><br>
	
	<div id="solution">
		<h2>6) Java for-each array example</h2>
	</div>
    <div id="code">
	<pre class="prettyprint">
// Loops over array using for-each (enhanced for loop )
public class TestClass { 
    public static void main(String[] args) {
        int[] ids = {1,2,3,4,5};
        for (int id : ids) {
            System.out.println("id : " + id); 
        }
    }		
}  	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
id : 1
id : 2
id : 3
id : 4
id : 5		</pre>
	</div><br>
	
	
<div id="solution">
		<h2>7) Java 8 forEach index example</h2>
        If you need index while using Java forEach, you need to get Stream from the array.
	</div>
    To use Java forEach List, you need specify forEach after the array object
	<div id="code">
	<pre class="prettyprint">
// Loops over array using forEach and prints index of each element

import java.util.stream.IntStream;

public class TestClass { 
    public static void main(String[] args) {
        String[] fruits = {"mango", "apple", "pineapple", "orange", "apple"};
        IntStream.range(0, fruits.length) 
        .mapToObj(index -> String.format("%d -> %s", index, fruits[index])) 
        .forEach(System.out::println); 
    }		
} 	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
0 -> mango
1 -> apple
2 -> pineapple
3 -> orange
4 -> apple		</pre>
	</div>
    <br>
	
	 <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
     
References : <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Iterable.html#forEach-java.util.function.Consumer-" target="_blank">https://docs.oracle.com/javase/8/docs/api/java/lang/Iterable.html#forEach-java.util.function.Consumer-</a> 

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
</body>
<?php 
    include("footer.htm");
?>
</html>
