<?php 
    include("../header.htm");
?>

<head>
    <title>Measure elapsed time in Java</title>
	<meta name="description" content="Measure elapsed time or check time taken by method in Java using System currentTimeMillis(), nanoTime(), Instant Class, Apache Commons Lang StopWatch, Spring StopWatch." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_cj_measureelapsedtime /">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to measure elapsed time or check time taken by method in Java ?</h1>
	</div>
	
	<div id="solution">
        <h4>1) Measure elapsed time using System currentTimeMillis()</h4>
		<p>
        You can measure elapsed time or check time taken by method in Java by using <code>System currentTimeMillis()</code>.This method returns the current time in milliseconds which is actually the difference between current time and 1st of January, 1970 UTC.
		</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// measure elapsed time or check time taken by method
public class MeasureElapsedTime {
		
    public void print() {
        System.out.println("Hello");
    }
		
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        (new MeasureTime()).print();
        long endTime = System.currentTimeMillis();
        System.out.println("time elapsed in print method " +
           (endTime - startTime) + " milliseconds");	
    }
}	</pre>	</div>
	
	<br>
    Reference <a href ="https://docs.oracle.com/javase/8/docs/api/java/lang/System.html#currentTimeMillis">https://docs.oracle.com/javase/8/docs/api/java/lang/System.html#currentTimeMillis</a>
	<br><br>
    
	<div id="solution">
		<h4>2) Measure elapsed time using System nanoTime()</h4>
        <p>
        You can also measure elapsed time or check time taken by method in Java using <code>System nanoTime()</code> which gives more precise time in nanoseconds.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// measure elapsed time or check time taken by method
public class MeasureTime {
		
    public void print() {
        System.out.println("Hello");
    }
		
    public static void main(String[] args) {
        long startTime = System.nanoTime();
        (new MeasureTime()).print();
        long endTime = System.nanoTime();
        System.out.println("time elapsed in print method " +
            (endTime - startTime) + " nanoseconds");	
    }
}	</pre>	</div>	<br>

	<div id="solution">
        <h4>2) Measure elapsed time using Java 8 Duration & Instant classes</h4>
        <p>
        You can also measure elapsed time or check time taken by method in Java using <code>Duration & Instant</code> classes. <code>Instant now()</code> will return an instance of <code>Instant</code> class. You need to pass two such instances, one when the event starts and once when the event stops to <code>Duration between()</code> method, which will return <code>Duration </code> object. <code>Duration toMillis()</code> method will return the time in milliseconds.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.time.Duration;
import java.time.Instant;

// measure elapsed time or check time taken by method
public class MeasureTime {
		
    public void print() {
        System.out.println("Hello");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }		
    }
		
    public static void main(String[] args) {
        Instant start = Instant.now();
        (new MeasureTime()).print();
        Instant end = Instant.now();
        long timeElapsed = Duration.between(start, end).toMillis();
        System.out.println("time elapsed in print method " + timeElapsed + " milliseconds");	
    }
}	</pre></div>
	
    <?php include("../sidebar/ad.htm"); ?>
     
	<br>
	<div id="solution">
        <h4>4) Measure elapsed time using Spring Stopwatch \</h4>
        <p>
        You can also measure elapsed time or check time taken by method in Java using Spring <code>Stopwatch getTotalTimeSeconds()</code> method which calculates time in seconds. You need to call <code>Stopwatch start()</code> at the start of event you want to check and <code>stop()</code> at the time event ends. At the end you need to call <code>Stopwatch getTotalTimeSeconds()</code> to get the time taken by the event.
        </p>
		You need to download spring core library from here <a href="http://central.maven.org/maven2/org/springframework/spring-core/4.3.4.RELEASE/spring-core-4.3.4.RELEASE.jar" target="_blank">download spring-core-4.3.4.jar</a>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import org.springframework.util.StopWatch;

// measure elapsed time or check time taken by method
public class MeasureTime {
		
    public void print() {
        System.out.println("Hello");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }		
    }
		
    public static void main(String[] args) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        (new MeasureTime()).print();
        stopWatch.stop();
        System.out.println("time elapsed in print method " +
        stopWatch.getTotalTimeSeconds() + " seconds");
    }
}	</pre>	</div>

	<div id="solution">
        <h4>5) Measure elapsed time using Apache Commons Lang Stopwatch</h4>
        <p>
        You can measure elapsed time or check time taken by method in Apache Commons Lang <code>Stopwatch getTime()</code> method which calculates time in milliseconds. You need to call <code>Stopwatch start()</code> at the start of event you want to check and <code>stop()</code> at the time event ends. At the end you need to call <code>Stopwatch getTime()</code> to get the time taken by the event.
        </p>    
		You need to download Apache Commons Lang library from here <a href="https://jar-download.com/artifacts/org.apache.commons/commons-lang3/3.7/source-code ">download commons-lang3-3.7.jar</a>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import org.apache.commons.lang3.time.StopWatch;

// measure elapsed time or check time taken by method
public class MeasureTime {
		
    public void print() {
        System.out.println("Hello");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }		
    }
		
    public static void main(String[] args) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        (new MeasureTime()).print();
        stopWatch.stop();
        System.out.println("time elapsed in print method " +
            stopWatch.getTime() + " milliseconds");
    }
}	</pre>	</div>
    
    <?php include("../sidebar/ad.htm"); ?>
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>	
</body>

<?php 
    include("footer.htm");
?>

</html>
