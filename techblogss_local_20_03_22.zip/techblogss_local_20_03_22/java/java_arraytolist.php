<?php 
    include("../header.htm");
?>

<head>
    <title>How to convert a array to list and vice versa in java</title>
	<meta name="description" content="Convert array to list in Java using Arrays asList(), Collections addAll(), Collectors toList(),Convert list to array in Java, using List toArray(), Stream toArray()" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_arraytolist" />
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Convert Array to List and vice versa in Java &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;</h1>
        <p>There are various ways of converting Array to List</p>
        <h2>How to convert Array to List</h2>
	</div>
	<div id="solution">
		<h4>1) Convert array to list in Java using Arrays asList() </h4>
	</div>
	<div id="code">
    <pre class="prettyprint">
// Converts array to list in Java using Arrays asList()    
import java.util.Arrays;
import java.util.List;

public class MyClass {
    public static void main(String[] args) {
        Integer[] values = { 1, 6, 5 };
        
        // convert array of Integer to List
        List&lt;Integer&gt; list = Arrays.asList(values);
        System.out.println(list);
       
        String[] names = { "Harry", "Ronny", "Jack" };
        
        // convert array of String to List
        List&lt;String&gt; nameList = Arrays.asList(names);
        System.out.println(nameList);        
    }
}
    </pre>
	</div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[1, 6, 5]
[Harry, Ronny, Jack]
		</pre>
	</div>		
	<div id="comments">
	</div>

<div id="solution">
		<h4>2) Convert array to list in Java without using Arrays asList() </h4>
        <p>You can convert array to list by iterating over array.</p> 
	</div>
	<div id="code">
    <pre class="prettyprint">
// Converts array to list in Java by iterating over array       
import java.util.ArrayList;
import java.util.List;

public class MyClass {
    public static void main(String[] args) {
        Integer[] nums = { 1, 6, 5 };
        
        List&lt;Integer&gt; list = new ArrayList&lt;&gt;();
      
        for (Integer num : nums) {
            list.add(num);
        }            
        
        System.out.println(list);
    }
}
    </pre>
	</div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[1, 6, 5]
	</pre>
	</div>		
	<div id="comments">
	</div>
		
<div id="solution">
		<h4>3) Convert array to list in Java using Collections addAll() </h4>
 	</div>
	<div id="code">
    <pre class="prettyprint">
//Converts array to list using Collections addAll()    
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MyClass {
    public static void main(String[] args) {
        Integer[] nums = { 1, 6, 5 };
        
        List&lt;Integer&gt; list = new ArrayList&lt;&gt;();
        list.add(2);
        Collections.addAll(list, nums); 
        System.out.println(list);
        
        Collections.addAll(list, 9, 10); 
        System.out.println(list);
    }
    
}
    </pre>
	</div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[2, 1, 6, 5]
[2, 1, 6, 5, 9, 10]
	</pre>
	</div>		
	<div id="comments">
	</div>

	<div id="solution">
		<h4>4) Convert array to list in Java using Collectors toList() </h4>
 	</div>
	<div id="code">
    <pre class="prettyprint">
//Converts array to list using Collectors toList()        
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MyClass {
    public static void main(String[] args) {
        Integer[] nums = { 1, 6, 5 };
        
        // convert array of Integer to List
        List&lt;Integer&gt; list = Arrays.stream(nums).collect(Collectors.toList());  
        System.out.println(list);
       
        String[] names = { "Harry", "Ronny", "Jack" };
        
        // convert array of String to List
        List&lt;String&gt; nameList = Arrays.stream(names).collect(Collectors.toList());
        System.out.println(nameList);        
    }
}
    </pre>
	</div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[1, 6, 5]
[Harry, Ronny, Jack]
		</pre>
	</div><br>		

	<div id="problem">
		<h2>How to convert a List to Array ?</h2>
	</div>
	<div id="solution">
		<h4>1) Convert list to array in Java using List toArray() </h4>
	</div>
	<div id="code">
    <pre class="prettyprint">
//Convert list to array in Java using List toArray()    
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; list = new ArrayList&lt;String&gt;();
        list.add("Apple");
        list.add("Mango");
        list.add("Grapes");
        String[] fruits = list.toArray(new String[list.size()]);
        System.out.println(Arrays.toString(fruits));
    }
}
    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[Apple, Mango, Grapes]
		</pre>
	</div>		
	<div id="comments">
	</div>

	<div id="solution">
		<h4>2) Convert list to array in Java without using List toArray() </h4>
        <p>You can convert list to array by iterating List.</p>
	</div>
	<div id="code">
    <pre class="prettyprint">
//Convert list to array in Java by iterating List    
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; list = new ArrayList&lt;String&gt;();
        list.add("Charlie");
        list.add("Allen");
        list.add("Walden");
        String[] students = list.toArray(new String[list.size()]);
        int i=0;
        
        for (String student : list) {
            students[i++] = student;
        }
        
        System.out.println(Arrays.toString(students));
    }
}
    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[Charlie, Allen, Walden]
		</pre>
	</div>		
	<div id="comments">
	</div>

	<div id="solution">
		<h4>3) Convert list to array in Java using Stream toArray()</h4>
	</div>
	<div id="code">
    <pre class="prettyprint">
//Convert list to array in Java using Stream toArray()    
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class MyClass {
    public static void main(String[] args) {
        List&lt;String&gt; list = new ArrayList&lt;String&gt;();
        list.add("Apple");
        list.add("Mango");
        list.add("Grapes");
        
        String[] fruits = list.stream().toArray((String[]::new));
        System.out.println(Arrays.toString(fruits));
    }
}
    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[Apple, Mango, Grapes]
		</pre>
	</div><br>		
	
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html#asList-T...-">Oracle Docs Arrays asList()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Collections.html#addAll-java.util.Collection-T...-">Oracle Docs Arrays addAll()</a> <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html#toList--">Oracle Docs Collectors toList()</a><br><br>		
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/List.html#toArray-T:A-">Oracle Docs List toArray()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#toArray-java.util.function.IntFunction-">Oracle Docs Stream toArray()</a><br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
    
</body>

<?php 
    include("footer.htm");
?>
</html>