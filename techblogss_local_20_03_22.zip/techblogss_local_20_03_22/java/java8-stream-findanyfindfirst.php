<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Stream findAny(), findFirst()</title>
	<meta name="description" content="Java 8 Stream findAny(), findFirst()" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-stream-findanyfindfirst" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h2>Java 8 Stream search examples using Stream findAny(), findFirst()</h2>
	</div>

	<div id="solution">
		<h4>1) Find an object in a <b><i>Stream</b></i> using <b><i>Stream findAny()</b></i> method</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Stream findAny() example    
package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StreamSearch {

    public static void main(String[] args) {
        List&lt;String> actors = Arrays.asList("Tom", "Harry", "Mark");
        Optional&lt;String&gt; name = actors.stream().filter(n -> n.startsWith("H")).findAny();
        name.ifPresent(System.out::println);
    }
}	</pre>
	</div>

<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Harry	</pre>
	</div>	
    <br>

<div id="solution">
		<h4>2) Find an object in a <b><i>Stream</b></i> using <b><i>Stream findFirst()</b></i> method</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Stream findFirst() example    
package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StreamSearch {

    public static void main(String[] args) {
        List&lt;String> actors = Arrays.asList("Hans", "Harry", "Mark");
        Optional&lt;String&gt; name = actors.stream().filter(n -> n.startsWith("H")).findFirst();
        name.ifPresent(System.out::println);
    }
}	</pre>
	</div>

<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Hans</pre>
	</div>	
    <br>
	
    <br>
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#findAny--" target="_blank">Oracle Docs Stream findAny()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#findFirst--" target="_blank">Oracle Docs Stream findFirst()</a>	<br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
