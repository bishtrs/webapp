<?php 
    include("header.htm");
?>

<head>
    <title>How to override a method in Java</title>
	<meta name="description" content="How to override a method in java, Overriding in Java"/>
	<link rel="canonical" href="https://www.techblogss.com/java/java-override-method">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
   	<div id="content">
	<div id="blog">
	<div id="problem">
		<h1>How to override a method in Java ?</h1>
	</div>

	<div id="solution">
        <p>
        <b><i>Overriding</b></i> is the ability of a <b><i>subclass or child</b></i> class method to <b><i>override</b></i> the behavior of the 
        <b><i>superclass or parent</b></i> method. <b><i>Overriding</b></i> is a way of achieving runtime <b><i>Polymorphism in Java</b></i>. 
        </p>
        <p>
        For example if there is a <b><i>parent class Animal</b></i> with method <b><i>eat()</b></i>, you can write different implementation of <b><i>eat()</b></i> method in a subclass like <b><i>Cat, Mouse</b></i> as shown in below example.
        Note that you can also invoke <b><i>Cat eat()</b></i> method using Animal class reference but The compiler will consider the reference type, and not the instance type. 
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// parent class
public class Animal {
    public void eat() {
        System.out.println("Generic animal is eating");
    }
}
</pre>	
	</div>

    <div id="code">
	<pre class="prettyprint">
// child class
public class Cat extends Animal {
    public void eat() {
        System.out.println("Cat is eating");
    }
}
    </pre>	
	</div>

<div id="code">
	<pre class="prettyprint">    
public class TestClass {
		
    public static void main(String[] args)  {
        Animal animal = new Animal(); 
        animal.eat();
        
        animal = new Cat(); 
        animal.eat();
        
        Cat cat = new Cat(); 
        cat.eat();
        // cat = new Animal; // won't compile without cast
    }
}
</pre>	
	</div>	
	
    <div id="solution">
		<h4>Console Output : </h4>
	</div>    
    <div id="code">
		<pre class="prettyprint">
Generic animal is eating
Cat is eating
Cat is eating
		</pre>
	</div>
	
	<br>
	
	<div id="solution">
        <h4>Overriding Rules</h4>
        <p>
        However there are few rules to follow for method <b><i>overriding</b></i>. For example the <b><i>overriding</b></i> method cannot
        have a more restrictive access modifier than the method being overridden. 
        </p>
        <h4>List of rules for overriding:</h4>
        <p>
        <ul>
            <li>The argument list of subclass method must exactly match that of the parent class method.</li>
            <li>The <b><i>return type</b></i> of subclass method must be same as, or a subtype of, the <b><i>return type</b></i> declard in the 
            parent class method. As shown below, Rectangle class will not compile.</li>
        
        </p>
<div id="code">
		<pre class="prettyprint">
public class Shape {
    public int area(int length, int width) {
        return length*width;
    }
}
</pre>
	</div>

<div id="code">
		<pre class="prettyprint">
public class Rectangle extends Shape {
    public long area(int length, int width) {
    	return length*width;
    }
} 
</pre>
	</div>
        <p>
            <li>The access level can't be more restrictive than that of the <b><i>overridden</b></i> method. If <b><i>Animal class eat()</b></i> method is of <b><i>public</b></i> type, then <b><i>Cat eat()</b></i> method cannot be <b><i>private</b></i> or <b><i>protected</b></i>.
            As shown below, Cat class will not compile.</li>
        </p>
            <div id="code">
            <pre class="prettyprint">
// parent class
public class Animal {
    public void eat() {
        System.out.println("Generic animal is eating");
    }
}
</pre>	
	</div>

    <div id="code">
	<pre class="prettyprint">
// child class
public class Cat extends Animal {
    private void eat() {
        System.out.println("Cat is eating");
    }
}
    </pre>	
	</div><br>   
        <p>
            <li>The <b><i>overrding</b></i> method can throw any <b><i>unchecked/runtime</b></i> exeption.</li>
            <li>The <b><i>overrding</b></i> method cannot throw any <b><i>checked</b></i> exeption, that are new or broader than those declared by the 
            <b><i>overridden</b></i> method. For example if parent class method throws SQLException, then child class method cannot declare to 
            throw IOException or Exception. As shown below, Cat class will not compile</li>
        </p>
    <div id="code">
	<pre class="prettyprint">
import java.sql.SQLException;    
// parent class
public class Animal {
    public void eat() throws SQLException {
        System.out.println("Generic animal is eating");
    }
}
</pre>	
	</div>

    <div id="code">
	<pre class="prettyprint">
// child class
public class Cat extends Animal {
    public void eat() throws Exception {
        System.out.println("Cat is eating");
    }
}
    </pre>	
	</div><br>
            <li>You cannot override a <b><i>final</b></i> method.</li>
            <li>You cannot override a <b><i>static</b></i> method.</li>
        </ul>
	</div>
    <br>
	
    <div id="solution">
        <h4>How to invoke a supertype method from a <b><i>overridden</b></i> method of child class ?</h4>
        <p>
        Sometimes the child class method may need to invoke parent class method and then perform its logic. This can be done using <b><i>super</b></i> keyword as shown below:
        </p>
    </div>        
    
 <div id="code">
	<pre class="prettyprint">
// parent class
public class Animal {
    public void print() {
        System.out.println("Generic animal printing");
    }
}
</pre>	
	</div>

    <div id="code">
	<pre class="prettyprint">
// child class
public class Cat extends Animal {
    public void print() {
        super.print();
        System.out.println("Cat printing");
    }
    
    public static void main(String[] args)  {
        Animal animal = new Cat(); 
        animal.printAnimalName();
    }
} 
</pre>	
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>    
    <div id="code">
		<pre class="prettyprint">
Generic animal
Cat
		</pre>
	</div>
	
	<br> 

    <h4>Using @Override annotation</h4>
    <p>Java 5 added <b><i>@Override annotation </b></i>, which is not mandatory to use while overriding a method but can help catch errors with 
    overriding at compile time.
    </p>
    View this page for more details <a href="https://www.techblogss.com/java/java_cj_annotations" target="_blank">Annotations in Java</a>

    <br><br>
    
     <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
	</div> <!-- content div -->
    
   <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
    
</body>



<?php 
    include("footer.htm");
?>

</html>
