<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Stream anymatch</title>
	<meta name="description" content="Java stream anymatch, anymatch in java 8, Java stream allMatch, Java stream noneMatch" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-stream-allanynonematch" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h2>Java Stream allMatch, anymatch, noneMatch examples</h2>
	</div>

	<div id="solution">
         <p>1) Java Stream <b><i>allMatch()</b></i> returns whether all elements of this stream match the provided predicate. 
        </p>

		<p><b><i>Stream allMatch()</b></i> example to check if all balls are larger than a size.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;

public class StreamAnyMatch {

    public static void main(String[] args) {
        Ball tennis = new Ball("tennis", 1, "green");
        Ball footBall = new Ball("football", 2, "white");
        Ball basketBall = new Ball("basketBall", 3, "orange");
        List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall);
        
        boolean allBallsBig = balls.stream().allMatch(b -> b.getSize() > 2);
        System.out.println(allBallsBig);
    }
}</pre>
	</div>


<div id="code">
	<pre class="prettyprint">
public class Ball {

    private String name;
    private int size;
    private String color;

    public Ball(String name, int size, String color) {
        this.name = name;
        this.size = size;
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public int getSize() {
        return size;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return "Ball [name=" + name + ", size=" + size + ", color=" + color + "]";
    }

}
</pre>
	</div>
    
<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
false
	</pre>
	</div>	
    <br>
	
	<div id="solution">
         <p>2) Java Stream <b><i>anyMatch()</b></i> returns whether any elements of this stream match the provided predicate. 
        </p>

		<p><b><i>Stream anymatch()</b></i> example to check if balls with a large size exists.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;

public class StreamAnyMatch {

    public static void main(String[] args) {
        Ball tennis = new Ball("tennis", 1, "green");
        Ball footBall = new Ball("football", 2, "white");
        Ball basketBall = new Ball("basketBall", 3, "orange");
        List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall);
        boolean largeBallPresent = balls.stream().anyMatch(b -> b.getSize() > 2);
        System.out.println(largeBallPresent);
        System.out.println(balls.stream().anyMatch(b -> b.getSize() > 5));
    }
}</pre>
	</div>
    
    <div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
true
false
	</pre>
	</div>	

    <br>
 
	<div id="solution">
         <p>3) Java Stream <b><i>noneMatch()</b></i> returns whether no elements of this stream match the provided predicate. 
        </p>

		<p><b><i>Stream noneMatch()</b></i> example to check if no ball with a large size exists.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;

public class StreamAnyMatch {

    public static void main(String[] args) {
        Ball tennis = new Ball("tennis", 1, "green");
        Ball footBall = new Ball("football", 2, "white");
        Ball basketBall = new Ball("basketBall", 3, "orange");
        List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall);
        boolean noneMatch = balls.stream().noneMatch(b -> b.getSize() > 2);
        System.out.println(noneMatch);
    }
}</pre>
	</div>
    
   <div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
false
	</pre>
	</div>	    

    <br> 
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#allMatch-java.util.function.Predicate-" target="_blank">
Oracle Docs Stream allMatch()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#anyMatch-java.util.function.Predicate-" target="_blank">
Oracle Docs Stream anyMatch()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#noneMatch-java.util.function.Predicate-" target="_blank">
Oracle Docs Stream noneMatch()</a>	<br><br>
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
