<?php 
    include("header.htm");
?>

<head>
    <title>Search an element in an array in Java</title>
	<meta name="description" content="Search an element in an array in Java, binary search array in Java, arrays.binarysearch comparator example" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_searcharray">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>Search an element in an array in Java</h1>
	</div>
    <p>The Arrays class provides methods that allow you to search for an element.</p>
	<div id="solution">
		<h4>1) Search an element in an array in java using Arrays binarySearch(Object[] a, Object key) </h4>
	</div>
	<div id="code">
	<pre class="prettyprint">
// Search an element in an array	
import java.util.Arrays;

public class TestSearchElement {
    public static void main(String[] args) {
        String[] actors = {"Brad", "Matt", "George", "Clive"};
        
        Arrays.sort(actors);
        
        for (String actor : actors)     
            System.out.println("actor " + actor);
        System.out.println("index of Matt in sorted array  " + Arrays.binarySearch(actors, "Matt"));
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
actor Brad
actor Clive
actor George
actor Matt
index of Matt in sorted array  3
		</pre>
	</div>	
	

	<div id="solution">
		<h4>2) Search an element in an array in java using Arrays binarySearch(T[] a, T key,  Comparator&lt;? super T> c) with Comparator</h4>
 	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.Arrays;
import java.util.Comparator;

class Actor {
    private String name;
    private int rank;
	
    Actor (String name, int rank) {
        this.name = name;
        this.rank = rank;
    }
	
    public String getName() {
        return name;
    }
	
    public int getRank() {
        return rank;
    }
	
    @Override
    public String toString() {
        return "Actor [name=" + name + ", rank=" + rank + "]";
    }	
}

// Sorts using Comparator by rank of Actor		
class ActorRankComparator implements Comparator&lt;Actor&gt;{

    public int compare(Actor actor1, Actor actor2) {
        return (actor1.getRank() &lt; actor2.getRank()) ?
            -1 : ((actor1.getRank() == actor2.getRank()) ? 0 : 1);
    }
}

public class TestSearchElement {
    public static void main(String[] args) {
        Actor[] actors = new Actor[3];
        actors[0] = new Actor("Harry", 5);
        actors[1] = new Actor("IronMan", 2);
        actors[2] = new Actor("Batman", 7);
        
        System.out.println("Before sorting");
        for (Actor actor : actors)     
            System.out.println(actor);
        
        ActorRankComparator comparator = new ActorRankComparator();
        
        Arrays.sort(actors, comparator);
        
        System.out.println("After sorting");
        for (Actor actor : actors)     
            System.out.println(actor);
        
        System.out.println("index of actor Harry in sorted array  " +
            Arrays.binarySearch(actors, new Actor("Harry", 5), comparator));
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Before sorting
Actor [name=Harry, rank=5]
Actor [name=IronMan, rank=2]
Actor [name=Batman, rank=7]
After sorting
Actor [name=IronMan, rank=2]
Actor [name=Harry, rank=5]
Actor [name=Batman, rank=7]
index of actor Harry in sorted array  1
		</pre>
	</div>	
	

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html">Oracle Docs Arrays</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html#binarySearch-java.lang.Object:A-java.lang.Object-">Oracle Docs Arrays binarySearch()</a> <br><br>		
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html#binarySearch-T:A-T-java.util.Comparator-">Oracle Docs Arrays binarySearch() using Comparator</a> <br><br>		
	</div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>