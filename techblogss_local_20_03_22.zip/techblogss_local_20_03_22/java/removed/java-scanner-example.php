<?php 
    include("header.htm");
?>

<head>
    <title>Scanner Java example</title>
	<meta name="description" content="Scanner java example, how to use scanner in java, java scanner input." />
	<link rel="canonical" href="https://www.techblogss.com/java/java-scanner-example"/ >
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Scanner Java example</h1>
	  </div>

      <div id="solution">
      <p>A <b><i>Scanner</b></i> class is used to read input from the user. It can also be broken into tokens by using a delimiter pattern (default is whitespace).
      </p>
      <p>
      <b><i>Scanner</b></i> has buffer size of (1KB) which is less than buffer size (8KB) of <b><i>BufferedReader</b></i>,
            so if you are reading long String from a file, you can use <b><i>BufferedReader</b></i> class.
      </p>
    </div>
     
<h2>1) Example below shows how to use Scanner to read user input from command line</h2>
	<div id="code">
	<pre class="prettyprint">
// Reads user input using Scanner
import java.util.Scanner;

public class TestScanner {

    public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in);
    	 
    	System.out.print("Please enter your name");
    	String fullName = scanner.next();
    	 
    	System.out.print("Pleae enter your age");
    	int age = scanner.nextInt();
    	 
    	System.out.printf("Your full name is: %s, Your age is: %s  " , fullName, age);
    	scanner.close();
    }
}	</pre>
	</div>
	
	<div id="solution">
		<h3>Output : </h3>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Please enter your name John
Pleae enter your age 38
Your full name is: John, Your age is: 38  
		</pre>
	</div>
  
<br>
  
<h2>2) Read file with delimiter. Below is the file which contains mapping of hostname & ip address that you can read using Scanner</h2>

<p>Below is the file which contains mapping of hostname & ip address</p> 
	<b>hosts.txt file:</b>
	<div id="code">
    <pre class="prettyprint">
google:192.168.1.1
yahoo:192.168.1.2
gmail:192.168.1.3    </pre>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TestScanner {

    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(new File("C://hosts.txt"));) {
    	    while (scanner.hasNextLine()) {
    	        String line = scanner.nextLine();
                
    	        try (Scanner rowScanner = new Scanner(line)) {
    	            rowScanner.useDelimiter(":");
    	            while (rowScanner.hasNext()) {
    	                System.out.printf("host --> %s, ip --> %s %n", rowScanner.next(),
                            rowScanner.next());
    	            }
    	        }
    	    }
    	} catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}	</pre>
	</div>
	
	<div id="solution">
		<h3>Output : </h3>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
host --> google, ip --> 192.168.1.1 
host --> yahoo, ip --> 192.168.1.2 
host --> gmail, ip --> 192.168.1.3 		</pre>
	</div>   

    <br>
    
<h2>3) Read text file line by line using Scanner</h2>

<p>Below is the text file to read</p> 
	<b>story.txt file:</b>	
<div id="code">
	<pre class="prettyprint">
Once, a hare saw a tortoise walking slowly with a heavy shell on his back.
The hare was very proud of himself and he asked the tortoise. �Shall we have a race?"
The tortoise agreed. 
They started the running race. 
The hare ran very fast.
But the tortoise walked very slowly.
The proud hair rested under a tree and soon slept off. 
But the tortoise walked very fast, slowly and steadily and reached the goal.
At last, the tortoise won the race.</div>
</pre>    

    <div id="code">
	<pre class="prettyprint">
// Reads text file line by line using Scanner
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class TestScanner {

    public static void main(String[] args) {

    	try (Scanner scanner = new Scanner(new FileReader("C://story.txt"))) {
            while (scanner.hasNext()) {
                System.out.println(scanner.nextLine());
            }
    	} catch (FileNotFoundException e) {
            e.printStackTrace();
        } 
    }

}	</pre>
	</div>
	
	<div id="solution">
		<h3>Output : </h3>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Once, a hare saw a tortoise walking slowly with a heavy shell on his back.
The hare was very proud of himself and he asked the tortoise. �Shall we have a race?"
The tortoise agreed. 
They started the running race. 
The hare ran very fast.
But the tortoise walked very slowly.
The proud hair rested under a tree and soon slept off. 
But the tortoise walked very fast, slowly and steadily and reached the goal.
At last, the tortoise won the race.		</pre>
	</div>     

    <br>

<h2>4) Read integer, float from a text file</h2>

<p>Below is the text file to read</p> 
	<b>employee.txt file:</b>	
<div id="code">
	<pre class="prettyprint">
Mike 49 234545.60
John 34 12345.607</pre>
</div> 
   
    <div id="code">
	<pre class="prettyprint">
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class TestScanner {

    public static void main(String[] args) {

    	try (Scanner scanner = new Scanner(new FileReader("C://employee.txt"))) {
            while (scanner.hasNext()) {
                System.out.printf("Name %s , Age %d, Salary %f %n",  scanner.next(), scanner.nextInt(), scanner.nextFloat());
            }
    	} catch (FileNotFoundException e) {
            e.printStackTrace();
        } 
    }

}	</pre>
	</div>
	
	<div id="solution">
		<h3>Output : </h3>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Name Mike , Age 49, Salary 234545.593750 
Name John , Age 34, Salary 12345.607422 		</pre>
	</div>     
    
<br>
<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <a href="https://docs.oracle.com/javase/8/docs/api/java/util/Scanner.html" target="_blank">Oracle Docs Scanner</a>	<br><br>
    
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
