<?php 
    include("header.htm");
?>

<head>
    <title>Read csv file Java</title>
	<meta name="description" content="Read csv file java, java read csv file into arraylist." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_cj_readcsv"/ >
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Read csv file in Java</h1>
	  </div>

      <div id="solution">
      <p>To read csv file in Java, you first need to read each line from the file and then split the line by using ',' as delimiter.</p>
	  <p>You can read csv file in Java using <b><i>BufferedReader</b></i>, <b><i>Scanner</b></i> and also using third party library 
        <b><i>OpenCSV.</b></i></p>
       <p>Below is the CSV file you want to parse</p> 
      </div>
      
    
	<b>person.csv file:</b>

	<div id="code">
    <pre class="prettyprint">
1,123,John,40
2,234,Michelle,35
3,456,Mike,25    </pre>	</div><br>

<h3>1) Read csv file using BufferedReader, FileReader</h3>
	<div id="code">
	<pre class="prettyprint">
// Reads csv file using FileReader
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestCSVReader {

    public static void main(String[] args) {

        String line = "";
        try (BufferedReader br = new BufferedReader(new FileReader("C://person.csv"))) {
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] person = line.split(",");

                System.out.printf("[ID] %s [Name] %s [Age] %s", person[1], person[2], person[3]);
                System.out.println();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } 

    }
}	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[ID] 123 [Name] John [Age] 40
[ID] 234 [Name] Michelle [Age] 35
[ID] 456 [Name] Mike [Age] 25
		</pre>
	</div>
    <br>
    
<h3>2) Read csv file using Scanner</h3>
	<div id="code">
	<pre class="prettyprint">
// Reads csv file using Scanner 
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TestCSVReader {

    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(new File("C://person.csv"));) {
    	    while (scanner.hasNextLine()) {
    	        String line = scanner.nextLine();
                
    	        try (Scanner rowScanner = new Scanner(line)) {
    	            rowScanner.useDelimiter(",");
    	            while (rowScanner.hasNext()) {
    	                System.out.print(rowScanner.next() + " ");
    	            }
    	            System.out.println();
    	        }
    	    }
    	} catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
1 123 John 40 
2 234 Michelle 35 
3 456 Mike 25 
		</pre>
	</div>   
    <br>

<h3>3) Read csv file using OpenCSV</h3>
<p>You need to downlod opencsv jar from here <a href="https://repo1.maven.org/maven2/com/opencsv/opencsv/4.6/opencsv-4.6.jar">opencsv-4.6.jar</a></p>
	
<div id="code">
	<pre class="prettyprint">
&lt;dependency>
    &lt;groupId>com.opencsv&lt;/groupId>
    &lt;artifactId>opencsv&lt;/artifactId>
    &lt;version>4.6&lt;/version>
&lt;/dependency>
</div>
</pre>    
    <div id="code">
	<pre class="prettyprint">
// Reads csv file using OpenCSV 
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.opencsv.CSVReader;

public class TestCSVReader {

    public static void main(String[] args) {

    	try (CSVReader csvReader = new CSVReader(new FileReader("C://person.csv"))) {
            String[] line;
            while ((line = csvReader.readNext()) != null) {
                System.out.printf("[ID] %s [Name] %s [Age] %s", line[1], line[2], line[3]);
                System.out.println();
            }
    		csvReader.close();
    	} catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[ID] 123 [Name] John [Age] 40
[ID] 234 [Name] Michelle [Age] 35
[ID] 456 [Name] Mike [Age] 25
		</pre>
	</div>      
<br>

  <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <a href="http://opencsv.sourceforge.net/">OpenCSV Library</a>	<br><br>
    
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
