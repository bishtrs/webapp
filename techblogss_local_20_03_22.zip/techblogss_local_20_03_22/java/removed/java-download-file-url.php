<?php 
    include("header.htm");
?>

<head>
    <title>Java download file from url</title>
	<meta name="description" content="Java download file from url" />
	<link rel="canonical" href="https://www.techblogss.com/java/java-download-file-url"/ >
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
        <div id="problem">
		<h1>How to download a file from url in Java ?</h1>
	  </div>

      <h3>You can download a file from a URL in Java in following ways:</h3>
        
<h4>1) Download file from a URL using java.net.URL & BufferedInputStream</h4>
	<div id="code">
	<pre class="prettyprint">
// Download file from URL	
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

public class DownloadFileFromURL {
	
    public static void main(String[] args) {
            
        String url = "https://www.oracle.com/java/technologies/#chapter1";
        String fileName = "C://chapter1.txt";
            
        try (BufferedInputStream inputStream = new BufferedInputStream(new URL(url).openStream());
            FileOutputStream fileOS = new FileOutputStream(fileName)) {
                
            byte data[] = new byte[1024];
            int byteContent;
            while ((byteContent = inputStream.read(data, 0, 1024)) != -1) {
                fileOS.write(data, 0, byteContent);
            }
                
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>
	<br>
	
<h4>2) Download file from a URL using java.net.URL & java nio Files</h4>
	<div id="code">
	<pre class="prettyprint">
// Download file from URL	
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class DownloadFileFromURL {
	
    public static void main(String[] args) {
            
        String url = "https://www.oracle.com/java/technologies/#chapter1";
        String fileName = "C://chapter1.txt";
            
        try {
            InputStream inputStream = new URL(url).openStream();
            Files.copy(inputStream, Paths.get(fileName), StandardCopyOption.REPLACE_EXISTING);
                
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

	</pre>
	</div>
	<br>

<h4>3) Download file from a URL using Java NIO</h4>
	<div id="code">
	<pre class="prettyprint">
// Download file from URL	
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class DownloadFileFromURL {
	
    public static void main(String[] args) {
            
        String url = "https://www.oracle.com/java/technologies/#chapter1";
        String fileName = "C://chapter1.txt";
            
        try {
            URL website = new URL(url);
            ReadableByteChannel rbc = Channels.newChannel(website.openStream());
            FileOutputStream fos = new FileOutputStream(fileName);
            fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
            fos.close();
            rbc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>
	<br>

<h4>4) Download file from a URL using Apache commons IO utility</h4>

    <div>
        First you need to download apache commons io 2.6 from this location <br><a href="https://mvnrepository.com/artifact/commons-io/commons-io/2.6" 
        target="_blank">
        https://mvnrepository.com/artifact/commons-io/commons-io/2.6</a>
    </div>

	<div id="code">
	<pre class="prettyprint">
// Download file from URL	
import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.apache.commons.io.FileUtils;

public class DownloadFileFromURL {
	
    public static void main(String[] args) {
            
        String url = "https://www.oracle.com/java/technologies/#chapter1";
        String fileName = "C://chapter1.txt";
            
        try {
            FileUtils.copyURLToFile(new URL(url), new File(fileName));
                
            // with connection, read timeout
            FileUtils.copyURLToFile(new URL(url), new File(fileName), 10000, 10000);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

	</pre>
	</div>
	<br>
	
    References :  <a href="https://docs.oracle.com/javase/7/docs/api/java/net/URL.html">Oracle Docs URL</a>
    
	</div> <!-- blog div-->
    
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
