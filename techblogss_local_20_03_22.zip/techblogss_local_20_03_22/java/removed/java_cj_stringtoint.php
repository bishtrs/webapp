<?php 
    include("header.htm");
?>

<head>
    <title>How to convert String to Integer in Java</title>
	<meta name="description" content="How to convert String to Integer in Java." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_cj_stringtoint" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to convert String to Integer ?</h1>
	</div>
	
	<div id="solution">
		<h3>1) Convert String to Integer using Integer.parseInt()</h3>
    </div>
	<div id="code">
    <pre class="prettyprint">
// converts String to Integer
public class MyClass {
    public static void main(String[] args) {
        String number = "20";
        int num = Integer.parseInt(number);
        System.out.println(num); // prints 20
    }
}    </pre>
	</div><br>

Reference: <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Integer.html#parseInt-java.lang.String-">Integer.parseInt() Java 8 Docs</a>	<br>

    <div id="solution">
		<h3>2) Convert String to Integer using Integer.valueOf()</h3>
	</div>	

	<div id="code">
    <pre class="prettyprint">
// converts String to Integer
public class MyClass {
    public static void main(String[] args) {
	    String number = "20";
        Integer numObject = Integer.valueOf(number); 
        System.out.println(numObject); // prints 20
    }
}    </pre>
	</div><br>
    
Reference: <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Integer.html#valueOf-int-">Integer.valueOf() Java 8 Docs</a>
	
    <div id="solution">
		<h3>3) NumberFormatException is thrown if you try to pass invalid String while converting String to Integer</h3>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
// converts String to Integer
public class MyClass {
    public static void main(String[] args) {
        String str = "random";
        // throws NumberFormatException  as invalid data is passed
        int num = Integer.parseInt(str); 
		// throws NumberFormatException  as invalid data is passed
        Integer numObject = Integer.valueOf(str); 
    }
}    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Exception in thread "main" java.lang.NumberFormatException: For input string: "random"
	at java.lang.NumberFormatException.forInputString(Unknown Source)
	at java.lang.Integer.parseInt(Unknown Source)
	at java.lang.Integer.parseInt(Unknown Source)
	at MyClass.main(MyClass.java:5)
		</pre>
	</div>
    <br>
    
     <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
Reference: <a href=	"https://docs.oracle.com/javase/8/docs/api/java/lang/NumberFormatException.html">NumberFormatException Java 8 Docs</a>
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>