<?php 
    include("header.htm");
?>
<head>
    <title>Annotations in Java</title>
	<meta name="description" content="Annotations in Java, Java Annotations example" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_cj_annotations" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Annotations in Java</h1>
        
	</div>
	<div id="solution">
		<h3>Using built in Java Annotations in java.lang package</h3>
	</div>
    <h4>a) Using @Override annotation</h4>
    <p><b><i>@Override</b></i> annotation indicates that a method declaration is intended to override a method declaration in a supertype.
    If you use <b><i>@Override</b></i> annotation and do not implement right method, you will get compilation error.</p>
	<div id="code">
	<pre class="prettyprint">
public class AnnotationTest extends Thread {
	
    @Override
    public void test() {
        System.out.println("Thread Running");
    }

}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
C:\Dev\eclipse\workspace\techblogss\src>javac AnnotationTest.java
AnnotationTest.java:3: error: method does not override or implement a method from a supertype
        @Override
        ^
1 error
		</pre>
	</div>
	<p>In order to fix compilation error you need to  implement run() method and use <b><i>@Override</b></i> on this method.</p>
	<div id="code">
	<pre class="prettyprint">
public class AnnotationTest extends Thread {
	
    @Override
    public void test() {
        System.out.println("Thread Running");
    }

}
	</pre>
	</div>
    <br>
<h4>b) Using @Deprecated annotation</h4>
    <p>If a class or method is deprecated you can mark it deprecated using <b><i>@Deprecated</b></i> annotation. If you use such class or method,
    compiler will give warning. </p>
	<div id="code">
	<pre class="prettyprint">
public class AnnotationTest {
	
    public static void main(String[] args) {
        Message message = new Message();
        message.test();
    }
}

class Message {
	
    @Deprecated
    public void test() {
        System.out.println("test called");
    }
}

	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
C:\Dev\eclipse\workspace\techblogss\src>javac AnnotationTest.java
Note: AnnotationTest.java uses or overrides a deprecated API.
Note: Recompile with -Xlint:deprecation for details.
		</pre>
	</div>
    <p>In addition, the <b><i>@Deprecated</b></i> annotation causes the javadoc-generated documentation to be marked "Deprecated" wherever that program element appears.
    Following example shows how to use the @deprecated Javadoc tag.</p>
 <div id="code">
	<pre class="prettyprint">   
public class AnnotationTest {
	
    /**
     * @deprecated  As of release 1.4
     */
    @Deprecated public String message() {
        return "message";
    }
	
}
</pre>
	</div>

    <br>
    <h4>c) Using @SuppressWarnings annotation</h4>
    <p><b><i>@SuppressWarnings</b></i> annotation indicates that the named compiler warnings should be suppressed in the annotated element.
    If you use <b><i>@SuppressWarnings</b></i> in above example, compiler will not give warning.</p>
	<div id="code">
	<pre class="prettyprint">
public class AnnotationTest {
    @SuppressWarnings(value={"deprecation"})
    public static void main(String[] args) {
        Message message = new Message();
        message.test();
    }
}

class Message {
	
    @Deprecated
    public void test() {
        System.out.println("test called");
    }
}

	</pre>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
C:\Dev\eclipse\workspace\techblogss\src>javac AnnotationTest.java
		</pre>
	</div>
    <br>
    
    <h4>d) Using @SuppressWarnings("unchecked") annotation to suppress warning</h4>
    <p>Below example shows how to suppress warning with <b><i>@SuppressWarnings("unchecked")</b></i> annotation.</p>
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

public class AnnotationTest {
	
    public static void main(String[] args) {
        List&lt;String&gt; list = new ArrayList();
        System.out.println(list);
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
C:\Dev\eclipse\workspace\techblogss\src>javac AnnotationTest.java
Note: AnnotationTest.java uses unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details.
	</pre>
	</div>
    
    <p>Apply <b><i>@SuppressWarnings("unchecked")</b></i> annotation on list or to main() method</p>
    
    <div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

public class AnnotationTest {
	
    public static void main(String[] args) {
        @SuppressWarnings("unchecked")
        List&lt;String&gt; list = new ArrayList();
        System.out.println(list);
    }

}
	</pre>
	</div>
    
    <br>
    
     <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

    References:  
    <ul>
    <li><a href ="https://docs.oracle.com/javase/tutorial/java/annotations/basics.html">Annotations basics</a></li><br>
    <li><a href="https://docs.oracle.com/javase/8/docs/technotes/guides/javadoc/deprecation/deprecation.html">Oracle docs Deprecated Annotation</li><br>
    <li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/SuppressWarnings.html">Oracle docs SuppressWarnings Annotation</li><br>
    <li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Override.html">Oracle docs Override Annotation</li>
	</ul>
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
</body>

<?php 
    include("footer.htm");
?>

</html>
