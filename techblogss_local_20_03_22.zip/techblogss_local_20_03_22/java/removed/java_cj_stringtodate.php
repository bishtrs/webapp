<?php 
    include("header.htm");
?>

<head>
    <title>How to convert String to Date in Java</title>
	<meta name="description" content=">How to convert String to Date in Java, How to convert String to Date" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_cj_stringtodate" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="blog">
	
	<div id="problem">
		<h1>How to convert String to Date in Java ?</h1>
	</div>
	
	<div id="solution">
		<h2>You convert String to Date in Java using SimpleDateFormat</h2>
    </div>
    
    <h4>a) Example below shows how to convert String to Date with day, month, year</h4>
	<div id="code">
    <pre class="prettyprint">
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
    
// converts String to Date
public class StringToDateTest {
    public static void main(String[] args) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String dateInString = "2017-10-01";
    	Date date = null;

    	try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println(formatter.format(date));
        
        formatter = new SimpleDateFormat("dd/MM/yyyy");
        dateInString = "01/10/2017";

    	try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        System.out.println(formatter.format(date));
       
        formatter = new SimpleDateFormat("EEE, MMM d, yy");
        dateInString = "Wed, Jul 4, 01";

    	try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        System.out.println(formatter.format(date));
    }
}
    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
2017-10-01
01/10/2017
Wed, Jul 4, 01
</pre>
	</div>	

    <h4>b) Example below shows how to convert String to Date with hours, minute, seconds</h4>
	<div id="code">
    <pre class="prettyprint">
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
    
// converts String to Date
public class StringToDateTest {
    public static void main(String[] args) {
    	Date date = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        String dateInString = "2017-10-01 15:23:01";

    	try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        System.out.println(formatter.format(date));
        
        formatter = new SimpleDateFormat("h:mm:s a");
        dateInString = "12:08:20 PM";

    	try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        System.out.println(formatter.format(date));
        
    }
}
    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
2017-10-01 15:23:01
12:08:20 PM
</pre>
	</div>	
    
   <h4>c) Example below shows how to convert String to Date with timezone. You can list of all TimeZone ids using TimeZone getAvailableIDs() method.</h4>
	<div id="code">
    <pre class="prettyprint">
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
    
// converts String to Date
public class StringToDateTest {
    public static void main(String[] args) {
    	Date date = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z");
        
        String dateInString = "2017-10-01 15:23:01 PDT";

    	try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        System.out.println(formatter.format(date));
        
        dateInString = "2017-10-01 15:23:01 IST";

    	try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        System.out.println(formatter.format(date));
        
        // set timezone using TimeZone
        formatter.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));
        System.out.println(formatter.format(date));
        formatter.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));
        System.out.println(formatter.format(date));
        
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"))
        System.out.println(formatter.format(date));
    }
}
    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
2017-10-01 15:23:01 -0700
2017-10-01 15:23:01 +0530
2017-10-01 11:53:01 +0200
2017-10-01 09:53:01 +0000
</pre>
	</div>	    
    <br><br>
 
Reference: <a href=	"https://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html">Java 8 Docs SimpleDateFormat</a>

  <!-- ADU1 -->
	<?php include("../sidebar/ad.htm"); ?>
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>