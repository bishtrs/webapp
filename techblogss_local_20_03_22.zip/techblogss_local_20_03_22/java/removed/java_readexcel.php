<?php 
    include("header.htm");
?>

<head>
    <title>Read Excel in Java</title>
	<meta name="description" content="Read Excel in Java, Read Excel File in Java."/>
	<link rel="canonical" href="https://www.techblogss.com/java/java_readexcel">
    <meta property="og:title" content="How to read Excel file in Java" />
    <meta name="twitter:title" content="How to read Excel file in Java" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
    <div id="content">
	<div id="problem">
		<h1>Read Excel in Java</h1>
	
		<h4>You can read Excel files in Java using open source library called Apache POI.</h4>
        <p>Apache POI library provides two types of implementations <b><i>HSSF</b></i> and <b><i>XSSF</b></i>. 
        <b><i>HSSF</b></i> (Horrible SpreadSheet Format is used to work with excel files of the older binary file format - .xls while
        <b><i>XSSF</b></i> (XML SpreadSheet Format) is used to work with the newer XML based file
        format - .xlsx. Example below shows how to read Excel file in java using poi example</p>
	</div>
	
	<div id="solution">
		First you need to download following Apache POI libraries <br><br>
        <a href="https://mvnrepository.com/artifact/org.apache.poi/poi-ooxml/3.17">poi-ooxml-3.17</a> (Click to download)<br>
        <a href="https://mvnrepository.com/artifact/org.apache.poi/poi/3.17">poi-3.17</a> (Click to download)<br>
        <a href="https://mvnrepository.com/artifact/org.apache.xmlbeans/xmlbeans/2.5.0">xmlbeans-2.5.0</a> (Click to download)<br>
        <a href="https://mvnrepository.com/artifact/org.apache.commons/commons-collections4/4.1">commons-collections4-4.1</a> (Click to download)<br>
        <a href ="https://mvnrepository.com/artifact/org.apache.poi/ooxml-schemas/1.0">ooxml-schemas-1.0.jar</a> (Click to download)<br>
	</div>
	<br>
    
    <div>
        <p>Excel Data to Read (Employee.xlsx) </p>
        <p><img src="../images/read_excel.jpg" alt="Excel Data" style="width:350px;height:100px;"></p>
    </div><br><br><br><br><br>

<div id="code">
<pre class="prettyprint"> 
// Reads Excel file in Java    
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
 
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
				
public class Test {
    public static void main(String[] args) {
        FileInputStream inputStream = null;
        try {		
            inputStream = new FileInputStream(new File("C://Employee.xlsx"));
        } catch (IOException e) {
            e.printStackTrace();
        }  
			
        Workbook workbook = null;
        try {
            workbook = new XSSFWorkbook(inputStream);
        } catch (IOException e1) {
            e1.printStackTrace();
        }        
        
        Sheet sheet = workbook.getSheetAt(0);
        Iterator&lt;Row&gt; iterator = sheet.rowIterator();
        
        // DataFormatter to format each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();
			
        while (iterator.hasNext()) { // iterates over rows
            Row row = iterator.next();
            Iterator&lt;Cell&gt; cellIterator = row.cellIterator();
				
            while (cellIterator.hasNext()) { 
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                System.out.print(cellValue + "  ");
            }
            System.out.println();
        }
			
        try {
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Employee Name ID Salary Department 
John Bocelli 123 140000 Engineering 
Harry Potter 124 160000 Human Resurces 
		</pre>
	</div>    
	
	<div id="comments">
	
	</div>
    </div>
    
</body>

<?php 
    include("footer.htm");
?>
</html>
