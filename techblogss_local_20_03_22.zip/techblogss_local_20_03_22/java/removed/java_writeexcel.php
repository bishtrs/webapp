<?php 
    include("header.htm");
?>

<head>
    <title>Create excel file in java</title>
	<meta name="description" content="Create excel file in java, how to create excel sheet in java, format cells of a Excel file in java"/>
	<link rel="canonical" href="https://www.techblogss.com/java/java_writeexcel">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
    <div id="content">
	<div id="problem">
		<h1>Create Excel file in Java</h1>
	
		<h4>You can create excel file in Java using open source library called Apache POI library.</h4>
        <p>Apache POI library provides two types of implementations <b><i>HSSF</b></i> and <b><i>XSSF</b></i>. 
        <b><i>HSSF</b></i> (Horrible SpreadSheet Format is used to work with excel files of the older binary file format - .xls while
        <b><i>XSSF</b></i> (XML SpreadSheet Format) is used to work with the newer XML based file
        format - .xlsx.</p>

	</div>
	
	<div id="solution">
		You need to download following Apache POI libraries <br><br>
        <a href="https://mvnrepository.com/artifact/org.apache.poi/poi-ooxml/3.17">poi-ooxml-3.17</a> (Click to download)<br>
        <a href="https://mvnrepository.com/artifact/org.apache.poi/poi/3.17">poi-3.17</a> (Click to download)<br>
        <a href="https://mvnrepository.com/artifact/org.apache.xmlbeans/xmlbeans/2.5.0">xmlbeans-2.5.0</a> (Click to download)<br>
        <a href="https://mvnrepository.com/artifact/org.apache.commons/commons-collections4/4.1">commons-collections4-4.1</a> (Click to download)<br>
        <a href ="https://mvnrepository.com/artifact/org.apache.poi/ooxml-schemas/1.0">ooxml-schemas-1.0.jar</a> (Click to download)<br>
	</div>
	<br>
    
    <h4>1) Example below shows how to create Excel file in java using poi example</h4>
	<div id="code">
	<pre class="prettyprint">
import java.io.File;    
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
 
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
				
public class TestWriteExcel {
    public static void main(String[] args) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        // create a blank sheet        
        XSSFSheet sheet = workbook.createSheet("Employee");
			
        Map&lt;String, Object[]&gt; data = new HashMap&lt;String, Object[]&gt;();
        data.put("1", new Object[] {"ID", "NAME", "Salary"});
        data.put("2", new Object[] {1, "John Irwin", "150000"});
        data.put("3", new Object[] {2, "Jay Joseph", "170000"});
        data.put("4", new Object[] {3, "Matt French", "180000"});
			
        Set&lt;Map.Entry&lt;String, Object[]&gt;&gt; entry  = data.entrySet();
        int rownum = 0;
        
        for (Map.Entry&lt;String, Object[]&gt; pair : entry) {
            
            Row row = sheet.createRow(rownum++);
            Object [] values = pair.getValue();
            int cellnum = 0;
			
            // create cells in a row
            for (Object obj : values) {
                Cell cell = row.createCell(cellnum++);
                if(obj instanceof String) {
                    cell.setCellValue((String)obj);
                } else {
                    cell.setCellValue((Integer)obj);
                }
            }
        }
			
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File("E://Employee.xlsx"));
            workbook.write(out);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
			
    }   
}
	</pre>
	</div>

<div id="solution">
		<h4>Excel Data generated (Employee.xlsx) </h4>
	</div>

<div>
        <p>Excel Data to Read (Employee.xlsx) </p>
        <p><img src="../images/write_excel.jpg" alt="Excel Data" style="width:250px;height:100px;"></p>
    </div><br><br><br><br><br>

    <h4>2) Example below shows how to format cells of a Excel file in java using poi example. 
    Below program writes a header row for the document with bold font style and font size 14:</h4>
	<div id="code">
	<pre class="prettyprint">
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
				
public class TestWriteExcel {
    public static void main(String[] args) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        // create a blank sheet        
        XSSFSheet sheet = workbook.createSheet("Employee");

        // Header creation starts
        CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
        Font font = sheet.getWorkbook().createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 14);
        font.setColor(HSSFColor.BLUE.index);
        cellStyle.setFont(font);
 
        Row row = sheet.createRow(0);
        Cell cellTitle = row.createCell(0);
 
        cellTitle.setCellStyle(cellStyle);
        cellTitle.setCellValue("ID");
     
        Cell cellAuthor = row.createCell(1);
        cellAuthor.setCellStyle(cellStyle);
        cellAuthor.setCellValue("NAME");
     
        Cell cellPrice = row.createCell(2);
        cellPrice.setCellStyle(cellStyle);
        cellPrice.setCellValue("SALARY");
        // Header creation ends
    
        Map&lt;String, Object[]&gt; data = new HashMap&lt;String, Object[]&gt;();
        data.put("2", new Object[] {1, "John Irwin", "150000"});
        data.put("3", new Object[] {2, "Jay Joseph", "170000"});
        data.put("4", new Object[] {3, "Matt French", "180000"});
			
        Set&lt;Map.Entry&lt;String, Object[]&gt;&gt; entry  = data.entrySet();
        int rownum = 1;
        
        for (Map.Entry&lt;String, Object[]&gt; pair : entry) {
            
            row = sheet.createRow(rownum++);
            Object [] values = pair.getValue();
            int cellnum = 0;
			
            // create cells in a row
            for (Object obj : values) {
                Cell cell = row.createCell(cellnum++);
                if(obj instanceof String) {
                    cell.setCellValue((String)obj);
                } else {
                    cell.setCellValue((Integer)obj);
                }
            }
        }
			
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File("E://Employee.xlsx"));
            workbook.write(out);
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
			
    }   
}
	</pre>
	</div>

<div id="solution">
		<h4>Excel Data generated (Employee.xlsx) </h4>
	</div>

<div>
        <p>Excel Data to Read (Employee.xlsx) </p>
        <p><img src="../images/write_excel_format.jpg" alt="Excel Data" style="width:250px;height:100px;"></p>
    </div><br><br><br><br><br>
    </div>
			
</body>

<?php 
    include("footer.htm");
?>
</html>
