<?php 
    include("header.htm");
?>

<head>
    <title>LocalDate to Date Java</title>
	<meta name="description" content="LocalDate to Date Java, convert localdate to date, LocalDateTime to Date Java" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_j8_convertlocaldate" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h2>Convert LocalDate to Date in Java</h2>
	</div>

    <div id="solution">
		<h4>1) Convert LocalDate to Date & LocalDateTime to Date</h4>
	</div>
    
    <div id="code">
	<pre class="prettyprint">
// Converts LocalDate to Date Java
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class LocalDateToDate {

    public static void main(String[] args) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
		
        LocalDate localDate = LocalDate.of(2019, 8, 18);
        Date date = Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
        
        System.out.println("LocalDate is: " + localDate);
        System.out.println("Date is: " + date);
        
        LocalDateTime localDateTime = LocalDateTime.of(2019,8,18,00,00,0);
        date = Date.from(localDateTime.atZone(defaultZoneId).toInstant());
        System.out.println("Date is: " + date);
   }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
LocalDate is: 2019-08-18
Date is: Sun Aug 18 00:00:00 IST 2019
Date is: Sun Aug 18 00:00:00 IST 2019
        </pre>
	</div>	
    
  <div id="solution">
		<h4>2) Convert Date to LocalDate & Date to LocalDateTime</h4>
	</div>
    
    <div id="code">
	<pre class="prettyprint">
// Converts Date to LocalDate Java
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class DateToLocalDate {

    public static void main(String[] args) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
		
        Date date = new Date();
        LocalDate localDate = date.toInstant().atZone(defaultZoneId).toLocalDate();
        
        System.out.println("localDate is: " + localDate);
        System.out.println("Date is: " + date);
        
        LocalDateTime localDateTime = date.toInstant().atZone(defaultZoneId).toLocalDateTime();
        
        System.out.println("localDateTime is: " + localDateTime);
   }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
localDate is: 2019-08-18
Date is: Sun Aug 18 15:13:01 IST 2019
localDateTime is: 2019-08-18T15:13:01.988
        </pre>
	</div>	    
 
 <br>

References : <br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/LocalDate.html">Oracle Docs LocalDate</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/LocalDateTime.html">Oracle Docs LocalDateTime</a>	<br><br>
<a href ="https://www.techblogss.com/java/java_j8_datetime">Java 8 Date and Time API</a>	<br><br>
	</div>
	
<?php 
    include("footer.htm");
?>
	
</body>
</html>
