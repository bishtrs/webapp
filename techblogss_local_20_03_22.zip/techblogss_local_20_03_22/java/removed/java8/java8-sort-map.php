<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Sort Map</title>
	<meta name="description" content="Java 8 Sort Map, sort map by key in java 8, sort map by value in java 8, 
    sort map by key java, sort map by value java" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-sort-map" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h2>Java 8 Sort Map examples</h2>
	</div>

	<div id="solution">
		<h4>1) You can sort a Map by key in Java 8 by using <b><i>Stream</b></i> sorted() & Map.Entry.comparingByKey() method. </h4>
        <p><b><i>Map.Entry.comparingByKey()</b></i> returns a comparator that compares <b><i>Map.Entry</b></i> by natural order of key.</p>
	</div>

    
    	<div id="code">
	<pre class="prettyprint">
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// sorts a Map by key
public class SortMap {

    public static void main(String[] args) {
        Map&lt;String, Integer> map = new HashMap<>();
        map.put("John", 2);
        map.put("Mark", 1);
        map.put("Thomas", 4);
        map.put("James", 3);
        map.put("Edwin", 5);
        map.put("Vinod", 6);
        System.out.println(map);
	Stream&lt;Entry&lt;String, Integer>> stream 
            = map.entrySet().stream().sorted(Map.Entry.comparingByKey());
	
        LinkedHashMap&lt;String, Integer> sortedMap 
		= stream.collect(Collectors.toMap(e->e.getKey(), e->e.getValue(),
                (e1, e2) -> e2, LinkedHashMap::new));
	System.out.println(sortedMap);
	
    }

}	</pre>
	</div>
<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{Thomas=4, James=3, Edwin=5, John=2, Mark=1, Vinod=6}
{Edwin=5, James=3, John=2, Mark=1, Thomas=4, Vinod=6}
	</pre>
	</div>	
    <br>
    
    <div id="solution">
		<h4>2) You can sort a Map by value in Java 8 by using <b><i>Stream</b></i> sorted() & Map.Entry.comparingByValue() method. </h4>
        <p><b><i>Map.Entry.comparingByValue()</b></i> returns a comparator that compares <b><i>Map.Entry</b></i> by natural order of value.</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// sorts a Map by value
public class SortMap {

    public static void main(String[] args) {
        Map&lt;String, Integer> map = new HashMap<>();
        map.put("John", 2);
        map.put("Mark", 1);
        map.put("Thomas", 4);
        map.put("James", 3);
        map.put("Edwin", 5);
        map.put("Vinod", 6);
        System.out.println(map);
		
        Stream&lt;Entry&lt;String, Integer>> stream 
                = map.entrySet().stream().sorted(Map.Entry.comparingByValue());
            
        LinkedHashMap&lt;String, Integer> sortedMap = stream.collect(
            Collectors.toMap(e->e.getKey(), e->e.getValue(), (e1, e2) -> e2, LinkedHashMap::new));
		
        System.out.println(sortedMap);
		
    }

}
	</pre>
	</div>

<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{Thomas=4, James=3, Edwin=5, John=2, Mark=1, Vinod=6}
{Mark=1, John=2, James=3, Thomas=4, Edwin=5, Vinod=6}
	</pre>
	</div>	
	<br>

   <div id="solution">
		<h4>3) You can also sort a Map by any attribute of the Object which is stored as value by using <b><i>Stream</b></i> sorted() &
        Map.Entry.comparingByValue(Comparator&lt;? super V> cmp). </h4>
        <p><b><i>Map.Entry.comparingByValue(Comparator&lt;? super V> cmp)()</b></i> returns a Comparator that compares <b><i>Map.Entry</b></i> 
        by value using the given Comparator.</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// sorts a Map by value
public class SortMap {

    public static void main(String[] args) {
        Map&lt;Integer, Book> bookMap = new HashMap<>();
        bookMap.put(1, new Book("Lord of the Rings", "J. R. R. Tolkien"));
        bookMap.put(2, new Book("Silence of the Lambs", "Thomas Harris"));
        bookMap.put(3, new Book("The Bourne Identity", "Robert Ludlum"));
        bookMap.put(4, new Book("Day of the Jackal", "Frederick Forsyth"));
        System.out.println(map);
        
        Stream&lt;Entry&lt;Integer, Book>> stream 
            = bookMap.entrySet().stream().sorted(Map.Entry.comparingByValue(
            Comparator.comparing(Book::getTitle)));
		
        LinkedHashMap&lt;Integer, Book> sortedMap 
            = stream.collect(Collectors.toMap(e->e.getKey(), e->e.getValue(),
            (e1, e2) -> e2, LinkedHashMap::new));
        System.out.println(sortedMap);
		
    }

}
	</pre>
	</div>
    
<div id="code">
	<pre class="prettyprint">
class Book {
    private final String title;
    private final String author;
		
    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }
	
    public String getTitle() {
        return title;
    }
	
    public String getAuthor() {
        return author;
    }

    @Override
    public String toString() {
        return "Book [title=" + title + ", author=" + author + "]";
    }
	
}

</pre>
	</div>
<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{4=Book [title=Day of the Jackal, author=Frederick Forsyth], 1=Book [title=Lord of the Rings, author=J. R. R. Tolkien],
 2=Book [title=Silence of the Lambs, author=Thomas Harris], 3=Book [title=The Bourne Identity, author=Robert Ludlum]}
	</pre>
	</div>	
	<br>
    
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#sorted--" target="_blank">Oracle Docs Stream sorted()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Map.Entry.html" target="_blank">Oracle Docs Map.Entry</a>	<br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
