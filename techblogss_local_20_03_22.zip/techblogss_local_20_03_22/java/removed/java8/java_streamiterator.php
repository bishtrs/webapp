<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Stream Iterate</title>
	<meta name="description" content="Java 8 Stream Iterate examples." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_streamiterator" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>Java 8 Stream iterate example</h1>
	</div>

	<div id="solution">
		<h4>1) Java 8 filter iterate example to produce a Stream of even numbers upto 10</h4>
	</div>
	<div id="code">
	<pre class="prettyprint">
// produces a Stream of even numbers upto 10    
import java.util.stream.Stream;
	
public class TestClass {
    public static void main(String[] args) {
    	Stream&lt;Integer&gt;stream = Stream.iterate(0, n-> n+2).limit(5);
        stream.forEach(System.out::println);
    }
}	</pre>			
	</div>
	
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
0
2
4
6
8		</pre>
	</div>	<br>

<div id="solution">
		<h4>2) Java 8 filter iterate example to produce a Stream of numbers from 0-9</h4>
	</div>
	<div id="code">
	<pre class="prettyprint">
// produces a Stream of even numbers from 0-9   
import java.util.stream.Stream;
	
public class TestClass {
    public static void main(String[] args) {
    	Stream&lt;Integer&gt;stream = Stream.iterate(0, n-> n+1).limit(10);
        stream.forEach(System.out::println);
    }
}	</pre>			
	</div>
	
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
0
1
2
3
4
5
6
7
8
9	</pre>
	</div>	


References : <br><br>

<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#iterate-T-java.util.function.UnaryOperator-">Oracle Docs Stream iterate</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/function/UnaryOperator.html">Oracle Docs UnaryOperator</a>	

	</div>
</body>

<?php 
    include("footer.htm");
?>	

</html>
