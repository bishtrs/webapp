<?php 
    include("header.htm");
?>

<head>
    <title>Java Supplier example</title>
	<meta name="description" content="Java supplier example, supplier Java 8 example." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_j8_supplier" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>Java 8 Supplier example</h1>
        <p><b><i>Supplier</b></i> is a functional interface which never takes an argument and it always returns something. It was introduced in Java 8.
        It has just one method <b><i>T get();</b></i>
        </p>
	</div>
	
	<div id="solution">
		<h4>1) A simple Supplier example which returns a primitive type.</h4>
	</div>
	
    <div id="code">
	<pre class="prettyprint">
import java.util.function.Supplier;

public class TestSupplier {

    public static void main(String args[]) {
        Supplier&lt;Integer&gt; simpleSupplier = () -> 50;
        System.out.println(simpleSupplier.get()); // prints 50

        //Supplier without using Lambda expression
        simpleSupplier = new Supplier&lt;Integer&gt;() {
			
            @Override
            public Integer get() {
                return 60;
            }
        };
        System.out.println(simpleSupplier.get()); // prints 60
        
        Supplier&lt;String&gt; stringSupplier = () -> "hello";
        System.out.println(stringSupplier.get()); // prints hello
        
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
    
	<div id="solution">
		<h4>2) A Supplier example which returns a custom class obejct.</h4>
	</div>
	
    <div id="code">
	<pre class="prettyprint">
import java.util.function.Supplier;

public class TestSupplier {

    public static void main(String args[]) {
        Supplier&lt;Person&gt; simpleSupplier = () -> new Person("John");
        System.out.println(simpleSupplier.get().getName()); // prints "John"
    }
}

class Person {
    
    private String name;
    
    public Person(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }

}
	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>    

	<div id="solution">
		<h4>3) IntSupplier example</h4>
        <p><b><i>IntSupplier</b></i>  is primarily used to avoid autoboxing in case you want a primitive, rather than an object, back from the supplier.
        <b><i>IntSupplier</b></i> doesn't use a type parameter, because the functional method returns a primitive</p>
	</div>
	
    <div id="code">
	<pre class="prettyprint">
import java.util.Random;    
import java.util.function.IntSupplier;

public class TestSupplier {

    public static void main(String args[]) {
        IntSupplier random = () -> new Random().nextInt(80);
        int intRandom = random.getAsInt();
        System.out.println(intRandom);
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>

 
 <br>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/function/Supplier.html">Oracle Docs Supplier</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/function/IntSupplier.html">Oracle Docs IntSupplier</a>	<br><br>

</div>
	
<?php 
    include("footer.htm");
?>
	
</body>
</html>
