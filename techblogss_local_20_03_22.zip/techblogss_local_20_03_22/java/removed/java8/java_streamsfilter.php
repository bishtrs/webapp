<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Stream Filter</title>
	<meta name="description" content="Java 8 Stream Filter examples" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_streamsfilter" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>Java 8 Stream Filter examples</h1>
	</div>

	<div id="solution">
		<h4>1) Java 8 Stream Filter example using List</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Filters List using Stream Filter
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
    
public class TestClass { 

    public static void main(String[] args) {
        List&lt;String&gt; fruits = Arrays.asList("mango", "apple",
			"pineapple", "orange", "apple");
        List&lt;String&gt; filteredList = fruits.stream() // convert list to stream
            .filter(fruit -> !"apple".equals(fruit))
            .collect(Collectors.toList());         
         
         filteredList.forEach(System.out::println);    
    }
}	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
mango
pineapple
orange
	</pre>
	</div>	<br>
    
	<div id="solution">
		<h4> 2) Java 8 Stream Filter example using Map</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
	
class Celebrity  {
    private String name;
    private int rank;
	
    Celebrity (String name, int rank) {
        this.name = name;
        this.rank = rank;
    }
	
    public String getName() {
        return name;
    }
	
    public int getRank() {
        return rank;
    }
}
	
public class TestClass { 

    public static void main(String[] args) {
        Celebrity celebrity1 = new Celebrity("Harry", 1);
        Celebrity celebrity2 = new Celebrity("IronMan", 3);
        Celebrity celebrity3 = new Celebrity("Batman", 2);
			
        List&lt;Celebrity&gt; celebrities = new ArrayList&lt;Celebrity&gt;();
        celebrities.add(celebrity1);
        celebrities.add(celebrity2);
        celebrities.add(celebrity3);
			
        /* get list of celebrity names using map & filter celebrities with 
			rank > 1 & get the name of celebrities as List */
        List&lt;String&gt; celebrityNames = celebrities.stream()
			.filter(r -> r.getRank() > 1).map(
				c -> c.getName()).collect(Collectors.toList());
				
        System.out.println(celebrityNames);  // prints [IronMan, Batman]
    }
}		</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[IronMan, Batman]	</pre>
	</div>	<br>
	
	<div id="solution">
		<h4>3) Filter a List of String which has first character as 'A'</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Filters Stream 
import java.util.Arrays;
import java.util.List;
    
public class TestClass { 

    public static void main(String[] args) {
        List&lt;String&gt; fruits = Arrays.asList("Mango", "Apple", "Pineapple", "Orange", "Avocado");
        fruits.stream().filter(fruit -> fruit.startsWith("A")) //filter stream 
            .forEach(System.out::println);     // print stream     

    }
}		</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Apple
Avocado	</pre>
	</div>	<br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#filter-java.util.function.Predicate-">Oracle Docs Stream filter</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/util/function/Predicate.html">Oracle Docs Predicate</a>
	</div>
</body>

<?php 
    include("footer.htm");
?>

</html>
