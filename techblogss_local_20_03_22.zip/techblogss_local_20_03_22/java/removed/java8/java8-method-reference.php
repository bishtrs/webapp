<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Method Reference</title>
	<meta name="description" content="This tutorial explains various kinds of method reference in Java 8" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-method-reference" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="blog">
	<div id="problem">
		<h1>Java 8 Method Reference</h1>
		<p>Sometimes, the only thing a <b><i>lambda expressions</b></i> does is call another method, for instance</p>
    <div id="code">
	<pre class="prettyprint">
List&lt;String> fruits = Arrays.asList("apple", "banana", "mango");
fruits.forEach(f -> System.out.println(f));   </pre>	</div>

        <p>Though above code is already pretty short, we can shorten it even more by using <b><i>Method references</b></i> introduced in Java 8.
        They are shorthand <b><i>lambda expressions</b></i> for methods that already have a name.<br><br>
        </p>
	</div>

    <h2>There are four types of method references in Java explained below</h2><br>
    
	<div id="solution">
		<h3>1) Method Reference to a static Method (syntax ContainingClass::staticMethodName)</h3>
	</div>
    
    <div id="code">
	<pre class="prettyprint">
// Refers a static method to it's functional method add().    
import java.util.function.BiFunction;
	
public class TestClass { 
    public static void main(String[] args) {
        BiFunction&lt;Integer, Integer, Integer&gt; output = TestClass::add;
        int out = output.apply(11, 5);
        System.out.println(out); // prints 16
    }
	
    public static int add(int a, int b){  
        return a + b;
    }
}  	</pre>
	</div>	<br>
	
	<div id="solution">
		<h3>2) Method reference to an instance method of an object of a particular type  (syntax ContainingType::methodName) </h3>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
// Refers to an instance method of an particular object    
import java.util.Arrays;
	
public class TestClass { 
    public static void main(String[] args) {
        String[] fruits = { "WaterMellon", "Mango", "Banana", "Apple"};
        
        // The method reference would invoke the method a.compareToIgnoreCase(b).
        Arrays.sort(fruits, String::compareToIgnoreCase);
        for(String fruit: fruits){
            System.out.println(fruit);
        }
    }

}    	</pre></div>	<br>
	
	<div id="solution">
		<h3>3) Method Reference to an Instance Method of a particular Object (syntax containingObject::instanceMethodName)</h3>
	</div>
     
	<div id="code">
	<pre class="prettyprint">
// Refers an instance method of an object add().        
import java.util.function.BiFunction;
	
public class TestClass { 
    public static void main(String[] args) {
        TestClass testClass = new TestClass();
        BiFunction&lt;Integer, Integer, Integer&gt; output = testClass::add;
        int out = output.apply(11, 5);
        System.out.println(out); // prints 16
    }
	
    public int add(int a, int b){  
        return a + b;
    }
}  	</pre>
	</div>
	
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Apple
Banana
Mango
WaterMellon		</pre>	</div>	<br>

    <p>
    The method reference <b>employeeComparator::compareByName</b> invokes the method compareByName that is part of the object employeeComparator.
    </p>

<div id="code">
	<pre class="prettyprint">
import java.util.Arrays;

public class TestClass { 

    public static void main(String[] args) {
        Employee employee1 = new Employee("Mark", 40);
        Employee employee2 = new Employee("John", 50);
		
        Employee[] employees = new Employee[2];
        employees[0] = employee1;
        employees[1] = employee2;
        EmployeeComparator employeeComparator = new EmployeeComparator();

        for (Employee employee : employees) {
            System.out.println(employee);
        }
		
        Arrays.sort(employees, employeeComparator::compareByName);
        System.out.println("After sorting");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}

class EmployeeComparator {
    public int compareByName(Employee a, Employee b) {
        return a.getName().compareTo(b.getName());
    }
        
}

class Employee {
    
    private int age;
    private String name;
		
    public Employee(String name, int age) {
        this.name = name;
        this.age = age;
    }
		
    public String getName() {
        return this.name;
    }
		
    public int getAge() {
        return this.age;
    }

    @Override
    public String toString() {
        return "Employee [age=" + age + ", name=" + name + "]";
    }
    
    
}
</pre>
	</div>
	
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Employee [age=40, name=Mark]
Employee [age=50, name=John]
After sorting
Employee [age=50, name=John]
Employee [age=40, name=Mark]	</pre>	</div>	<br>
	
<div id="solution">
		<h3>4) Method Reference to a constructor (format ClassName::new)    </h3>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
// Refers to constructor    
public interface TestClassInterface {
    TestClass print();
}
	
public class TestClass { 
    public static void main(String[] args) {
    	<span class="highlight">TestClassInterface testClass = TestClass::new</span>;
        testClass.print();
    }
	
    public void print() {
        System.out.println("Hello");
    }
} 
	</pre>
	</div>
<br>

<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
Reference : <a href="https://docs.oracle.com/javase/tutorial/java/javaOO/methodreferences.html" target="_blank">https://docs.oracle.com/javase/tutorial/java/javaOO/methodreferences.html</a>	
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
	
	 <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>
<?php 
    include("footer.htm");
?>
</html>
