<?php 
    include("header.htm");
?>

<head>
    <title>Default Methods In Java 8</title>
	<meta name="description" content="Default Methods In Java 8" />
	<link rel="canonical" href="https://www.techblogss.com/java/java8-default-methods">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h1>Default Methods In Java 8</h1>
	</div>
	
	<div id="solution">
		<h4>In Java 8, interfaces can include methods with concrete implementations. These concrete methods are called <i>default</i> methods.</h4>
	</div>
    <p>
    Few points related to <b><i>default</b></i> methods:
    <ul>
        <li><b><i>default</b></i> keyword can be used only with interface method, not class method signatures.</li>
        <li><b><i>default</b></i> methods must have a concrete method body.</li>
        <li><b><i>default</b></i> methods are <b><i>public</b></i> by definition and the <b><i>public</b></i> modifier is optional.</li>
    </ul>
    </p>
	
    <h4>Example of default Method</h4>
	<div id="code">
	<pre class="prettyprint">
interface Flyable {
    default boolean fly() {
        return true;
    }
}
	</pre>	
	</div>
	
    <br>
	<h3>Multilpe interfaces with same default method</h3>
    <div id="solution">
		<p>Suppose there are two interfaces with same <b><i>default</b></i> method and a class <b><i>Hen</b></i> implements both the interfaces.</p>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
interface Flyable {
    default boolean fly() {
        return true;
    }
}
</pre>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
interface Walkable {
    default boolean fly() {
        return false;
    }
}
</pre>
	</div>
    <br>

<p>Note that <b><i>Hen</b></i> class below will not compile if you don't implement fly() method again, because it's not clear which version
        of fly() should be used.</p>

<div id="code">
		<pre class="prettyprint">
public class Hen implements Flyable, Walkable {
    public static void main(String[] args) {
        new Hen().fly();
    }
    
} 
</pre>
	</div>
    
<p>Below code will compile</p>


<div id="code">
		<pre class="prettyprint">
public class Hen implements Flyable, Walkable {
    public static void main(String[] args) {
        new Hen().fly();
    }
    
    public boolean fly() {
        return true;
    }
}

</pre>
	</div>	    
    
    <br>
    
    <div id="solution">
        <h2>Declaring static methods in Interface</h2>
		<p>In Java 8, interfaces can include <b><i>static</b></i> methods with concrete implementations.</p>
	</div>
    
    <p>
    Few points related to <b><i>static</b></i> methods:
    <ul>
        <li><b><i>static</b></i> methods in interface can be invoked only by using interface name.</li>
        <li><b><i>static</b></i> methods must have a concrete method body.</li>
        <li><b><i>static</b></i> methods are <b><i>public</b></i> by definition and the <b><i>public</b></i> modifier is optional.</li>
    </ul>
    </p>
    
    	<div id="code">
		<pre class="prettyprint">
interface Flyable {
    static boolean fly() {
        return true;
    }
}
</pre>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
interface Walkable {
    static boolean fly() {
        return false;
    }
}
</pre>
	</div>
    
    <div id="code">
		<pre class="prettyprint">
        
public class Hen implements Flyable, Walkable {
    public static void main(String[] args) {
        System.out.println(Flyable.fly());
        System.out.println(Walkable.fly());
    }
    
}

</pre>
	</div>	 
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
    References
	<ul>
		<li><a href ="https://docs.oracle.com/javase/tutorial/java/IandI/defaultmethods.html">Oracle Docs Default Methods</a></li><br>
	</ul>
	
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>	
</body>

<?php 
    include("footer.htm");
?>

</html>
