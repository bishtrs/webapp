<?php 
    include("header.htm");
?>

<head>
    <title>How to stop thread in Java</title>
	<meta name="description" content="How to stop thread in java using a boolean flag or using interrupt method" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_threads_threadstop /">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>How to stop thread in Java ?</h1>
        <p>A Java thread can be stopped in following ways:</p>
	</div>
	<div id="solution">
		<h4>1) Use boolean flag to check if running thread should be stopped</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
	
// stops thread     
public class MyThread implements Runnable {

    private final List&lt;BigInteger&gt;primes = new ArrayList&lt;BigInteger&gt;();
    private volatile boolean isCancelled = false;

    public void run() { 
        BigInteger b = BigInteger.ONE;
		
        while(!isCancelled) {
            System.out.println("Thread running");
            System.out.println(primes);
            b = b.nextProbablePrime();
        
            synchronized (this) {
                primes.add(b);
            }
        }
    }
			
    public void cancel() { 
        isCancelled = true;
    }
	
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        Thread thread = new Thread(myThread);
        thread.start();
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) { 
            e.printStackTrace();
        }        
		
        myThread.cancel();
    }

}
	</pre>
	</div>

    <div id="solution">
		<h4>Output (may vary on each run and different system): </h4>
	</div>
<div id="code">
		<pre class="prettyprint">
Thread running
[]
Thread running
[2]
Thread running
[2, 3]
Thread running
[2, 3, 5]
Thread running
[2, 3, 5, 7]
Thread running
[2, 3, 5, 7, 11]
Thread running
[2, 3, 5, 7, 11, 13]

		</pre>
	</div>	
<br>
<p>If however, a task that uses above approach calls a blocking method such as BlockingQueue.put,the thread might never
check the cancellation flag and therefore might never terminate. Hence it is not recommended to use above approach. See program below</p>
<br>

<div id="code">
	<pre class="prettyprint">
import java.math.BigInteger;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
	
// Unreliable cancellation that can leave producers stuck in a blocking operation.    
public class MyThread implements Runnable {

    private final BlockingQueue&lt;BigInteger&gt; queue = new ArrayBlockingQueue&lt;BigInteger&gt;(10);
    private volatile boolean isCancelled = false;

    public void run() { 
        BigInteger b = BigInteger.ONE;
		
        while(!isCancelled) {
            System.out.println("Thread running");
            System.out.println(queue);
            b = b.nextProbablePrime();
            try {
                queue.put(b);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
			
    public void cancel() { 
        isCancelled = true;
    }
	
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        Thread thread = new Thread(myThread);
        thread.start();
        try {
            Thread.sleep(10);
            myThread.consume();			
        } catch (InterruptedException e) { 
            e.printStackTrace();
        }        
		
        myThread.cancel();
    }

    private void consume() throws InterruptedException {
        System.out.println(queue.take());
    }	
	
}
	</pre>
	</div>
<br>	
	<div id="solution">
		<h4>2) Interrupting thread, interrupt method Interrupts this thread</h4>
		<p>Interruption is usually the most sensible way to implement cancellation. Each thread has a boolean interrupted status; 
		interrupting a thread sets its interrupted status to true.</p>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
// stops thread         
public class MyThread implements Runnable {
    public void run() { 
        while(!Thread.interrupted()) {
            System.out.println("Thread running");
        }            
        System.out.println("Thread stopped");
    }
	
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        Thread thread = new Thread(myThread);
        thread.start();
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) { 
            e.printStackTrace();
        }         
        thread.interrupt();
    }

}
    </pre>
	</div>
    
     <div id="solution">
		<h4>Output : </h4>
	</div>
<div id="code">
		<pre class="prettyprint">
Thread running
Thread running
Thread stopped
		</pre>
	</div>	

References : <br>
<ul>
	<li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Thread.html#stop--">Oracle Docs Thread stop</a>	<br><br></li>	
	<li><a href ="https://docs.oracle.com/javase/8/docs/api/java/lang/Thread.html#interrupt--">Oracle Docs Thread interrupt  </a>	</li><br>

</ul>    

	
	</div>
	
</body>
</html>
