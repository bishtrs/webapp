<?php 
    include("header.htm");
?>

<head>
    <title>Read properties file in java</title>
	<meta name="description" content="Read properties file in java using Properties class." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_cj_readproperties"/ >
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Read properties file in Java</h1>
	  </div>

      <div id="solution">
      <p>In Java properties can be saved as key value pairs in a properties file. Files generally have .properties extension. In each pair, the key and value are both String values.These key/value paires can be read as Properties object using Properties Class in Java. The key is used to retrieve, the value in the key/value pair.</p>
      <p>You can read properties file in Java, write properties file in Java as follows:</p></div><br>
        
	<b>db.properties file:</b>
	<div id="code">
    <pre class="prettyprint">
db.driverClassName = oracle.jdbc.driver.OracleDriver
db.url = jdbc:oracle:thin:@oracle.somedomain.com:1521:ROH
db.username = scott
db.password = tiger
    </pre>
	</div>
1) Read properties file from system	
	<div id="code">
	<pre class="prettyprint">
// Reads properties file from system	
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
		
public class ReadProperties {
    public static void main(String[] args) {
        try {	
            FileReader reader = new FileReader("C:\\db.properties"); 
            Properties properties = new Properties();  
            properties.load(reader); 
            System.out.println( properties.getProperty("db.username"));
            System.out.println( properties.getProperty("db.password"));
        } catch (IOException io) {
            io.printStackTrace();
        }
    }		
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
scott
tiger
		</pre>
	</div>
References	 : <a href="https://docs.oracle.com/javase/tutorial/essential/environment/properties.html">https://docs.oracle.com/javase/tutorial/essential/environment/properties.html</a>
	<div id="comments">
	</div>

2) Read properties file from classpath
	<div id="code">
	<pre class="prettyprint">
// Reads properties file from classpath	
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
		
public class ReadProperties {
    public static void main(String[] args) {
        try (InputStream input = ReadProperties.class.getClassLoader().
                getResourceAsStream("db.properties")) { 
            Properties properties = new Properties();  
            properties.load(input); 
            System.out.println( properties.getProperty("db.username"));
            System.out.println( properties.getProperty("db.password"));
        }  catch (IOException e) {
            e.printStackTrace();
        }
    }		
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
scott
tiger
		</pre>
	</div>
3) Write to properties file    
<div id="code">
	<pre class="prettyprint">
// Writes to properties file	
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.io.IOException;
		
public class WriteProperties {
    public static void main(String[] args) {
        try (OutputStream output = new FileOutputStream("C:\\db2.properties")) {
            Properties properties = new Properties();  
            properties.setProperty("db.username", "scott");
            properties.setProperty("db.password", "tiger");		
            properties.store(output, "Properties Example");
            System.out.println(properties);
        } catch (IOException io) {
            io.printStackTrace();
        }		
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{db.password=tiger, db.username=scott}
		</pre>
	</div>
<div id="solution">
		<h4>db2.properties file generated:</h4>
	</div>    
	
	<div id="code">
		<pre class="prettyprint">
#Properties Example
#Wed May 01 11:21:07 IST 2019
db.password=tiger
db.username=scott
	</pre>
	</div>
	
	<div id="comments">
	</div>
	

References	 : <a href="https://docs.oracle.com/javase/tutorial/essential/environment/properties.html">https://docs.oracle.com/javase/tutorial/essential/environment/properties.html</a>
	<div id="comments">
	</div>
    
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
