<?php 
    include("header.htm");
?>

<head>
    <title>How to use printf in Java</title>
	<meta name="description" content="printf in java, java printf format, how to use printf in java." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_cj_printf"/ >
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
    
	<div id="problem">
		<h1>How to use printf() in Java ?</h1>
	  </div>

      <div id="solution">
      <p><b><i>printf()</b></i> method is defined in <b><i>PrintStream</b></i> class. It is used to write a formatted string to 
      this output stream using the specified format string and arguments. It is similar to <b><i>printf()</b></i> in C language & you can pass any number of arguments to be printed.</p>
      <p>
	  It has following signature:  <b><i>public PrintStream printf(String format, Object ... args)</b></i><br>
      </p>
      </div>
      
 
<h4>1) Below example shows how to print multiple String objects using printf</h4>
	<div id="code">
	<pre class="prettyprint">
// printf example with multiple string objects

public class TestFormatting {

    public static void main(String[] args) {
        String firstName = "Boris";
        String lastName = "Becker";
        System.out.printf("First name is %s , last name is %s %n", firstName, lastName);
        System.out.printf("First name is %S , last name is %S %n", firstName, lastName);
        lastName = null;
        System.out.printf("First name is %S , last name is %S", firstName, lastName);
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
First name is Boris , last name is Becker 
First name is BORIS , last name is BECKER 
First name is BORIS , last name is NULL
		</pre>
	</div><br>
    
 <h4>2) Below example shows how to format and print float type with decimal precision</h4>
	<div id="code">
	<pre class="prettyprint">
// printf example with decimal precision

public class TestFormatting {

    public static void main(String[] args) {
    	int x = 10; 
        System.out.printf("Simple integer: x = %d\n", x); 
        
        float f = 12.67893f;
        System.out.printf("Print without any decimal precision : %f\n", f); 
        System.out.printf("Print with upto 4 decimal: %.4f\n", f);
        System.out.printf("Print with upto 3 decimal: %.3f\n", f);
        System.out.printf("Print with upto 2 decimal: %.2f\n", f);
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Simple integer: x = 10
Print without any decimal precision : 12.678930
Print with upto 4 decimal: 12.6789
Print with upto 3 decimal: 12.679
Print with upto 2 decimal: 12.68
		</pre>
	</div>
    <br>
    
<h4>3) Below example shows how to add whitespace using printf(). </h4>
    <p>Suppose you want to add space while priting data, you can specify the field width by inserting a number between the % sign and the conversion character.
    </p>
	<div id="code">
	<pre class="prettyprint">
// printf example with whitespace

public class TestFormatting {

    public static void main(String[] args) {
    	String name1 = "Mark";
        String name2 = "Abraham";
        int age1 = 37;
        int age2 = 5;
        System.out.format("%s  %d\n",name1,age1); // prints without proper alignment
        System.out.format("%s  %d\n",name2,age2); // prints without proper alignment
        System.out.format("%-10s  %4d\n",name1,age1); // prints with proper alignment
        System.out.format("%-10s  %4d\n",name2,age2); // prints with proper alignment       
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Mark  37
Abraham  5
Mark          37
Abraham        5
		</pre>
	</div>    
   
<br>

 <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
References : <br><br><a href="https://docs.oracle.com/javase/8/docs/api/java/io/PrintStream.html">Oracle Docs PrintStream</a>	<br><br>
    <a href="https://docs.oracle.com/javase/8/docs/api/java/io/PrintStream.html#printf-java.lang.String-java.lang.Object...-">Oracle Docs PrintStream printf()</a><br><br>
	
    <a href="https://docs.oracle.com/javase/1.5.0/docs/api/java/util/Formatter.html#syntax">Oracle Docs</a><br>
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
