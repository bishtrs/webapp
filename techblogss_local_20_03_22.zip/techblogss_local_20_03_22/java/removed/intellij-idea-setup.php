<?php 
    include("header.htm");
?>

<head>
    <title>Maven setup in windows</title>
	<meta name="description" content="Maven setup in windows" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_mavensetup" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog" style="float:left;">
	<div id="problem">
		<h1>Maven setup in windows</h1>
	</div>
	<div id="solution">
		<h4>Step 1) Download Maven 3.6.1 from below link </h4><a href="http://apachemirror.wuchna.com/maven/maven-3/3.6.1/binaries/apache-maven-3.6.1-bin.zip">Maven 3.6.1</a>
        <h4>Step 2) Open apache-maven-3.6.1-bin.zip with winzip or any other unzip tool as shown below </h4>
        <div>
            <p><img src="../images/maven_zip.jpg" alt="Maven Build" style="width:700px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h4>Step 3) Extract contents of apache-maven-3.6.1-bin.zip to a folder as shown below </h4>
        <div>
            <p><img src="../images/maven_extract.jpg" alt="Maven Build" style="width:700px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
         <h4>Step 4) Setting Maven path</h4>
         <p>a) Open Control Panel &rarr; Systems &rarr; Advanced System Settings &rarr; Click on  Environment Variables</p>
        <div>
            <p><img src="../images/maven_env.jpg" alt="Maven Build" style="width:700px;height:500px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <p>b) Select PATH and click on Edit, append the maven path as shown below </p>
        <div>
            <p><img src="../images/maven_path.jpg" alt="Maven Build" style="width:700px;height:500px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h4>Step 5) Verify Maven installation</h4>
         <p>a) Open command prompt and type 'set'</p>
        <div>
            <p><img src="../images/maven_verify_path.jpg" alt="Maven Build" style="width:800px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br>
        <p>b) Type maven -version in command prompt to see if maven is working</p>
        <div>
            <p><img src="../images/maven_verify.jpg" alt="Maven Build" style="width:800px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
References : <br><br>
<a href="https://maven.apache.org/download.cgi">Maven - Download Apache Maven</a>	<br><br>
 
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>