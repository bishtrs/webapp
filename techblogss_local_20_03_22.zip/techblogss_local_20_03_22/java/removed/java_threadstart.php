<?php 
    include("header.htm");
?>

<head>
    <title>How to create thread in java</title>
	<meta name="description" content="How to create thread in java, by extending Thread Class and implementing java Runnable interface." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_threadstart">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>How to create thread in java ?</h1>
	
	</div>
    <div id="solution">
		<h4>1) Extending Thread Class </h4>
        <p>There are two ways to create a new thread in Java.
        One is to extend Thread Class and override <b><i>run()</b></i> method. 
        It has following signature : <b><i>public void run()</b></i>.<br><br>
        This subclass should override the run method of class Thread.
        For example, below thread prints SOP.
        </p> 
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Creates a thread by extending Thread Class
public class MyThread extends Thread {

    public void run() { 
        System.out.println("Thread started");
    }
    
    public static void main(String[] args) {
        MyThread myThread = new MyThread(); // Creates a thread
        myThread.start(); // calls run method
    } 

}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread started
		</pre>
	</div>	
 
<h4>Setting thread name </h4> 
	<div id="code">
	<pre class="prettyprint">
// Creates a thread by extending Thread Class
public class MyThread extends Thread {

    public void run() { 
        System.out.println(Thread.currentThread() + " running");
    }
    
    public static void main(String[] args) {
        MyThread myThread = new MyThread(); // Creates a thread
        myThread.setName("MyThread");
        myThread.start(); // calls run method
    } 

}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread[MyThread,5,main] running
		</pre>
	</div>	    
	
	<div id="comments">
		<h4>Comments on above approach:</h4>
		<ul>
            <li>It is not recommended to use above approach for creating a Thread as you cannot extend more than one Class in Java.</li>
			<li>It is preferred to implement Runnable interface to create thread.</li>
        </ul>
	</div>
	<div id="solution">
		<h4>2) Implementing Runnable Interface</h4>
        <p>The other way to create a thread is to create a class that implements the Runnable interface 
        & implements the <b><i>run()</b></i> method which has following signature : <b><i>public void run()</b></i><br>
        An instance of the class can then be passed as an argument when creating Thread, and started. 
        The same example in this other style looks like the following:
	</div>
<h5>a) Implement Runnable Interface</h5>	
	<div id="code">
	<pre class="prettyprint">
// Creates a thread by implementing Runnable Interface	
public class MyThread implements Runnable {

    public void run() { 
        System.out.println("Thread started");
    }
    
    public static void main(String[] args) {
        Thread thread = new Thread(new MyThread()); // Creates a thread
        thread.start();
    }

}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread started
		</pre>
	</div>	

<h5>b) Implement Runnable Interface using Lambda Expression </h5>
	<div id="code">
	<pre class="prettyprint">
// Creates a thread by implementing Runnable Interface using Lambda Expression	
public class MyThread {

    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        Runnable runnable = () -> System.out.println("Thread started");
        Thread thread = new Thread(runnable); // Creates a thread
        thread.start();
    }

}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread started
		</pre>
	</div>	
	
    <div id="comments">
		<h4>Comments on above approach:</h4>
		<ul>
			<li>A Runnable thread will not block the main thread.</li>
        </ul>
	</div>


References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Thread.html">Oracle Docs Thread</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Runnable.html">Oracle Docs Runnable</a><br><br>		
	
	</div>
</body>

<?php 
    include("footer.htm");
?>	

</html>
