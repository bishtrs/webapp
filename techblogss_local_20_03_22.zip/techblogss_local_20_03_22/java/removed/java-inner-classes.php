<?php 
    include("header.htm");
?>

<head>
    <title>Java Inner Classes</title>
    <meta name="description" content="java inner classes, java nested classes, method local inner classes, static inner classes,
    anonymous inner classes" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-inner-classes" />
</head>

<body>
    <?php 
        include("navigation.htm");
    ?>
       
    <div id="content">
    <div id="blog">
    <div id="problem">
        <h1>Inner Classes</h1>
        <p>In Java you can create an <b><i>Inner</b></i> or <b><i>Nested</b></i> Class which resides inside an existing Class. It makes code more cohesive, maintainable and improves encapsulation. There are four types of <b><i>Inner</b></i> Classes in Java.</p>

        <p>
        <ul>
            <li><b><i>Regular Inner or Nested Class</b></i></li>
            <li><b><i>Static Inner class</b></i></li>
            <li><b><i>Method Local Inner Class</b></i></li>
            <li><b><i>Anonymous Inner Class</b></i></li>
        </ul>
        </p>
    </div>
    
    <div id="solution">
        <h2>1) Regular Inner Class</h2>
        <p>Below examples of <b><i>Inner</b></i> Class show that an Inner</b></i> Class can access Outer Class variables. Note that you have to use syntax like <b><i>outer.new Inner()</b></i> to create an instance of <b><i>Inner</b></i> Class. </p>
        <p>Also if you see the compiled classes, you will find two classes <i>Outer.class</i> and <i>Outer$Inner.class</i></p>
    </div>

    <div id="code">
    <pre class="prettyprint">
public class Outer {

    private String name;

    public Outer(String name) {
        this.name = name;
    }

    class Inner {
        public void print() {
            System.out.println(name);
        }
    }

    public static void main(String[] args) {
        Outer outer = new Outer("inner variable");
        Outer.Inner inner = outer.new Inner();
        inner.print();
    }
}    </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">inner variable    </pre>
    </div>
    
    <br>
    
    <p>Below is another practical example of Inner Class where the iterator specific behaviour for StringArray data structure is encapsulated in StringArrayIterator Inner class.</p>

    
    <div id="code">
    <pre class="prettyprint">
public class StringArray {

    private String[] stringArray;
    private int size = 0;
    private int index = 0;

    public StringArray(int size) {
        this.stringArray = new String[size];
        this.size = size;
    }

    public void add(String data) {
        this.stringArray[index++] = data;
    }

    public void print() {
        StringArrayIterator iterator = this.new StringArrayIterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next() + " ");
        }
    }

    class StringArrayIterator implements java.util.Iterator&lt;String> {

        private int nextIndex = 0;

        @Override
        public boolean hasNext() {
            return (nextIndex &lt;= size - 1);
        }

        @Override
        public String next() {
            return stringArray[nextIndex++];
        }
    }

    public static void main(String[] args) {
        StringArray stringArray = new StringArray(5);
        stringArray.add("mercury");
        stringArray.add("venus");
        stringArray.add("earth");
        stringArray.add("mars");
        stringArray.add("jupiter");
        stringArray.print();
    }

}    </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">mercury 
venus 
earth 
mars 
jupiter    </pre>
    </div>
    
    <br>


    <div id="solution">
        <h2>2) Static Inner Class</h2>
        <p>You can create an <b><i>Static Inner</b></i> Class inside a Class. Its also called <b><i>Static Nested</b></i> Class. The static Class is just a static member of the Outer Class. <b><i>Static Inner</b></i> Class cannot access any instance variable or method of Outer Class.</p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
public class StaticInnerExample {

    public void foo() {
        Inner inner = new Inner();
        inner.print();
    }

    static class Inner {
        public void print() {
            System.out.println("static inner class");
        }
    }

    public static void main(String[] args) {
        StaticInnerExample.Inner inner = new StaticInnerExample.Inner();
        inner.print();

        StaticInnerExample staticInner = new StaticInnerExample();
        staticInner.foo();

    }
}  </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">
static inner class
static inner class        </pre>
    </div>
    
    <br>
    
    <div id="solution">
        <h2>3) Method Local Inner Class</h2>
        <p>You can also create an <b><i>Inner</b></i> Class inside a method or is local to a method. Method local <b><i>Inner</b></i> Class can be instantiated only within the local method & not outside the method.</p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
public class MethodLocal {

    private String name;

    public MethodLocal(String name) {
        this.name = name;
    }

    public void foo() {
        int x = 20;
        class Inner {
            public void print() {
                System.out.println(name);
                System.out.println(x);
            }
        }
        Inner inner = new Inner();
        inner.print();
    }

    public static void main(String[] args) {
        MethodLocal outer = new MethodLocal("method local example");
        outer.foo();
    }
}   </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">
method local example
20        </pre>
    </div>
    
    <br>
    

    <div id="solution">
        <h2>4) Anonymous Inner Class</h2>
        <p><b><i>Anonymous Inner</b></i> Class is used to extend another class but this class doesn't have any name. In below example Parent Class is overridden in Test Class without any Class name.</p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
public class Parent {

    public void print() {
        System.out.println("parent class print method called");
    }

    public static void main(String[] args) {
        Test test = new Test();
        test.parent.print();
    }

}

class Test {
    Parent parent = new Parent() {
        public void print() {
            System.out.println("child class print method called");
        }
    };

}  </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">child class print method called </pre>   </div>
    
    <br>
    
    <div id="solution">     
    <p>In another type of <b><i>Anonymous Inner</b></i> Class, it is used to implement an interface instead of extending another Class.
    In below example, we implement Animal interface in AnimalTest class but its anonymous.</p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
public interface Animal {
    
    public void run();

}    </pre>
    </div>

    <div id="code">
    <pre class="prettyprint">
public class AnimalTest {
    
    Animal animal = new Animal() {
        public void run() {
            System.out.println("Tiger is running");
        }
    };
    
    public static void main(String[] args) {
        AnimalTest test = new AnimalTest();
        test.animal.run();
    }

}</pre>
    </div>


    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">Tiger is running   </pre>   </div>
    <br>
    
    <br>
    
     <!-- ADU1 -->

    <?php include("../sidebar/ad.htm"); ?>
    
<div id="refrences">
   References: 

<ul>
    <li><a href="https://docs.oracle.com/javase/tutorial/java/javaOO/nested.html" target="_blank">Nested Classes</a></li><br>
</a></li>
</ul>
</div>

     </div> <!-- blog div-->

    <?php include("../sidebar/sidebar.htm"); ?>

    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>