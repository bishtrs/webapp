<?php include("../header.htm");?>

<head>
    <title>Predicate example in Java 8</title>
    <meta name="description" content="Predicate in Java, Java predicate example, predicate in Java 8" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-predicate" />
</head>

<body>
    <?php include("../navigation.htm");?>
    
       <div id="content">
    <div id="blog">
    <div id="problem">
        <h2>Predicate example in Java 8</h2>
        
        <p>
        <code>Predicate</code> in Java is a functional interface whose functional method is <code>test(Object)</code>. 
        It was introduced in <code>Java 8</code>. It is used to test things, it takes a value, does a logical test, and returns ture or false.
        This tutorial shows various examples of <code>Predicate</code> in <code>Java 8</code>.
        </p>
    </div>
    
    <div id="solution">
        <h3>1) A simple Predicate example which returns a primitive type</h3>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.function.Predicate;

public class TestPredicate {

    public static void main(String args[]) {
        Predicate&lt;Integer&gt; greaterThan = i -> (i &gt; 10);  
  
        System.out.println(greaterThan.test(15));  
        System.out.println(greaterThan.test(10));  
        System.out.println(greaterThan.test(5));  
        
    }
}    </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    <div id="code">
        <pre class="prettyprint">
true
false
false   </pre></div></div><br>
    
    <div id="solution">
        <h3>2) Example with Predicate passed as method argument</h3>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.function.Predicate;

public class TestPredicate {

    public static void main(String args[]) {
        testPredicate(10, (i) -> i > 5); 
    }
    
    private static void testPredicate(int num, Predicate&lt;Integer&gt; predicate) {
        if (predicate.test(num)) { 
            System.out.println(num); // prints 10
        }  
    } 
}    </pre></div><br>
    

    <div id="solution">
        <h2>3) Predicate negate() example</h2>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.function.Predicate;

public class TestPredicate {

    public static void main(String args[]) {
        testNegate("John", (i) -> i.length() > 5); 
        testNegate("Michelle", (i) -> i.length() > 5); 
    }
    
    private static void testNegate(String name, Predicate&lt;String&gt; predicate) {
        System.out.println(predicate.negate().test(name));
    } 
    
}    </pre></div><br>

    <div id="solution">
        <h4>Output : </h4>
    </div>   
    
    <div id="code">
        <pre class="prettyprint">
true
false        </pre></div><br>

    <div id="solution">
        <h3>4) Predicate or(Predicate other) and and(Predicate other) example</h3>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.function.Predicate;

public class TestPredicate {

    public static void main(String args[]) {
        Predicate&lt;Integer&gt; greaterThan = i -> (i &gt; 10);  
        Predicate&lt;Integer&gt; lessThan = i -> (i &lt; 20);  
  
        System.out.println(greaterThan.and(lessThan).test(15));  
        System.out.println(greaterThan.and(lessThan).test(25));
        System.out.println(greaterThan.or(lessThan).test(15));
        System.out.println(greaterThan.or(lessThan).test(25));
    }
}    </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
 <div id="code">
        <pre class="prettyprint">
true
false
true
true    </pre></div><br>

    <div id="solution">
        <h3>5) Predicate isEqual(Object) example</h3>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.function.Predicate;

public class TestPredicate {

    public static void main(String args[]) {
        Predicate&lt;Integer&gt; greaterThan = i -> (i &gt; 10);  
        Predicate&lt;Integer&gt; lessThan = i -> (i &lt; 20);  
  
        System.out.println(greaterThan.equals(lessThan));  
        System.out.println(greaterThan.equals(greaterThan));  
    }
}    </pre>
    </div>

    <div id="solution">
        <h4>Output : </h4>
    </div>        
    
    <div id="code">
        <pre class="prettyprint">
false
true        </div></pre><br>

    <div id="solution">
        <h3>6) BiPredicate example</h3>
        <p>
        Suppose you have a <b><i>List</b></i> of DVDs and you want to purchase a DVD based on price & genre. You can create two predicates 
        that will determine if you can buy that DVD.
        </p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;

class DVD {

    private String name;
    private int price;
    private String genre;
    
    // removed getter, setter and constrcutor   
}

public class TestBiPredicate {

    public static void main(String args[]) {
        List&lt;DVD&gt; dvdList = new ArrayList&lt;&gt;();
        dvdList.add(new DVD("Terminator", 20, "Action"));
        dvdList.add(new DVD("Rambo", 30, "Action"));
        dvdList.add(new DVD("When Harry Met Sally", 10, "Romantic"));
        
        BiPredicate&lt;Integer, String&gt; priceBuy = (price, genre) -> price &lt; 30;  
        BiPredicate&lt;Integer, String&gt; genreBuy = (price, genre) 
            -> genre.equalsIgnoreCase("Action");
        BiPredicate&lt;Integer, String&gt; finalBuy = priceBuy.and(genreBuy);
        
        dvdList.forEach(dvd -> {
            if (finalBuy.test(dvd.getPrice(), dvd.getGenre())) {
                System.out.println("You can buy " + dvd.getName());
            }
        });
    }
}    </pre></div><br>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code"><pre class="prettyprint">
You can buy Terminator    </pre></div><br>    
    
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/function/Predicate.html">Oracle Docs Predicate</a>    <br><br>

    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
<?php include("footer.htm");?>
    
</body>
</html>
