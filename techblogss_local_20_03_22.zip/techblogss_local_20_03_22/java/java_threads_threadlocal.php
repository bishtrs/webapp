<?php 
    include("header.htm");
?>

<head>
    <title>ThreadLocal in Java</title>
	<meta name="description" content="ThreadLocal in Java, Java ThreadLocal example" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_threads_threadlocal">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>ThreadLocal in Java</h1>
	
	</div>
    <div id="solution" style="text-align:justify;">
		<h2>Java ThreadLocal example</h2>
	</div>
    
    <div id="solution">
		<h4>1) A simple ThreadLocal Java example which stores an integer value a primitive type.</h4>
	</div>
	<div id="code">
	<pre class="prettyprint">
public class ThreadLocalTest {
    public static void main(String[] args) {
     
        // Thread local variable containing a Integer
        ThreadLocal&lt;Integer&gt; threadLocal = new ThreadLocal&lt;Integer&gt;();
     
        threadLocal.set(100);      
        System.out.println("value = " + threadLocal.get()); 
        threadLocal.set(200);      
        System.out.println("value = " + threadLocal.get()); 
    }
 }
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
    
    <div id="code">
	<pre class="prettyprint">
value = 100
value = 200
	</div>
	
	<div id="solution">
		<h4>2) ThreadLocal Java example in which each Thread sets and gets its own value.</h4>
	</div>
	<div id="code">
	<pre class="prettyprint">
public class ThreadLocalTest extends Thread {
	 
    // Thread local variable containing a Integer
    private ThreadLocal&lt;Integer&gt; threadLocal;
    private Integer number = 0;

    public ThreadLocalTest(ThreadLocal&lt;Integer&gt; threadLocal, Integer number) {
        this.threadLocal = threadLocal;
        this.number = number;
    }
	 
    public static void main(String[] args) {
        ThreadLocal&lt;Integer&gt; threadLocal = new ThreadLocal&lt;Integer&gt;();
    	ThreadLocalTest t1 = new ThreadLocalTest(threadLocal, 100);
    	t1.setName("Thread 1");
    	t1.start();
    	
    	ThreadLocalTest t2 = new ThreadLocalTest(threadLocal, 200);
    	t2.setName("Thread 2");
    	t2.start();
    }
     
    public void run() {
        System.out.println(Thread.currentThread().getName() + " setting value " + number);
    	threadLocal.set(number);  
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName() + " getting value");        
    	System.out.println("value = " + threadLocal.get());
    }
     
}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
    
    <div id="code">
	<pre class="prettyprint">
Thread 1 setting value 100
Thread 2 setting value 200
Thread 2 getting value
Thread 1 getting value
value = 200
value = 100
    </pre>
	</div>
    
    <div id="solution">
		<h4>3) ThreadLocal Java example with SimpleDateFormat.</h4>
        <p>A typical scenario where you can use <b><i>ThreadLocal</b></i> is when multiple threads are trying to use same 
        <b><i>SimpleDateFormat</b></i> instance. Since <b><i>SimpleDateFormat</b></i> class is not thread-safe, each Thread must have its own copy 
        of <b><i>SimpleDateFormat</b></i> instance and it should be stored in a <b><i>ThreadLocal</b></i>.</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.text.SimpleDateFormat;

public class ThreadLocalTest extends Thread {
	 
    // SimpleDateFormat is not thread-safe, so give one to each thread
    private static final ThreadLocal&lt;SimpleDateFormat&gt; formatter
        = new ThreadLocal&lt;SimpleDateFormat&gt;() {
        
        @Override
        protected SimpleDateFormat initialValue()
        {
            return new SimpleDateFormat("yyyyMMdd HHmm");
        }
    };


    public static void main(String[] args) {
    	ThreadLocalTest t1 = new ThreadLocalTest();
    	t1.setName("Thread 1");
    	t1.start();
    	
    	ThreadLocalTest t2 = new ThreadLocalTest();
    	t2.setName("Thread 2");
    	t2.start();
    	
    	ThreadLocalTest t3 = new ThreadLocalTest();
    	t3.setName("Thread 3");
    	t3.start();
    	
    	ThreadLocalTest t4 = new ThreadLocalTest();
    	t4.setName("Thread 4");
    	t4.start();
    	
    	ThreadLocalTest t5 = new ThreadLocalTest();
    	t5.setName("Thread 5");
    	t5.start();

    }
     
    public void run() {
    	System.out.println(Thread.currentThread().getName() + " Date Format = " 
            + formatter.get().toPattern());
        if (Thread.currentThread().getName().equalsIgnoreCase("Thread 2") 
            || Thread.currentThread().getName().equalsIgnoreCase("Thread 4")) {
        	formatter.set(new SimpleDateFormat("yyyyMMdd"));
        } else {
        	formatter.set(new SimpleDateFormat("ddMMyyyy"));
        }
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName() + " Date Format = "
            + formatter.get().toPattern());        
    }
     
}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
    
    <div id="code">
	<pre class="prettyprint">
Thread 5 Date Format = yyyyMMdd HHmm
Thread 3 Date Format = yyyyMMdd HHmm
Thread 1 Date Format = yyyyMMdd HHmm
Thread 2 Date Format = yyyyMMdd HHmm
Thread 4 Date Format = yyyyMMdd HHmm
Thread 5 Date Format = ddMMyyyy
Thread 3 Date Format = ddMMyyyy
Thread 2 Date Format = yyyyMMdd
Thread 4 Date Format = yyyyMMdd
Thread 1 Date Format = ddMMyyyy
    </pre>
	</div>    

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/lang/ThreadLocal.html">Oracle Docs ThreadLocal</a>	<br><br>

	</div>
</body>

<?php 
    include("footer.htm");
?>	

</html>
