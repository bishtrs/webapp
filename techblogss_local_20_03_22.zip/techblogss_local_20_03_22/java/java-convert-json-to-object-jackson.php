<?php include("../header.htm");?>

<head>
    <title>Convert JSON to Java Object using Jackson</title>
    <meta name="description" content="Convert json to Java object, convert Java object to json"/>
    <link rel="canonical" href="https://www.techblogss.com/java/java-convert-json-to-object-jackson">
</head>

<body>
    <?php include("../navigation.htm");    ?>
       
    <div id="content">
    <div id="blog">
    <div id="problem">
        <h2>Convert JSON to Java Object using Jackson</h2>
        <p>
        Jackson provides APIs which is a high-performance JSON processor for Java. Using Jackson APIs, you can easily convert a JSON to Java
        objects and vice-versa.
        </p>        
    </div>
        
    <div id="solution">
        <h4>First you need to download following jars or using maven dependency</h4>
        <a href="https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-databind/2.9.8" target="_blank">jackson-databind-2.9.8</a><br><br>
        <a href="https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-annotations/2.9.8" target="_blank">jackson-annotations-2.9.8</a><br><br>
        <a href="https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-core/2.9.8" target="_blank">jackson-core-2.9.8</a><br>
        
    </div>
    
    <div id="code">
    <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>com.fasterxml.jackson.core&lt;/groupId>
    &lt;artifactId>jackson-databind&lt;/artifactId>
    &lt;version>2.9.8</version>
&lt;/dependency>   </pre></div>
    
    <div id="code">
    <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>com.fasterxml.jackson.core&lt;/groupId>
    &lt;artifactId>jackson-annotations&lt;/artifactId>
    &lt;version>2.9.8&lt;/version>
&lt;/dependency>    </pre></div>
    
    <div id="code">
    <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>com.fasterxml.jackson.core&lt;/groupId>
    &lt;artifactId>jackson-core&lt;/artifactId>
    &lt;version>2.9.8&lt;/version>
&lt;/dependency>    </pre></div><br>

    <p>Below is the JSON String that you want to convert to Java Object using Jackson</p>
    
  <div id="code">
    
    <pre class="prettyprint">
{
    "id":12345, 
    "name":"Pierce Brosnan",
    "age":35,
    "emailaddress":["p.brosnan@gmail.com", "p.brosnan@yahoo.com"]
}    </pre></div>
    
    <div id="solution">
        <p>Java POJO class used to convert JSON String to object and vice-versa.</p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.List;
    
public class Actor {
    
    private int id;
    private String name;
    private int age;
    private List&lt;String&gt; emailaddress;
      
    // removed getter and setter      
    
    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ","
            +" age=" + age + ", emailaddress=" + emailaddress + "]";
    }    
    
}    </pre></div><br>
 
    <div id="solution">
        <h4>1) Convert JSON string to Java object using Jackson.</h4>
    </div> 
    <div id="code">
    <pre class="prettyprint">
// Parses JSON String using Jackson Parser    
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
    
public class JsonToObject {
    public static void main(String[] args) {
        String jsonString = "{\"id\":12345, \"name\":\"Pierce Brosnan\", \"age\":35,"
            + " \"emailaddress\":[\"p.brosnan@gmail.com\", \"p.brosnan@yahoo.com\"]}";
            
        ObjectMapper mapper = new ObjectMapper();
        Actor actor = null;

        try {
            actor = mapper.readValue(jsonString, Actor.class);
        } catch (IOException e) {
            e.printStackTrace();
        } 
        System.out.println(actor);   
    }
}    </pre></div>

    
    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
Actor [id=12345, name=Pierce Brosnan, age=35, emailaddress=[p.brosnan@gmail.com, p.brosnan@yahoo.com]]    </pre></div><br>


<div id="solution">
        <h4>2) Reads JSON file and converts it to Java object using Jakckson.</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Parses JSON File using Jackson Parser    
import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
    
public class JsonToObject {
    public static void main(String[] args) {
        File file = new File("c://actors.json"); // to read from file
        ObjectMapper mapper = new ObjectMapper();
        Actor actor = null;

        try {
            actor = mapper.readValue(jsonString, Actor.class);
        } catch (IOException e) {
            e.printStackTrace();
        } 
        System.out.println(actor);    
    }
}
    </pre>
    </div>
    
    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
Actor [id=12345, name=Pierce Brosnan, age=35, emailaddress=[p.brosnan@gmail.com, p.brosnan@yahoo.com]]    </pre></div><br>
    
    <div id="solution">
        <h4>3) Convert Java object to JSON string using Jackson.</h4>
    </div> 
    <div id="code">
    <pre class="prettyprint">
// Converts Java object to JSON string using Jackson   
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectToJson {
    public static void main(String[] args) {
        Actor actor = new Actor();
        actor.setId(1234);
        actor.setName("Pierce Brosnan");
        actor.setAge(40);
        
        List&lt;String> emailaddress = new ArrayList<>();
        emailaddress.add("p.brosnan@yahoo.com");
        emailaddress.add("p.brosnan@gmail.com");
        actor.setEmailaddress(emailaddress);
            
        ObjectMapper mapper = new ObjectMapper();
        String jsonString = "";

        try {
            jsonString = mapper.writeValueAsString(actor);
            System.out.println(jsonString);   
            // Enable pretty print
            jsonString = mapper.writerWithDefaultPrettyPrinter().
                writeValueAsString(actor);
            System.out.println("Prettyfied output");
            System.out.println(jsonString); 
        }  catch (IOException e) {
            e.printStackTrace();
        } 
        
    }
}    </pre></div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
{"id":1234,"name":"Pierce Brosnan","age":40,"emailaddress":["p.brosnan@yahoo.com","p.brosnan@gmail.com"]}
Prettyfied output
{
  "id" : 1234,
  "name" : "Pierce Brosnan",
  "age" : 40,
  "emailaddress" : [ "p.brosnan@yahoo.com", "p.brosnan@gmail.com" ]
}   </pre></div><br>  

    <div id="solution">
        <h4>4) Convert JSON to Map object</h4>
    </div> 

    <div id="code">
    <pre class="prettyprint">
Map&lt;String, String> map = new HashMap&lt;>();
try {
    map = mapper.readValue(jsonString, Map.class);
} catch (IOException e) {
    e.printStackTrace();
}
System.out.println(map); </pre></div><br>
    
    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
{id=12345, name=Pierce Brosnan, age=35, emailaddress=[p.brosnan@gmail.com, p.brosnan@yahoo.com]}    </pre></div><br>

    <div id="solution">
        <h4>5) Convert Map object to JSON string</h4>
    </div> 
    
    <div id="code">
    <pre class="prettyprint">
// Converts Map to JSON String
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;
    
public class TestJsonJackson {
    public static void main(String[] args) {
        Map&lt;String, String> map = new HashMap&lt;>();
        map.put("id", "12345");
        map.put("name", "Pierce Brosnan");
        map.put("age", "36");
            
        try {
            jsonString = mapper.writeValueAsString(map);
            System.out.println(jsonString);	
            
            // Pretty JSON
            jsonString = mapper.writerWithDefaultPrettyPrinter()
                .writeValueAsString(map);
            System.out.println(jsonString);	
        }  catch (IOException e) {
            e.printStackTrace();
        } 
    }
}    </pre></div><br>

    
    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
{
    "name" : "Pierce Brosnan",
    "id" : "12345",
    "age" : "36"
}    </pre></div><br>
    
    <div id="solution">
        <h4>6) Below example shows how to convert JSON Array String to List object</h4>
    </div> 
    
    <div id="solution">
        <p>Java class used to convert JSON Array String to List.</p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">    
public class Employee {
    
    private int id;
    private String name;
    private int age;
        
    // removed getter and setter      
   
    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + "," +" age=" + age + "]";
    }  
}  </pre></div><br>

    <div id="code">
    <pre class="prettyprint">
// Converts JSON Array String to List  
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
    
public class TestJsonJackson {
    public static void main(String[] args) {
        String jsonString = "[{\"id\":\"12345\", \"name\":\"Jason Bourne\", \"age\":\"35\"},"
            + "{\"id\":\"12346\", \"name\":\"James Bond\", \"age\":\"38\"}]";
            
        ObjectMapper mapper = new ObjectMapper();

        try {
            Employee[] employee = mapper.readValue(jsonString, Employee[].class);
            System.out.println(Arrays.toString(employee));            
            
            List&lt;Employee&gt; employeeList = Arrays.asList(mapper.readValue(jsonString, Employee[].class));
            System.out.println(employeeList);
            
            employeeList = mapper.readValue(jsonString, new TypeReference&lt;List&lt;Employee&gt;&gt;() {});
            System.out.println(employeeList);
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } 
    }
}    </pre></div><br>

    
    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
[Employee [id=12345, name=Jason Bourne, age=35], Employee [id=12346, name=James Bond, age=38]]
[Employee [id=12345, name=Jason Bourne, age=35], Employee [id=12346, name=James Bond, age=38]]
[Employee [id=12345, name=Jason Bourne, age=35], Employee [id=12346, name=James Bond, age=38]]    </pre></div><br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>    
    <br>
  
    </div> <!-- blog div-->
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div>  <!-- content div -->          
</body>

<?php 
    include("footer.htm");
?>

</html>
