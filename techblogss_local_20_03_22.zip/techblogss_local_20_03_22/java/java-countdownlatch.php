<?php 
    include("../header.htm");
?>

<head>
    <title>CountdownLatch in Java</title>
	<meta name="description" content="CountdownLatch in Java" />
	<link rel="canonical" href="https://www.techblogss.com/java/java-countdownlatch">
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>CountdownLatch in Java</h1>
	</div>
    <div id="solution">
        <p>A <code>CountdownLatch</code> allows one or more threads to wait for a set of events to occur. A <code>CountdownLatch</code> is initialized with a given count which represents the number of events to wait for. Once an event has occured, the <code>countDown()</code> method decrements the counter. The <code>await()</code> methods wait for the counter to reach zero, which happens when all the events have occured.
        </p> 
        <p>
        Below example shows <code>CountdownLatch</code> example with 2 worker threads t1 & t2. Main thread waits at a point using <code>endSignal.await()</code> till it receives signal from both threads t1 & t2 that they are done using <code>endSignal.countDown()</code>.
        Here we set number of events to complete as 2. Each <code>endSignal.countDown()</code> call will decrement the count, so when both the threads call <code>endSignal.countDown()</code>, it means wait is over for the main thread and it can proceed. 
        </p>
    </div>	

    <h4>1) CountDownLatch example with two threads/events </h4>		
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.CountDownLatch;

public class CountdownLatchExample {

    final CountDownLatch endSignal = new CountDownLatch(2);

    public static void main(String[] args) {
        CountdownLatchExample countdownLatchExample = new CountdownLatchExample();
        countdownLatchExample.test();
    }

    public void test() {
        Thread t1 = new Thread() {
            public void run() {
                delay(2000);
                System.out.println("Thread t1 running");
                endSignal.countDown();
            }
        };
        t1.start();

        Thread t2 = new Thread() {
            public void run() {
                delay(2000);
                System.out.println("Thread t2 running");
                endSignal.countDown();
            }
        };
        t2.start();

        System.out.println("Waiting for all threads to complete");
        try {
            endSignal.await(); // waits for two threads 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("All threads completed completed their task");
    }
    
    private void delay(long duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}	</pre></div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Waiting for all threads to complete
Thread t1 running
Thread t2 running
All threads completed completed their task		</pre></div><br>
	
<h4>2) CountDownLatch example with N number of threads/events </h4>		
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.CountDownLatch;

public class CountdownLatchExample {
	
    private int counter;
    final CountDownLatch endSignal = new CountDownLatch(2);
        
    public CountdownLatchExample(int counter) {
        this.counter = counter;
    }

    public static void main(String[] args) {
        CountdownLatchExample countdownLatchExample = new CountdownLatchExample(5);
        countdownLatchExample.test();
    }

    public void test() {
        for (int i=0; i&lt;counter ;i++) {
            Thread t = new Thread() {
                public void run() {
                    try {
                        System.out.println(Thread.currentThread().getName() + " running");
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    endSignal.countDown();
                }
            };
            t.start();
        }

        System.out.println("Waiting for all threads to complete");
        try {
            endSignal.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("All threads completed completed their task");
    }

}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread-0 running
Thread-3 running
Thread-4 running
Thread-2 running
Waiting for all threads to complete
Thread-1 running
All threads completed completed their task		</pre></div><br>
	
 <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/CountDownLatch.html">Oracle Docs CountDownLatch</a>	<br><br>

        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>
