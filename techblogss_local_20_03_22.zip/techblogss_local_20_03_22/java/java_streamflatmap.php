<?php 
    include("header.htm");
?>

<head>
    <title>Java Stream flatmap example</title>
	<meta name="description" content="Java Stream flatmap examples." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_streamflatmap" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>Java Stream flatmap examples</h1>
	
	</div>
	
	<div id="solution">
		<h4>1) Java 8 Stream flatmap example to convert two dimensional array of String to stream of Strings.</h4>
        <p>It converts {{"Mike", "Micky"}, {"Pearl", "John"}, {"James", "Emma"}} to 
        {"Mike", "Micky", "Pearl", "John","James", "Emma"}</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Convert two dimensional array of String to stream of Strings using flatmap
import java.util.Arrays;
import java.util.stream.Stream;
    
public class StreamFlatMap { 

    public static void main(String[] args) {
        String[][] strs = new String[][]{{"Mike", "Micky"}, {"Pearl", "John"},
            {"James", "Emma"}};

        Stream&lt;String[]&gt; stream1 = Arrays.stream(strs);
        Stream&lt;String[]&gt; stream = stream1.filter(x -> "Micky".equals(x.toString()));
        stream.forEach(System.out::println);  // prints nothing 
        
        Stream&lt;String[]&gt; stream2 = Arrays.stream(strs);
        Stream&lt;String&gt; stringStream = stream2.flatMap(x -> Arrays.stream(x));
        stringStream.forEach(System.out::println);
        
        Stream&lt;String[]&gt; stream3 = Arrays.stream(strs);
        stringStream = stream3.flatMap(x -> Arrays.stream(x));
        stringStream = stringStream.filter(x -> "Micky".equals(x.toString()));  
        
        stringStream.forEach(System.out::println);    // prints Micky
    }
}	
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Mike
Micky
Pearl
John
James
Emma
Micky
</pre>
	</div>	
    
<div id="solution">
		<h4>2) Java 8 Stream flatmap example to get list of all states for two countries</h4>
        <p>Suppose you have two Country objects and each one has list of states, now you want to get
        list of all the states that belong to all the countries, you can do it using Stream flatmap as shown below:</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.Set;    
public class Country {

    private String name;
    private Set&lt;String&gt; states;

    public Country(String name, Set&lt;String&gt; states) {
        this.states = states;
        this.name = name;
    }

    public Set&lt;String&gt; getStates() {
        return this.states;
    }
}
</pre>
	</div>
<div id="code">
	<pre class="prettyprint">    
// Stream flatmap example
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
    
public class StreamFlatMap { 

    public static void main(String[] args) {
        
        Set&lt;String&gt; russianStates = new HashSet&lt;String&gt;();
        russianStates.add("rs1");
        russianStates.add("rs2");
        
        Country russia = new Country("Russia", russianStates);
        
        Set&lt;String&gt; germanStates = new HashSet&lt;String&gt;();
        germanStates.add("gs1");
        germanStates.add("gs2");
        
        Country germany = new Country("Germany", germanStates);
        
        List&lt;Country&gt; countries = new ArrayList&lt;Country&gt;();
        countries.add(russia);
        countries.add(germany);
        
        Stream&lt;Country&gt; collect =   countries.stream();
        Stream&lt;Set&lt;String&gt;&gt; streamSet = collect.map(c -> c.getStates());
        Stream&lt;Object&gt; streamObject = streamSet.flatMap(x -> x.stream());
        List&lt;Object&gt; allStates = streamObject.collect(Collectors.toList());
        
        // prints all the states for all the countries
        allStates.forEach(System.out::println);  
    }
}	
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
rs2
rs1
gs1
gs2
</pre>
	</div>	


	<div id="solution">
		<h4>3) Java 8 Stream flatMapToInt example to convert list of String to stream of int.</h4>
        <p>flatMapToInt() method is defined in Stream interface. It has following signature </p>
        <b><i><R> IntStream flatMapToInt(Function&lt;&quest; super T, &quest; extends IntStream&gt; mapper)</b></i>
        
        <p>Below example converts {"1", "2", "3", "4", "5", "6"} to {1, 2, 3, 4, 5, 6}</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Convert two dimensional array of int to stream of int using flatMapToInt
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;
    
public class StreamFlatMapToInt { 

    public static void main(String[] args) {
        List&lt;String&gt; list = Arrays.asList("1","2","3","4","5","6");
        Stream&lt;String&gt; stream = list.stream();
        IntStream intStream =  stream.flatMapToInt(n-> IntStream.of(Integer.parseInt(n)) );
        intStream.forEach(System.out::println);
     
    }
}	
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
1
2
3
4
5
6
</pre>
	</div>	    
 <br>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#flatMap-java.util.function.Function-">Oracle Docs Stream flatmap</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/util/function/Function.html">Oracle Docs Function</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#flatMapToInt-java.util.function.Function-">Oracle Docs flatMapToInt</a> 
	</div>
	
<?php 
    include("footer.htm");
?>
	
</body>
</html>
