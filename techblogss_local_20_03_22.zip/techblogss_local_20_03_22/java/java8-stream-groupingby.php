<?php include("../header.htm");?>

<head>
    <title>Java 8 Collectors groupingby examples</title>
	<meta name="description" content="Java 8 Stream groupingby, Java collectors groupingby(), mapping(), counting(), averagingInt and summingInt()" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-stream-groupingby" />
</head>

<body>
	<?php include("../navigation.htm");?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h2>Java 8 Collectors groupingby examples</h2>
    </div> 
    
    <div id="solution">
		<h4>1) Example that shows how to group the objects by any attribute using Collectors groupingBy()</h4>
        <p>If you have a list of objects say list of persons and you want to group them by rollNumber, you can use <b><i>Collectors
		groupingBy()</b></i> method.
        </p>
	</div>

	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
	
class Student {
    private int rollNumber;
    private String name;
    private int age;
	
    Student (int rollNumber, String name, int age) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.age = age;
    }
    
    // removed getters and setter for brevity    
   
    @Override
    public String toString() {
        return "Student [rollNumber=" + rollNumber + ", name=" + name + ", age="+ age + "]";
    }
} </pre></div>

	<div id="code">
	<pre class="prettyprint">
// Converts List to Map using Collectors groupingBy() method
public class ListToMapConverter { 

    public static void main(String[] args) {
        // create students list
			
        Stream&lt;Student&gt; studentStream = students.stream();
        Map&lt;Integer, List&lt;Student&gt;&gt; rollNumberNameMap = 
        studentStream.collect(Collectors.groupingBy(Student::getRollNumber));
        System.out.println(rollNumberNameMap); 
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{1=[Student [rollNumber=1, name=John, age=13],
 Student [rollNumber=1, name=James, age=15]],
 2=[Student [rollNumber=2, name=Mark, age=14]],
 3=[Student [rollNumber=3, name=Henry, age=13]]}	</pre></div><br>
    
        
	<div id="solution">
        <h4>
        If you have a list of objects say list of persons and you want to group them by age or name, you can use <b><i>Collectors 
        groupingBy()</b></i> method.
        </h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingBy {

    public static void main(String[] args) {
        Person harry = new Person("Harry", 34);
        Person robert = new Person("Robert", 27);
        Person hillary = new Person("Hillary", 34);
        List&lt;Person> persons = Arrays.asList(harry, robert, hillary);
        Map&lt;Integer, List&lt;Person>> personsGroup 
            = persons.stream().collect(Collectors.groupingBy(Person::getAge));
        System.out.println(personsGroup);
    }
}	</pre>
	</div>

<div id="code">
<pre class="prettyprint">
class Person {

    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // removed getters and setter for brevity

    @Override
    public String toString() {
        return "Person [name=" + name + ", age=" + age + "]";
    }

}	</pre>
	</div>
<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{34=[Person [name=Harry, age=34], Person [name=Hillary, age=34]], 27=[Person [name=Robert, age=27]]}</pre>
	</div>	
    <br>
    
	<div id="solution">
		<h4>2) Collectors groupingBy() and counting() example</h4>
        <p>
        If you want to count the number of persons that belong to a age group, you can use
        <b><i>Collectors groupingBy(Function, Collector)</b></i>.
        </p>
        
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingBy {

    public static void main(String[] args) {
        Person harry = new Person("Harry", 34);
        Person robert = new Person("Robert", 27);
        Person hillary = new Person("Hillary", 34);
        Person james = new Person("James", 31);
        List&lt;Person> persons = Arrays.asList(harry, robert, hillary, james);
        Map&lt;Integer, Long> personsGroupCounting 
            = persons.stream().collect(Collectors.groupingBy(Person::getAge, Collectors.counting()));
        System.out.println(personsGroupCounting);
    }
}	</pre>
	</div>

<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{34=2, 27=1, 31=1}	</pre></div><br>

    <div id="solution">
		<h4>3) Collectors groupingBy() and mapping() example</h4>
        <p>
        If you want to group the persons by age and only want the names of the persons instead of whole Person object, you can use
         <b><i>Collectors mapping(Function, Collector)</b></i> function.
        </p>
 	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingBy {

    public static void main(String[] args) {
        // create persons list
        Map&lt;Integer, List&lt;String>> namesByAge 
            = persons.stream().collect(Collectors.groupingBy(Person::getAge, 
            Collectors.mapping(Person::getName, Collectors.toList())));
        System.out.println(namesByAge);
    }
}	</pre></div>

    <div id="solution">
		<h4>Console Output : </h4>
    </div>
	
	<div id="code">
		<pre class="prettyprint">
{34=[Harry, Hillary], 27=[Robert], 31=[James]}	</pre></div>	
	<br>
    
    <div id="solution">
		<h4>4) Collectors groupingBy() and summingInt() example</h4>
        <p>
        Suppose you have list of students and you want to calculate the total marks of a student, you can use <b><i>Collectors summingInt()</b></i> 
        function.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingBy {

    public static void main(String[] args) {
        List&lt;Student> students = new ArrayList&lt;>();
        students.add(new Student(1, "English", 74));
        students.add(new Student(1, "Science", 89));
        students.add(new Student(2, "English", 89));
        students.add(new Student(2, "Science", 91));
        students.add(new Student(3, "English", 69));
        students.add(new Student(3, "Science", 95));
		
        Map&lt;Integer, Integer> marks = students.stream().collect(Collectors.groupingBy(Student::getId,
            Collectors.summingInt(Student::getMarks)));
        System.out.println(marks);
    }
}	</pre></div>

<div id="code">
<pre class="prettyprint">
class Student {
    private final int id;
    private final String subject;
    private final int marks;

    public Student(int id, String subject, int marks) {
        this.id = id;
        this.subject = subject;
        this.marks = marks;
    }

   // removed getters and setter for brevity

    @Override
    public String toString() {
        return "Student [id=" + id + ", subject=" + subject + ", marks="+ marks + "]";
    }

}    
</pre>
</div>
    <div id="solution">
		<h4>Console Output : </h4>
       
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{1=163, 2=180, 3=164}	</pre></div><br>  

    <div id="solution">
		<h4>5) Collectors groupingBy() and averagingInt() example</h4>
        <p>
        Suppose you have list of students and you want to calculate the average of marks for a subject, you can use 
        <b><i>Collectors averagingInt()</b></i> function.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingBy {

    public static void main(String[] args) {
        List&lt;Student> students = new ArrayList&lt;>();
        students.add(new Student(1, "English", 74));
        students.add(new Student(1, "Science", 89));
        students.add(new Student(2, "English", 89));
        students.add(new Student(2, "Science", 91));
        students.add(new Student(3, "English", 69));
        students.add(new Student(3, "Science", 95));
		
        Map&lt;String, Double> average = students.stream().collect(
				Collectors.groupingBy(Student::getSubject, Collectors.averagingInt(Student::getMarks)));
		System.out.println(average);
    }
}
	</pre>
	</div>  

<div id="solution">
		<h4>Console Output : </h4>
       
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{English=77.33333333333333, Science=91.66666666666667}	</pre></div><br>  
    
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html" target="_blank">Oracle Docs Collectors</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html#groupingBy-java.util.function.Function-" target="_blank">Oracle Docs Comparator Collectors groupingBy()</a>	<br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
