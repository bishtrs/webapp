<?php include("../header.htm");?>

<head>
    <title>Checked and unchecked exception example</title>
	<meta name="description" content="Checked and unchecked exception example"/>
	<link rel="canonical" href="https://www.techblogss.com/java/java-checked-unchecked-exception">
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
   	<div id="content">
	<div id="blog">
	<div id="problem">
		<h1>Checked and unchecked exception example</h1>
	</div>

	<div id="solution">
    <h3>Checked Exceptions</h3>
    <p>
        Checked Exceptions are Exceptions which must be caught in the code using catch block or should be declared with throws clause.
        If not then the code would not compile. Checked Exceptions extend <code>Exception</code> class. Checked Exceptions are handled in
        scenarios when you are sure that application can recover from the situation that led to Exception.
    </p>
    <p>
        For example in below code when you create a <code>FileReader</code> instance, you need to provide catch block to catch the 
        <code>FileNotFoundException</code>, else code will not compile or else the method can declare that it throws <code>FileNotFoundException</code>.
    </p>
    </div>
        
    <div id="code">
    <pre class="prettyprint">
public void readFile() {        
    try {
        FileReader reader = new FileReader("C://File.txt")
    } catch (FileNotFoundException e) { 
        e.printStackTrace(); 
    }
}</pre></div>

<p><b>OR</b></p>

<div id="code">
    <pre class="prettyprint">
public void readFile() throws FileNotFoundException {        
    FileReader reader = new FileReader("C://File.txt")
}</pre></div><br>

<div id="solution">
    <h3>Unchecked Exceptions</h3>
    <p>
        Unchecked Exceptions (also called runtime exceptions) extend <code>RuntimeException</code> class which is not mandatory to be caught in the code using catch block 
        nor required to be declared with throws clause.
    </p>
    <p>
        For example below code will throw <code>ArithmeticException</code> but it is not required to handle it, though you can 
        still use try catch block to catch the Exception.
        Unchecked Exceptions are generally not caught as there is little you can do after an Unchecked Exception is thrown.
    </p>
    </div>
        
    <div id="code">
    <pre class="prettyprint">
public void divide() {        
    int div = 4/0;
}</pre></div>

<div id="code">
    <pre class="prettyprint">
public void divide() {        
    try {
        int div = 4/0;
    } catch (ArithmeticException e) { 
        e.printStackTrace(); 
    }
}</pre></div><br>
    
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
	</div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
    
</body>



<?php 
    include("footer.htm");
?>

</html>
