<?php 
    include("header.htm");
?>

<head>
    <title>Parse JSON in Java </title>
	<meta name="description" content="Parse JSON in Java, Parse JSON string Java" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_parsejson">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
	
    <div id="content">
    <div id="blog">
	<div id="problem">
		<h2>Parse JSON in Java using simple JSONObject</h2>
	</div>
	
	<div id="solution" style="text-align: justify;">
		<p>JSON (JavaScript Object Notation) is a lightweight data-interchange format. It is easy for humans to read and write. 
		JSON can represent two structured types: objects and arrays. To parse JSON using simple JSONObject you need to download: </p>
		<a href="https://code.google.com/archive/p/json-simple/downloads">json-simple-1.1.1.jar </a> 
        <p>Below is the JSON string to parse</p>
	</div>
		
    <div id="code">
	
	<pre class="prettyprint">
{
    "id":12345, 
    "name":"Jason Bourne",
    "age":35,
    "emailaddress":["j.bourne@gmail.com", "j.bourne@yahoo.com"]
}
	</pre>
	</div>

	<div id="solution">
		<h4>1) Parse JSON using simple JSONObject.</h4>
        <p>Below example shows how to parse a JSON string and convert json to object.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Parses JSON    
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
				
public class TestJson {
    public static void main(String[] args) {
        JSONParser parser = new JSONParser();
        String agent = "{\"id\":12345, \"name\":\"Jason Bourne\","+
        "\"age\":35,\"emailaddress\":[\"j.bourne@gmail.com\","+
        "\"j.bourne@yahoo.com\"]}";
        
        try {
            Object obj = parser.parse(agent);
            JSONObject jsonObject = (JSONObject) obj;
            
            String name = (String) jsonObject.get("name");
            System.out.println(name);
            
            long age = (Long) jsonObject.get("age");
            System.out.println(age);
            
            JSONArray emailaddress = (JSONArray) jsonObject.get("emailaddress");
            
            Iterator&lt;String&gt; iterator = emailaddress.iterator();
            while (iterator.hasNext()) {
                System.out.println(iterator.next());
            }
        } catch (ParseException pe) {
            pe.printStackTrace();
        }

    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Jason Bourne
35
j.bourne@gmail.com
j.bourne@yahoo.com
		</pre>
	</div>	

<div id="solution">
		<h4>2) Write JSON object to a file using simple JSONObject.</h4>
        <p>Below example shows how to convert a object to JSON string and then write it to file.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Writes JSON object to a file

package json;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
				
public class TestJsonWriter {
    public static void main(String[] args) {
        JSONParser parser = new JSONParser();
        String agent = "{\"id\":12345, \"name\":\"Jason Bourne\","+
        "\"age\":35,\"emailaddress\":[\"j.bourne@gmail.com\","+
        "\"j.bourne@yahoo.com\"]}";
        
        JSONObject jsonObject = new JSONObject(); 
        jsonObject.put("id", 12345);
        jsonObject.put("name", "Jason Bourne");
        jsonObject.put("age", 35);
            
        JSONArray emailaddress = new JSONArray();
        emailaddress.add("j.bourne@gmail.com");
        emailaddress.add("j.bourne@yahoo.com");
		
        jsonObject.put("emailaddress", emailaddress);
                
        System.out.println(jsonObject);
                
        PrintWriter pw = null;
        try {
            pw = new PrintWriter("C:///Data.json");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } 

        pw.write(jsonObject.toJSONString()); 
          
        pw.flush(); 
        pw.close(); 

    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{"name":"Jason Bourne","emailaddress":["j.bourne@gmail.com","j.bourne@yahoo.com"],"id":12345,"age":35}
		</pre>
	</div>	
	
	<div id="comments">
        <h4>Comments on above approach:</h4>
		<ul>
			<li>JSONParser is a simple library & performs at high level.</li>
            <li>You can use <a href="java_parsejson_jackson">jackson parser</a> & <a href="java_parsejson_gson">gson parser</a> also to parse JSON object.</li>
        </ul>
	</div>
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>
	
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
</body>

<?php 
    include("footer.htm");
?>

</html>
