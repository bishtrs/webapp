<?php include("../header.htm");?>

<head>
    <title>Spring Boot circuit breaker resilience4j example</title>
    <meta name="description" content="Spring Boot circuit breaker resilience4j example" />
    <link rel="canonical" href="https://www.techblogss.com/microservices/microservices-circuit-breaker" />
</head>

<body>
    <?php include("../navigation.htm");?>
        
    <div id="content">
    <div id="blog">
        <div id="problem">
            <h1>Hystrix circuit breaker Spring boot</h1>
        </div>
        <div id="solution">
            <p>
			A <b><i>Circuit Breaker</b></i> is designed to avoid repeating timeouts. The circuit breaker keeps track of every time a specific	
			request fails or produces a timeout. If this count exceeds a certain level, it prevents further calls to service, instead of returning
			an error instantly.
			</p>
			<p>
			<b><i>Circuit Breaker</b></i> also provides a fallback call to return the response to caller. It also incorporates a mechanism for
			retrying the call, either after a certain amount of time or in reaction to an event. <b><i>Circuit breakers</b></i> are important
			when calling external services. Below example shows how to implement <b><i>Circuit Breaker</b></i> using <b><i>Netflix Hystrix</b></i>.
			</p>    
        </div>
        
        <h4>Step 1) Create pom.xml file as below to create MovieService Spring Boot application </h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?>
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    &lt;modelVersion>4.0.0&lt;/modelVersion>

    &lt;groupId>com.example&lt;/groupId>
    &lt;artifactId>movie-service&lt;/artifactId>
    &lt;version>0.0.1-SNAPSHOT&lt;/version>
    &lt;packaging>jar&lt;/packaging>

    &lt;name>movie-service&lt;/name>
    &lt;description>Demo project for Spring Boot&lt;/description>

    &lt;parent>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
        &lt;version>2.1.6.RELEASE&lt;/version>
        &lt;relativePath/> &lt;!-- lookup parent from repository -->
    &lt;/parent>

    &lt;properties>
        &lt;java.version>1.8&lt;/java.version>
    &lt;/properties>

    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.boot&lt;/groupId>
            &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
        &lt;/dependency>
            
    &lt;/dependencies>
	
    &lt;build>
        &lt;plugins>
            &lt;plugin>
                &lt;groupId>org.springframework.boot&lt;/groupId>
                &lt;artifactId>spring-boot-maven-plugin&lt;/artifactId>
            &lt;/plugin>
        &lt;/plugins>
    &lt;/build>
	
&lt;/project>
        </pre>
        </div>
        <br>

    <div id="1">
    <h4>Step 2) Create Movie, MovieRestController, MovieServiceApplication classes to create MovieService microservice </h4>
    <div id="code">
    <pre class="prettyprint">
package com.example;

    public class Movie {

    private String title;
    private String genre;

    public Movie(String title, String genre) {
        this.title = title;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Movie [title=" + title + ", genre=" + genre + "]";
    }

}
  </div>
    </pre>	

<div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MovieServiceApplication.class, args);
    }

}
  </div>
    </pre>	

<div id="code">
    <pre class="prettyprint">
package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MovieRestController {
	
    @RequestMapping(value = "/movies") // http://localhost:8090/movies
    public List&lt;Movie> listAll() {

        List&lt;Movie> movies = new ArrayList<>();
        movies.add(new Movie("Lord of the Rings", "Fantasy"));
        movies.add(new Movie("The Specialist", "Thriller"));
        System.out.println("returning list of movies " + movies);
        return movies;
    }

}
  </div>
    </pre>    
    <br>
    
<h4>Step 3) Create application.yml file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
spring:
  application:
    name: movie-service

server:
  port: 8090
    </div>
    </pre>	

    </div>    

 <br>
    <h4>Step 4) Building MovieServiceApplication</h4>
     
    <p> Build this Spring Boot application using this command &rarr; <b><i>mvn clean install</b></i></p>

    <h4>Step 5) Running MovieServiceApplication</h4>
    <p>Run this Spring Boot application using following command &rarr; <b><i>java -jar movie-service-0.0.1-SNAPSHOT.jar</b></i></p>
    

<div id="solution">Open <a href="http://localhost:8090/movies" target="_blank">http://localhost:8090/movies</a> in the browser.
    <p>You will see below page displayed in the broswer.</p>
    </div>
    
        <div>
            <img src="../images/microservices/ribbon_2.jpg" alt="Ribbon" style="width:380px;height:300px;">
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br>
    
    <h4>Step 6) Create pom.xml file as below to create MovieClient</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?>
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    &lt;modelVersion>4.0.0&lt;/modelVersion>

    &lt;groupId>com.example&lt;/groupId>
    &lt;artifactId>circuitbreaker-client&lt;/artifactId>
    &lt;version>0.0.1-SNAPSHOT&lt;/version>
    &lt;packaging>jar&lt;/packaging>

    &lt;name>circuitbreaker-client&lt;/name>
    &lt;description>Demo project for Spring Boot&lt;/description>

    &lt;parent>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
        &lt;version>2.1.6.RELEASE&lt;/version>
        &lt;relativePath /> &lt;!-- lookup parent from repository -->
    &lt;/parent>

    &lt;properties>
        &lt;java.version>1.8&lt;/java.version>
    &lt;/properties>

    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.boot&lt;/groupId>
            &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
        &lt;/dependency>
        &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-starter-netflix-hystrix&lt;/artifactId>
        &lt;/dependency>
    &lt;/dependencies>
	
    &lt;dependencyManagement>
        &lt;dependencies>
            &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
            &lt;version>Greenwich.SR3&lt;/version>
            &lt;type>pom&lt;/type>
            &lt;scope>import&lt;/scope>
        &lt;/dependency>
        &lt;/dependencies>
    &lt;/dependencyManagement>

    &lt;build>
        &lt;plugins>
            &lt;plugin>
                &lt;groupId>org.springframework.boot&lt;/groupId>
                &lt;artifactId>spring-boot-maven-plugin&lt;/artifactId>
            &lt;/plugin>
        &lt;/plugins>
    &lt;/build>

&lt;/project>

       </pre>	  </div>
           
        
        <br>
        
         <h4>Step 7) Create MovieClient, CircuitBreakerMovieApplication classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@Service
public class MovieClient {

    private final RestTemplate restTemplate;

    public MovieClient(RestTemplate rest) {
        this.restTemplate = rest;
    }

    @HystrixCommand(fallbackMethod = "reliable")
    public String movieList() {
        URI uri = URI.create("http://localhost:8090/movies");
        return this.restTemplate.getForObject(uri, String.class);
    }

    public String reliable() {
        return "{title:Lord of the Rings, genere:Fantasy}";
    }

}

   </pre> </div>
       
        
<div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@EnableCircuitBreaker
@SpringBootApplication
@RestController
public class CircuitBreakerMovieApplication {

    @Autowired
    private MovieClient movieClient;

    @Bean
    public RestTemplate rest(RestTemplateBuilder builder) {
        return builder.build();
    }

    @RequestMapping("/allMovies")
    public String getMovieList() {
        return this.movieClient.movieList();
    }

    public static void main(String[] args) {
        SpringApplication.run(CircuitBreakerMovieApplication.class, args);
    }

}
  
    </pre> </div>
        
        <br>
   
    <div id="solution">
        <h4>Step 8) Launch CircuitBreakerMovieApplication open <a href="http://localhost:8080/allMovies" target="_blank">
        http://localhost:8080/allMovies</a> in the browser.</h4>
    </div>
        <br>
        <div>
            <p><img src="../images/microservices/ribbon_4.jpg" alt="Maven Build" style="width:400px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br>  
    
    <div id="solution">
        <h4>Step 9) Now shutdown MovieServiceApplication and refresh <a href="http://localhost:8080/allMovies" target="_blank">
        http://localhost:8080/allMovies</a> in the browser.</h4>
        <p>Now circuit breaker will come into picture and will not send rqeuests to MovieServiceApplication. Instead it will return the data
        provided by the fallback mechanism by invoking MovieClient reliable() method.</p>
    </div>
        <br>
        <div>
            <p><img src="../images/microservices/circuitbreaker.jpg" alt="Maven Build" style="width:300px;height:100px;"></p>
        </div>
        
        <br><br><br><br><br>
    References : <br><br>
    <a href="https://docs.spring.io/spring-cloud-circuitbreaker/docs/current/reference/html/">Spring Cloud Circuit Breaker</a>	<br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
    <div id="content">
    <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>