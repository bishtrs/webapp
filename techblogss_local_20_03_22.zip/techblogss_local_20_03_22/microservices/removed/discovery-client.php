    <?php 
        include("header.htm");
    ?>

    <head>
        <title>Service Discovery with DiscoveryClient</title>
        <meta name="description" content="Service Discovery with DiscoveryClient, Microservices Service discovery with DiscoveryClient,
        Service Discovery with Spring Cloud DiscoveryClient" />
        <link rel="canonical" href="https://www.techblogss.com/microservices/discovery-client" />
    </head>

    <body>
        <?php 
            include("navigation.htm");
        ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h2>Service Discovery with Spring Cloud DiscoveryClient</h2>
        </div>
        <div id="solution">
            <p>The Spring Cloud <b><i>DiscoveryClient</b></i> provides a simple API (not specific to Netflix) for discovery clients, as shown in the
            following example.
            </p>  
            <p>Below example shows how to register and lookup a <b><i>microservice</b></i> using <b><i>Spring Cloud DiscoveryClient</b></i>.
            We will create a <b><i>Eureka Service Registry server</b></i> and register <b><i>DVD service microservice</b></i> with it.
            DVD Client Application will lookup DVD Service microservice in the <b><i>Eureka Service Registry</b></i> and invoke its method.
            </p>             
        </div>
        
        <div>
            <img src="../images/microservices/discoveryclient.jpg" alt="Maven Build" style="width:400px;height:300px;margin-left:100px">
        
            <br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>
        
        <h4>Step 1) Create pom.xml file as below to create Eureka Service registry </h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;

    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;eureka-service&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;packaging&gt;jar&lt;/packaging&gt;

    &lt;parent&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.2.1.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;

    &lt;properties&gt;
        &lt;project.build.sourceEncoding&gt;UTF-8&lt;/project.build.sourceEncoding&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-starter-netflix-eureka-server&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;/dependencies&gt;

    &lt;dependencyManagement&gt;
        &lt;dependencies&gt;
            &lt;dependency&gt;
                &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
                &lt;artifactId&gt;spring-cloud-dependencies&lt;/artifactId&gt;
                &lt;version&gt;Hoxton.RELEASE&lt;/version&gt;
                &lt;type&gt;pom&lt;/type&gt;
                &lt;scope&gt;import&lt;/scope&gt;
            &lt;/dependency&gt;
        &lt;/dependencies&gt;
    &lt;/dependencyManagement&gt;

    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;
        </pre>
        </div>
        <br>

    <div id="1">
    <h4>Step 2) Create EurekaServiceApplication class to launch Eureka Service registry</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class EurekaServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(EurekaServiceApplication.class, args);
  }
}
  </div>
    </pre>	
    <br>
    
<h4>Step 3) Create application.properties file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
server.port=8761

eureka.client.register-with-eureka=false
eureka.client.fetch-registry=false

logging.level.com.netflix.eureka=OFF
logging.level.com.netflix.discovery=OFF
    </div>
    </pre>	

    </div>    

 <br>
<h4>Step 4) Launch EurekaServiceApplication and open <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a>
 in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/eureka_1.jpg" alt="Maven Build" style="width:800px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
<br>    
    
    <h4>Step 5) Create pom.xml file as mentioned below for DVDService application</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?>
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    &lt;modelVersion>4.0.0&lt;/modelVersion>

    &lt;groupId>com.example&lt;/groupId>
    &lt;artifactId>dvd-service&lt;/artifactId>
    &lt;version>0.0.1-SNAPSHOT&lt;/version>
    &lt;packaging>jar&lt;/packaging>

    &lt;parent>
	&lt;groupId>org.springframework.boot&lt;/groupId>
	&lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
	&lt;version>2.2.1.RELEASE&lt;/version>
	&lt;relativePath /> &lt;!-- lookup parent from repository -->
    &lt;/parent>

    &lt;properties>
	&lt;project.build.sourceEncoding>UTF-8&lt;/project.build.sourceEncoding>
	&lt;java.version>1.8&lt;/java.version>
    &lt;/properties>

    &lt;dependencies>
	&lt;dependency>
		&lt;groupId>org.springframework.cloud&lt;/groupId>
		&lt;artifactId>spring-cloud-starter-netflix-eureka-client&lt;/artifactId>
	&lt;/dependency>
	&lt;dependency>
		&lt;groupId>org.springframework.boot&lt;/groupId>
		&lt;artifactId>spring-boot-starter-web&lt;/artifactId>
	&lt;/dependency>

    &lt;/dependencies>

    &lt;dependencyManagement>
	&lt;dependencies>
		&lt;dependency>
			&lt;groupId>org.springframework.cloud&lt;/groupId>
			&lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
			&lt;version>Hoxton.RELEASE&lt;/version>
			&lt;type>pom&lt;/type>
			&lt;scope>import&lt;/scope>
		&lt;/dependency>
	&lt;/dependencies>
    &lt;/dependencyManagement>

    &lt;build>
	&lt;plugins>
		&lt;plugin>
			&lt;groupId>org.springframework.boot&lt;/groupId>
			&lt;artifactId>spring-boot-maven-plugin&lt;/artifactId>
		&lt;/plugin>
	&lt;/plugins>
    &lt;/build>

&lt;/project>
        </div>
        </pre>	    
        
        <br>
        
         <h4>Step 6) Create DVD, DVDApplication & DVDRestController classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

public class DVD {
	
    private String title;
    private String director;
    private String genre;
        
    public DVD(String title, String director, String genre) {
        this.title = title;
        this.director = director;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getDirector() {
        return director;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "DVD [title=" + title + ", director=" + director + ", genre=" + genre + "]";
    }
	
}   </div>
        </pre>
        
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class DVDApplication {

    public static void main(String[] args) {
        SpringApplication.run(DVDApplication.class, args);
    }
}  </div>
        </pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DVDRestController {
	
    List&lt;DVD> dVDs = new ArrayList&lt;>();
	
    public DVDRestController() {
        dVDs.add(new DVD("Lord of the Rings", "Peter Jackson", "Fantasy"));
        dVDs.add(new DVD("The Specialist", "Luis Llosa", "Thriller"));
        dVDs.add(new DVD("The World Is Not Enough", "Michael Apted", "Spy"));
    }

    @GetMapping("/{id}") 
    public DVD get(@PathVariable("id") int id) {
        return dVDs.get(id);
    }
}   </div>
        </pre>        
        <br>
 
<h4>Step 7) Create application.yml file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
server:
  port: 9098
 
eureka:
  client:
    serviceUrl:
      defaultZone: http://localhost:8761/eureka/
 
spring:
  application:
    name: dvd-service    
 
</div>
    </pre>	 
   <br>    
   
	   <h4>Step 8) Create pom.xml file as mentioned in Step # 5 to create DVDDiscoveryClientApplication which will act as Eureka Client
       and will invoke DVD Service using Eureka service registry.
Just update the artifactId in the pom.xml to below  </h4>
        <div id="code">
        <pre class="prettyprint">
&lt;groupId&gt;com.example&lt;/groupId&gt;
&lt;artifactId&gt;dvd-dicovery-client&lt;/artifactId&gt;
&lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
&lt;packaging&gt;jar&lt;/packaging&gt;
        </div>
        </pre>	    
        
        <br>
		
<h4>Step 9) Create DVDDiscoveryClientApplication & DVDDiscoveryClientController classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DVDDiscoveryClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(DVDDiscoveryClientApplication.class, args);
    }
}   </div>
    </pre>		

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class DVDDiscoveryClientController {

    @Autowired
    private DiscoveryClient discoveryClient;

    @RequestMapping("/dvd-servive/{id}")
    public ResponseEntity&lt;?> getDVD(@PathVariable String id) {
        List&lt;ServiceInstance> instances = discoveryClient.getInstances("dvd-service");
        System.out.println("number of instances " + instances.size());
        String serviceUri = String.format("%s/%s", instances.get(0).getUri().toString(),id);
            
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForEntity(serviceUri, String.class);
    }
	
}
   </div>
    </pre>			
    <br>

<h4>Step 10) Create application.yml file under src/main/resources</h4>
<p>Note that we don't need to register DVDDiscoveryClientApplication with service registry, hence we set <br> <b><i>register-with-eureka : false</i>
</b></p>
    <div id="code">
    <pre class="prettyprint">
server:
  port: 8084    
 
eureka:
  client:
    register-with-eureka : false
    fetch-registry : true
 
spring:
  application:
    name: dvd-discovery-client    
    </div>
    </pre>	 
   <br>  
   
    <h4>Step 11) Launch DVDApplication & DVDDiscoveryClientApplication and open <a href="http://localhost:8084/dvd-service/1" target="_blank">
    http://localhost:8084/dvd-service/1</a> in the browser.</h4>
    <p>Note that <b><i>DVDDiscoveryClientApplication</b></i> first looks up DVD service in service registry with the help of Discovery Client
    and then invokes DVD service.</p>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/discoveryclient_2.jpg" alt="DVDDiscoveryClientApplication" style="width:400px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br>
    </div>
    
    <br>   
    
    <h4>Step 12) Also refresh <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a> in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/discoveryclient_3.jpg" alt="Service registry" style="width:600px;height:600px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
<br>   
        
    References : <br><br>
    <a href="https://spring.io/guides/gs/service-registration-and-discovery/" target="_blank">Spring Service Registration and Discovery</a>	<br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>