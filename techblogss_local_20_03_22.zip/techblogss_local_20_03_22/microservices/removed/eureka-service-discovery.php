<?php include("../header.htm");?>

    <head>
        <title>Eureka Service Discovery</title>
        <meta name="description" content="Eureka Service Discovery" />
        <link rel="canonical" href="https://www.techblogss.com/microservices/eureka-service-discovery" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Eureka Service Discovery example</h1>
        </div>
        <div id="solution">
            <p>
            With multiple instances of <code>microservices</code>, you need a mechanism for locating services and load balancing over 
            the different instances of the service you are calling.
            </p> 
            
            <p>
            A <code>service registry</code> is a typically used as a store that holds a list of all the available <code>microservice</code> at
            any time and can be used by any client to lookup a <code>microservice</code>. Also <code>microservices</code> register and unregister
            themselved when they come up and shutdown. A <code>microservice</code> sends heartbeats to the registry to show that it is
            up and can receive requests. If it is not up, <code>service registry</code> will remove it from its store and will not return the 
            instance when clients look it up. 
            </p>
            
            <p>
            Below Eureka Service Discovery example shows how to register and lookup a <code>microservice</code> using <b><i>Netflix Eureka service 
            registry</b></i>. We will create a <b><i>Eureka Service Registry server</b></i> and register two <code>microservices</code> named 
            <b><i>BookService</b></i> and <b><i>BookAdvisorService</b></i> respectively. <b><i>BookAdvisorService</b></i> microservice will discover 
            or lookup <b><i>BookService</b></i> microservice in the <b><i>Eureka Service Registry</b></i> and invoke its exposed endpoint.
            </p>    
        </div>
        
        <div>
            <img src="../images/microservices/eureka_2.jpg" alt="Maven Build" style="width:600px;height:400px;">
        
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        
        <div id="code">
        <pre class="prettyprint">
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-starter-netflix-eureka-server&lt;/artifactId&gt;
        &lt;/dependency&gt;
    &lt;/dependencies&gt;

    &lt;dependencyManagement&gt;
        &lt;dependencies&gt;
            &lt;dependency&gt;
                &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
                &lt;artifactId&gt;spring-cloud-dependencies&lt;/artifactId&gt;
                &lt;version&gt;Hoxton.RELEASE&lt;/version&gt;
                &lt;type&gt;pom&lt;/type&gt;
                &lt;scope&gt;import&lt;/scope&gt;
            &lt;/dependency&gt;
        &lt;/dependencies&gt;
    &lt;/dependencyManagement&gt;</pre></div><br>

    <div id="1">
    <h4>Step 2) Create EurekaServiceApplication class to launch Eureka Service registry</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class EurekaServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(EurekaServiceApplication.class, args);
  }
}  </pre></div><br>
    
<h4>Step 3) Create application.properties file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
server.port=8761

eureka.client.register-with-eureka=false
eureka.client.fetch-registry=false

logging.level.com.netflix.eureka=OFF
logging.level.com.netflix.discovery=OFF </pre></div>    

    </div><br>
    
    <h4>Step 4) Launch EurekaServiceApplication and open <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a>
    in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/eureka_1.jpg" alt="Maven Build" style="width:800px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div><br>    
    
    <h4>Step 5) Create pom.xml file as mentioned below for BookService application</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?>
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    &lt;modelVersion>4.0.0&lt;/modelVersion>

    &lt;groupId>com.example&lt;/groupId>
        &lt;artifactId>book-service&lt;/artifactId>
        &lt;version>0.0.1-SNAPSHOT&lt;/version>
    &lt;packaging>jar&lt;/packaging>

    &lt;parent>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
        &lt;version>2.2.1.RELEASE&lt;/version>
        &lt;relativePath /> &lt;!-- lookup parent from repository -->
    &lt;/parent>

    &lt;properties>
        &lt;project.build.sourceEncoding>UTF-8&lt;/project.build.sourceEncoding>
        &lt;java.version>1.8&lt;/java.version>
    &lt;/properties>

    &lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.cloud&lt;/groupId>
        &lt;artifactId>spring-cloud-starter-netflix-eureka-client&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
    &lt;/dependency>

    &lt;/dependencies>

    &lt;dependencyManagement>
    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
            &lt;version>Hoxton.RELEASE&lt;/version>
            &lt;type>pom&lt;/type>
            &lt;scope>import&lt;/scope>
        &lt;/dependency>
    &lt;/dependencies>
    &lt;/dependencyManagement>

    &lt;build>
    &lt;plugins>
        &lt;plugin>
            &lt;groupId>org.springframework.boot&lt;/groupId>
            &lt;artifactId>spring-boot-maven-plugin&lt;/artifactId>
        &lt;/plugin>
    &lt;/plugins>
    &lt;/build>

&lt;/project>        </div></pre><br>
        
         <h4>Step 6) Create Book, BookApplication & BookRestController classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

    public class Book {
        
    private String title;
    private String author;
    private String genre;
        
    public Book(String title, String author, String genre) {
        this.title = title;
        this.author = author;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Book [title=" + title + ", author=" + author + ", genre="
                + genre + "]";
    }
    
}
   </div>
        </pre>
        
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class BookApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookApplication.class, args);
    }
}
   </div>
        </pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookRestController {
    
    List&lt;Book> books = new ArrayList&lt;>();
        
    public BookRestController() {
        books.add(new Book("The Silence of the Lambs", "Thomas Harris", "Thriller"));
        books.add(new Book("Murder on the Orient Express", "Agatha Christie", "Thriller"));
        books.add(new Book("A Midsummer Night's Dream", "William Shakespeare", "Comedy"));
    }

    @GetMapping("/{id}") 
    public Book get(@PathVariable("id") int id) {
        return books.get(id);
    }
}
   </div>
        </pre>        
        <br>
 
<h4>Step 7) Create application.properties file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
spring.application.name=book-service
eureka.client.serviceUrl.defaultZone=http://localhost:8761/eureka/
    </div>
    </pre>     
   <br>    
   
       <h4>Step 8) Create pom.xml file as mentioned in Step # 5 to create BookAdvisorService as second microservice and as Eureka Client.
Just update the artifactId in the pom.xml to below  </h4>
        <div id="code">
        <pre class="prettyprint">
&lt;groupId&gt;com.example&lt;/groupId&gt;
&lt;artifactId&gt;book-advisor-service&lt;/artifactId&gt;
&lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
&lt;packaging&gt;jar&lt;/packaging&gt;
        </div>
        </pre>        
        
        <br>
        
<h4>Step 9) Create BookAdvisorApplication & BookAdvisorRestController classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookAdvisorApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookAdvisorApplication.class, args);
    }
}

   </div>
    </pre>        

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class BookAdvisorRestController {

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/book-advisor/{id}")
    public ResponseEntity&lt;?> getBook(@PathVariable String id) {
        return restTemplate.getForEntity("http://book-service/"+id, String.class);
    }
        
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
   </div>
    </pre>            
    <br>

<h4>Step 10) Create application.properties file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
server.port=8084
eureka.client.serviceUrl.defaultZone=http://localhost:8761/eureka/
spring.application.name=book-advisor
    </div>
    </pre>     
   <br>  
   
    <h4>Step 11) Launch BookApplication & BookAdvisorApplication and open <a href="http://localhost:8084/book-advisor/1" target="_blank">
    http://localhost:8084/book-advisor/1</a> in the browser.</h4>
    <p>Note that <b><i>BookAdvisorRestController</b></i> internally calls <b><i>http://book-service/1</b></i> and 
    not<b><i> http://localhost:8080/1</b></i>. This means <b><i>BookService</b></i> instance was fetched from <b><i>Eureka Servie Registry</b></i>
    and then it was invoked.</p>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/eureka_3.jpg" alt="Maven Build" style="width:800px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
    <br>   
    
    <h4>Step 12) Also refresh <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a> in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/eureka_4.jpg" alt="Maven Build" style="width:800px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
<br>   
        
    References : <br><br>
    <a href="https://spring.io/guides/gs/service-registration-and-discovery/">Spring Service Registration and Discovery</a>    <br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>