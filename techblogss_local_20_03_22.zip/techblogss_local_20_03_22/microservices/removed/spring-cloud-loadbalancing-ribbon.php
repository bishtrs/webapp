    <?php include("../header.htm");?>

    <head>
        <title>Spring Cloud Load Balancing using Ribbon</title>
        <meta name="description" content="Spring Cloud Load Balancing using Ribbon, Microservices Load Balancing with Ribbon" />
        <link rel="canonical" href="https://www.techblogss.com/microservices/spring-cloud-loadbalancing-ribbon" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Cloud Load Balancing using Ribbon</h1>
        </div>
        <div id="solution">
            <p>
            <code>Spring Cloud Netflix Ribbon</code> provides <code>client-side load-balancing</code> of service calls from a service consumer. 
            which makes it possible for a client to continue making service calls even if the service discovery agent is temporarily unavailable.
            With the <code>Ribbon load balancer</code> in the client side, you can control its load balancing algorithm.
            </p>
            
			<p>
            Below example shows how to use <code>client-side load-balancing</code> using Spring Boot <code>microservices</code>
            using <code>Spring Cloud Netflix Ribbon library.</code>
            </p>
            
            <p>
            We will create two <code>microservices</code> named <code>MovieService</code> and <code>MovieClient</code> 
            & launch two instances of <code>MovieService</code>. <code>MovieClient</code> microservice will call
            <code>MovieService</code> microservice through Ribbon load balancer.
            </p>    
        </div>
        
        <div>
            <img src="../images/microservices/ribbon_1.jpg" alt="Maven Build" style="width:600px;height:400px;">
        
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>
        
        <h4>Step 1) Add below dependency in pom.xml to create MovieService Spring Boot application </h4>
        
        <div id="code">
        <pre class="prettyprint">
    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.boot&lt;/groupId>
            &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
        &lt;/dependency>
     &lt;/dependencies></pre></div><br>

    <div id="1">
    <h4>Step 2) Create Movie, MovieRestController, MovieServiceApplication classes to create MovieService microservice </h4>
    <div id="code">
    <pre class="prettyprint">
package com.example;

    public class Movie {

    private String title;
    private String genre;

    public Movie(String title, String genre) {
        this.title = title;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Movie [title=" + title + ", genre=" + genre + "]";
    }

}  </div></pre>

<div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MovieServiceApplication.class, args);
    }

}  </div> </pre>	

<div id="code">
    <pre class="prettyprint">
package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MovieRestController {
	
    @RequestMapping(value = "/movies") // http://localhost:8090/movies
    public List&lt;Movie> listAll() {

        List&lt;Movie> movies = new ArrayList<>();
        movies.add(new Movie("Lord of the Rings", "Fantasy"));
        movies.add(new Movie("The Specialist", "Thriller"));
        System.out.println("returning list of movies " + movies);
        return movies;
    }

}  </div></pre><br>
    
<h4>Step 3) Create application.yml file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
spring:
  application:
    name: movie-service

server:
  port: 8090
    </div>
    </pre>	

    </div>    

 <br>
<h4>Step 4) Build the above project, go to the directory where movie-service-0.0.1-SNAPSHOT.jar is generated & launch two instances 
of MovieServiceApplication using below commands</h4>
<p>java  -Dserver.port=8090 -jar movie-service-0.0.1-SNAPSHOT.jar</p>
<p>java  -Dserver.port=9092 -jar movie-service-0.0.1-SNAPSHOT.jar</p>


<div id="solution">Open <a href="http://localhost:8090/movies" target="_blank">http://localhost:8090/movies</a> & 
<a href="http://localhost:9092/movies" target="_blank">http://localhost:9092/movies</a> in the browser.</div><br>
    <p>You will see below pages displayed in the broswer.</p>
    
        <div>
            <img src="../images/microservices/ribbon_2.jpg" alt="Ribbon" style="width:380px;height:300px;">
            <img src="../images/microservices/ribbon_3.jpg" alt="Ribbon" style="width:380px;height:300px;">
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>    
    
    <h4>Step 5) Create pom.xml file as below to create MovieClient</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?>
    &lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    &lt;modelVersion>4.0.0&lt;/modelVersion>

    &lt;groupId>com.example&lt;/groupId>
    &lt;artifactId>movie-client&lt;/artifactId>
    &lt;version>0.0.1-SNAPSHOT&lt;/version>
    &lt;packaging>jar&lt;/packaging>

    &lt;name>movie-client&lt;/name>
    &lt;description>Demo project for Spring Boot&lt;/description>

    &lt;parent>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
        &lt;version>2.1.6.RELEASE&lt;/version>
        &lt;relativePath /> &lt;!-- lookup parent from repository -->
    &lt;/parent>

    &lt;properties>
        &lt;java.version>1.8&lt;/java.version>
    &lt;/properties>

    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-starter-netflix-ribbon&lt;/artifactId>
        &lt;/dependency>
        &lt;dependency>
            &lt;groupId>org.springframework.boot&lt;/groupId>
            &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
        &lt;/dependency>

    &lt;/dependencies>
	
    &lt;dependencyManagement>
    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
            &lt;version>Greenwich.SR3&lt;/version>
            &lt;type>pom&lt;/type>
            &lt;scope>import&lt;/scope>
        &lt;/dependency>
    &lt;/dependencies>
    &lt;/dependencyManagement>

    &lt;build>
        &lt;plugins>
            &lt;plugin>
                &lt;groupId>org.springframework.boot&lt;/groupId>
                &lt;artifactId>spring-boot-maven-plugin&lt;/artifactId>
            &lt;/plugin>
        &lt;/plugins>
    &lt;/build>


&lt;/project>
       </pre>	  </div>
           
        
        <br>
        
         <h4>Step 6) Create MovieClientApplication, MovieClientConfiguration classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@RestController
@RibbonClient(name = "movie-client", configuration = MovieClientConfiguration.class)
public class MovieClientApplication { 

    @LoadBalanced
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/allMovies") 
    public String getMovieList() {
        return this.restTemplate.getForObject("http://movie-service/movies", String.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(MovieClientApplication.class, args);
    }

}
   </pre> </div>
       
        
<div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AvailabilityFilteringRule;
import com.netflix.loadbalancer.IPing;
import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.PingUrl;

public class MovieClientConfiguration {

    @Autowired
    IClientConfig ribbonClientConfig;

    @Bean
    public IPing ribbonPing(IClientConfig config) {
        return new PingUrl();
    }

    @Bean
    public IRule ribbonRule(IClientConfig config) {
        return new AvailabilityFilteringRule();
    }

}    </pre> </div><br>
 
<h4>Step 7) Create application.properties file under src/main/resources to configure load-balanced Ribbon configuration.</h4>
 <p>This configures properties for a <b><i>Ribbon client</b></i>. Spring Cloud Netflix creates an ApplicationContext for each <b><i>Ribbon 
 client</b></i> name in our application. This is used to give the client a set of beans for instances of Ribbon components.</p>
    <div id="code">
    <pre class="prettyprint">
spring:
  application:
    name: movie-client

movie-service:
  ribbon:
    eureka:
      enabled: false
    listOfServers: localhost:8090,localhost:9092,localhost:9999
    ServerListRefreshInterval: 15000    </pre></div> <br>    
   
    <div id="solution">
        <h4>Step 8) Launch MovieClientApplication open <a href="http://localhost:8080/allMovies" target="_blank">
        http://localhost:8080/allMovies</a> in the browser.</h4>
        Note that <b><i>MovieClientApplication</b></i> internally calls <b><i>http://movie-service/movies</b></i>.
        If you refresh <a href="http://localhost:8080/allMovies" target="_blank">http://localhost:8080/allMovies</a> multiple times, 
        observe the logging in <b><i>MovieServiceApplication</b></i>, you will see the two instances are called on round-robin basis.
    </div>
        <br>
        <div>
            <p><img src="../images/microservices/ribbon_4.jpg" alt="Maven Build" style="width:400px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br>  
         
    References : <br><br>
    <a href="https://spring.io/guides/gs/client-side-load-balancing/">Spring Client side Load Balancing with Ribbon</a>	<br><br>
    <a href="https://github.com/Netflix/ribbon/wiki">Ntflix Ribbon Wiki</a>	<br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
    <div id="content">
    <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>