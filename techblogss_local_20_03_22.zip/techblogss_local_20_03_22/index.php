<?php header_remove("X-Powered-By"); ?>

<?php include("header.htm");?>

<head>
    <title>Technical Blogs for problems that developers encounter</title>
	<meta name="description" content="Solutions to technical problems that developers encounter, for e.g Java, Spring Boot problems" />
    <link rel="canonical" href="https://www.techblogss.com">
</head>

<body>
   	<?php include("navigation.htm");?>
    
	<div id="title">
		<div id="topic" class="topic">
		<div style='background-color:#159414;color:white'><h3>Core Java</h3></div>
		<ul id="problems">
            <li><a href="java/java-autoboxing-unboxing" target="_blank">Autoboxing and unboxing</a></li>
            <li><a href="java/java_cj_equalshashcode" target="_blank">How to override equals and hashcode method ?</a></li>
            <li><a href="java/java-immutable-class" target="_blank">How to create an immutable class ?</a></li>
            <li><a href="java/java-checked-unchecked-exception" target="_blank">Checked and unchecked Exception </a></li>
            <li><a href="java/java_trycatchmultiple" target="_blank">Exception handling in Java</a></li>
            <li><a href="java/java-autocloseable-try-with-resources" target="_blank">Try with resources example</a></li>
            <!-- Java custom annotation example -->
            <!-- Java reflection invoke method -->
            <!-- How to write custom ClassLoader in Java -->
            <li><a href="java/java_cj_measureelapsedtime" target="_blank">How to measure elapsed time in Java ?</a></li>
            <li><a href="java/java-enums" target="_blank">How to create and use Java Enums ?</a></li>
            <li><a href="java/java-custom-annotation" target="_blank">How to write custom annotation ?</a></li>
            <li><a href="designpatterns/singleton-design-pattern" target="_blank">Singleton Design Pattern</a></li>
            <li><a href="designpatterns/builder-design-pattern" target="_blank">Builder Design Pattern</a></li>
            <!-- How to break Singleton pattern in Java -->
            <!-- Java WatchService, Java WatchService example -->
            <!-- Java iterate files in directory recursively -->
            <!-- observer design pattern in java -->
		</ul>
		
		<div style='background-color:#159414;color:white'><h3>Collections</h3></div>
		<ul id="problems">
			<li><a href="java/java-iterate-hashmap" target="_blank">How to iterate through a HashMap ?</a></li>
			<li><a href="java/java_removeitemmap" target="_blank">How to remove an item from HashMap ?</a></li>
            <li><a href="java/java_removeitemlist" target="_blank">How to remove an item from ArrayList ?</a></li> 
			<li><a href="java/java-sort-arraylist" target="_blank">How to sort an ArrayList ?</a></li>
            <li><a href="java/java_arraytolist" target="_blank">Convert Array to List and vice versa</a></li>
            <!--TBD <li><a href="java/java-copyonwritearraylist" target="_blank">Copyonwritearraylist example</a></li> java copyonwritearraylist, copyonwritearraylist in java-->
		 </ul>
        
        <div style='background-color:#159414;color:white'><h3>MultiThreading and Concurrency</h3></div>
		<ul id="problems">
            <li><a href="java/java-acquire-lock" target="_blank">Acquire Lock in Java</a></li>
			<li><a href="java/java-thread-synchronization" target="_blank">Thread synchronization in Java</a></li>
            <li><a href="java/java-executor" target="_blank">Executor and ExecutorService example</a></li>
			<li><a href="java/java_threads_threadlocal" target="_blank">Java ThreadLocal example</a></li>
            <li><a href="java/java_threads_futuretask" target="_blank">Java FutureTask example</a></li>
            <li><a href="java/java-countdownlatch" target="_blank">CountDownLatch example</a></li>
			<li><a href="java/java-cyclicbarrier" target="_blank">CyclicBarrier example</a></li>
            <!-- TBD Consumer producer using blockingqueue-->
            <!-- TBD deadlock in java multithreading, deadlock vs livelock -->
		</ul>
            
		<div style='background-color:#159414;color:white'><h3>XML Parsing</h3></div>
		<ul id="problems">
			<li><a href="java/java_domparser" target="_blank">Parse XML in Java using DOM parser</a></li>
            <li><a href="java/java_xml_domparser_createxml" target="_blank">Create XML in Java using DOM parser</a></li>
            <li><a href="java/java_xml_domparser_modifyxml" target="_blank">Modify XML in Java using DOM parser</a></li>
			<li><a href="java/java_xml_saxparser" target="_blank">Parse XML in Java using SAX parser</a></li>
			<li><a href="java/java_staxparser" target="_blank">How to parse XML using StAX parser ?</a></li>
			<li><a href="java/java_xml_jdomparser" target="_blank">How to parse XML using JDOM parser ?</a></li>
			<li><a href="java/java_dom4jparser" target="_blank">How to parse XML using DOM4J parser ?</a></li>
		</ul>
		<div style='background-color:#159414;color:white'><h3>JSON Parsing</h3></div>
		<ul id="problems">
			<li><a href="java/java_JSONToXML" target="_blank">How to convert JSON object to XML ?</a></li>
			<li><a href="java/java_parsejson" target="_blank">How to parse JSON in Java ?</a></li>
			<li><a href="java/java_parsejson_gson" target="_blank">How to parse JSON in Java using Gson ?</a></li>
            <li><a href="java/java_json_gsonreadwrite" target="_blank">Gson JsonReader and JsonWriter example</a></li>
            <li><a href="java/java-convert-json-to-object-jackson" target="_blank">JSON to Java Object using Jackson</a></li>
            <li><a href="java/java-json-schema-validation" target="_blank">JSON Schema validation in Java</a></li>
            <li><a href="java/java-jsonpath-example" target="_blank">JsonPath example</a></li>
            <!--<li><a href="java/java_parsejson">How to wrtie JSON to file in Java ?</a></li>-->
            <!--<li><a href="java/java_parsejson">Jackson annotations ?</a></li>-->    
        </ul>
        <!--
		<div style='background-color:#159414;color:white'><h3>Others</h3></div>
            <ul id="problems">-->
                <!-- Bubble sort algorithm Java -->                
                <!-- Selection sort algorithm Java -->  
                <!-- binary search in java using recursion -->
                <!-- Find height of binary tree Java -->  
                <!--  Preorder traversal of binary tree example -->
                <!-- find middle element in linked list java -->    
                <!--<li><a href="java/change-color-theme-eclipse" target="_blank">How to change color theme in eclipse ?</a></li>-->
                <!--<li><a href="java/java-cpu-usage" target="_blank">How to setup maven in windows ?</a></li>java cpu usage -->                
                <!--<li><a href="java/java-consume-webservice">How to consume restful webservice in Java?</a></li>-->
                <!-- Liskov Substitution Principle example in Java-->
                <!-- open closed principle -->
                <!-- How to read yaml file in java -->
                <!-- java lombock example -->               
        
        </div>
    </div>

	<div id="contentMain">
	
	    <div id="wrap">
		<p>Thec code solutions have been tested with Java 1.8 version. You can download the jdk from this link</p>
        <a href="https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html">Download JDK 8</a>
        <br><br><br><br><br><br><br><br><br><br><br><br>
         <!-- 
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script> -->
        <!-- Square -->
        <!--<ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-9752425248354304"
             data-ad-slot="6267994878"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>-->

        </div>
		
	</div>
    
    <?php include("sidebar/sidebarHomePage.htm"); ?>
</body>


<?php include("footer.htm");?>
	
</html>
