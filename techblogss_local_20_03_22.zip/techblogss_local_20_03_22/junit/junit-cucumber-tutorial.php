<?php include("../header.htm");?>

<head>
    <title>Cucumber Java tutorial</title>
    <meta name="description" content="Cucumber Java tutorial" />
    <link rel="canonical" href="https://www.techblogss.com/junit/junit-cucumber-tutorial" />
</head>

<body>
    <?php include("../navigation.htm");    ?>
       
    <div id="content">
    
    <div id="blog" style="float:left;">
    
    <div id="problem">
        <h1>Cucumber Java tutorial</h1>
    </div>
    
    <div id="solution">
        <p>
        <code>TDD</code> approach helps in testing the code, but it doesn't help in testing business or funtional scenarios.
        <code>BDD</code> (behavior-driven development) focuses on specific business features based on scenarios. It also helps in bridging gap between
        buisness, developers and testers because all agree to a common language in which <code>BDD</code> tests are written.
        </p>
        <p>
        In <code>BDD</code> test scenarios are written using Given/When/Then keywords and below format.<br><br> 
        <code>Given</code>in two numbers<br>
        <code>When</code> subtract one number from other<br>
        <code>Then</code> correct difference should br returned<br>
        </p>
        <p>
        <code>Cucumber</code> is a <code>BDD</code> testing framework. which uses <code>Gherkin</code> language to describes application scenarios. 
        In this tutorial we will show how to write a <code>BDD</code> test using <code>Cucumber</code>, <code>Java</code> and <code>JUnit</code>.
        </p>
    </div>
    
    <div id="solution">
        <h4>Step 1) Add below dependencies to pom.xml</h4>
    </div>
    
    <div id="code"> <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;info.cukes&lt;/groupId&gt;
    &lt;artifactId&gt;cucumber-java&lt;/artifactId&gt;
    &lt;version&gt;1.2.5&lt;/version&gt;
    &lt;scope>test&lt;/scope>
&lt;/dependency&gt;</pre>    </div>    
    
    <div id="code">    <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;info.cukes&lt;/groupId&gt;
    &lt;artifactId&gt;cucumber-junit&lt;/artifactId&gt;
    &lt;version&gt;1.2.5&lt;/version&gt;
    &lt;scope>test&lt;/scope>
&lt;/dependency&gt;    </pre>    </div><br>    
    
        
    <div id="solution">
        <h4>Step 2) Install Cucumber plugin for eclipse if using eclipse</h4>
        <p>Go to Help &rarr; Eclipse Marketplace and install <code>Cucumber</code> plugin</p>
    </div>
    
    <div id="solution">
        <h4>Step 3) Write Calculator Class to test</h4>
        <p>Write Calculator class which has subtract method that will be tested using <code>BDD</code> approach </p>
    </div>
    
    <div id="code">    <pre class="prettyprint">
public class Calculator {
    public int subtract(int a, int b) {
        return a-b;
    }
}    </pre></div><br>
    
    <div id="solution">
        <h4>Step 4) Write <code>calculator.feature</code> file under src/test/resources/features directory</h4>
    </div>
    
    <div id="code">    <pre class="prettyprint">
Feature: calculate subtraction of two numbers
   Pass two numbers and check difference

  Scenario: Check difference between numbers
    Given two numbers
    When subtract one number from other
    Then correct difference should br returned    </pre></div><br>
    
    <div id="solution">
        <h4>Step 5) Run feature file</h4>
        <p>Right click on <code>calculator.feature</code> file and run it as <code>Cucumber</code> feature. It will provide the skeleton of the test 
        methods as below</p>
    </div>

  <div id="code">    <pre class="prettyprint">
You can implement missing steps with the snippets below:

@Given("^two numbers$")
public void two_numbers() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^subtract one number from other$")
public void subtract_one_number_from_other() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^correct difference should br returned$")
public void correct_difference_should_br_returned() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}</pre></div>    <br> 

    <div id="solution">
        <h4>Step 6) Add test class that based on business logic in previous step</h4>
    </div>

  <div id="code">    <pre class="prettyprint">
import static org.junit.Assert.assertEquals;

import calculator.Calculator;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculatorStepDef {
    
    private int a;
    private int b;
    private int c;
    private Calculator calculator = new Calculator();  
    
    @Given("^two numbers$")
    public void two_numbers() {
        a = 10;
        b = 4;
    }

    @When("^subtract one number from other$")
    public void subtract_one_number_from_other() throws Throwable {
        c = calculator.subtract(a, b);
    }

    @Then("^correct difference should br returned$")
    public void correct_difference_should_br_returned() throws Throwable {
        assertEquals(6,c);
    }

}</pre></div>    <br> 

    <div id="solution">
        <h4>Step 7) Add CalculatorCucumberTest class that will run test cases of CalculatorStepDef</h4>
    </div>

  <div id="code">    <pre class="prettyprint">
import org.junit.runner.RunWith;
 

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
 
@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/features/calculator.feature",
glue = "stepDefinitions")
public class CalculatorCucumberTest {    
}</pre></div>    <br> 

    <div id="solution">
        <h4>Step 8) Run Cucumber tests CalculatorCucumberTest</h4>
    </div>

    <div id="code">    <pre class="prettyprint">
import org.junit.runner.RunWith;
 

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
 
@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/features/calculator.feature", 
    glue = "stepDefinitions")
public class CalculatorCucumberTest {    
}</pre></div>    <br> 

    <div id="solution">
        <h4>Output : </h4>
    </div>
<div id="code">    <pre class="prettyprint">    
1 Scenarios ([32m1 passed[0m)
3 Steps ([32m3 passed[0m)
0m0.220s </pre></div>    <br> 

    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?> 
    <br>
 
     </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>