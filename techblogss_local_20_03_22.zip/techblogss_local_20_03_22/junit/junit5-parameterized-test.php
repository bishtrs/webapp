<?php include("../header.htm"); ?>

<head>
    <title>JUnit 5 parameterized test example</title>
    <meta name="description" content="JUnit 5 parameterized test example" />
    <link rel="canonical" href="https://www.techblogss.com/junit/junit5-parameterized-test" />
</head>

<body>
    <?php include("../navigation.htm"); ?>
        
    <div id="content">
        <div id="blog">
        <div id="problem">
            <h2>JUnit 5 parameterized test example</h2>
        </div>

        <div id="solution">
        <p>
        Sometimes you need to run the same test with various sets of parameters, these are called <code>Parameterized tests</code>.
        The examples below show how to write <code>Parameterized JUnit 5</code> Tests.
        </p>
        
        <p>
        To run <code>Parameterized JUnit 5</code> Tests, you need to use <code>@ParameterizedTest</code> annotation, along with 
        <code>@ValueSource</code>, <code>@EnumSource</code> or <code>@CsvSource</code> annotation.
        </p>
       
        </div>
        
        <h4>1) Add below dependencies to pom.xml</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId>org.junit.jupiter&lt;/groupId>
    &lt;artifactId>junit-jupiter-params&lt;/artifactId>
    &lt;version>5.8.1&lt;/version>
    &lt;scope>test&lt;/scope>
&lt;/dependency&gt;</pre></div><br>
        
        <h4>2) Write Parameterized JUnit 5 test using <code>@ParameterizedTest</code> & <code>@ValueSource</code> annotations</h4>
        <p>
        <code>@ValueSource</code> annotation allows to pass values using single dimensional array, whose elements can be used for testing one by one.
        </p>
   
        <div id="code">
        <pre class="prettyprint">
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class JUnit5ParameterizedTest {

    @ParameterizedTest
    @ValueSource(ints = { 2, 1, 5 })
    public void testArraySize(int num) {
        assertTrue(num > 0);
    }

    @ParameterizedTest
    @ValueSource(strings = { "i love junit5", "test using junit5" })
    void testWordsInSentence(String str) {
        assertNotNull(str);
        assertEquals(3, str.split(" ").length);
    }
}</div></pre><br>
        
        <h4>2) Write Parameterized JUnit 5 test using <code>@ParameterizedTest</code> & <code>@EnumSource</code> annotations</h4>
        <p>
        <code>@EnumSource</code> annotation allows to pass values as Enum.
        </p>
   
        <div id="code">
        <pre class="prettyprint">
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.EnumSource.Mode;

public class JUnit5ParameterizedTest {

    @ParameterizedTest
    @EnumSource(value = Colors.class)
    void testAllColorsLength(Colors colors) {
        assertTrue(colors.value().length() > 0);
    }

    @ParameterizedTest
    @EnumSource(value = Colors.class, names = { "GREEN", "BLUE" })
    void testFewColorsLength(Colors colors) {
        assertTrue(colors.value().length() > 0);
    }

    @ParameterizedTest
    @EnumSource(value = Colors.class, mode = Mode.EXCLUDE, names = { "GREEN", "BLUE" })
    void testYellowColorLength(Colors colors) {
        assertEquals("Yellow", colors.value());
    }
}</div></pre><br>

        <h4>3) Write Parameterized JUnit 5 test using <code>@ParameterizedTest</code> & <code>@CsvSource</code> annotations</h4>
        <p>
        <code>@CsvSource</code> annotation allows to pass values seperated by comma.
        </p>
   
        <div id="code">
        <pre class="prettyprint">
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class JUnit5ParameterizedTest {

    @ParameterizedTest
    @CsvSource({ "3, i love junit5", "2, junit5 tests" })
    void testWordsInASentence(int expected, String str) {
        assertNotNull(str);
        assertEquals(expected, str.split(" ").length);
    }
}</div></pre><br>

        <h4>4) Write Parameterized JUnit 5 test using <code>@ParameterizedTest</code> & <code>@CsvFileSource</code> annotations</h4>
        <p>
        <code>@CsvFileSource</code> annotation allows to pass values using csv file. You can keep test.csv file under /test/resource folder.
        </p>
   
        <div id="code">
        <pre class="prettyprint">
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

public class JUnit5ParameterizedTest {

    @ParameterizedTest
    @CsvFileSource(resources = "/test.csv")
    void testNumberOfWordsInASentence(int expected, String str) {
        assertNotNull(str);
        assertEquals(expected, str.split(" ").length);
    }
}</div></pre><br>

    
    References : <br><br>
    <a href="https://junit.org/junit5/docs/5.3.0/api/org/junit/jupiter/params/ParameterizedTest.html">ParameterizedTest (JUnit 5.3.0 API)</a>    <br><br>
                      
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>

    </div> <!-- content div -->
        
    <div id="content">
            <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
</html>