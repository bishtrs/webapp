<?php include("../header.htm"); ?>
<head>    <title>JUnit 5 Disable Test</title>    <meta name="description" content="JUnit 5 Disable Test" />    <link rel="canonical" href="https://www.techblogss.com/junit/junit5-disable-test" /></head>
<body>    <?php include("../navigation.htm"); ?>    
    <div id="content">        <div id="blog">        <div id="problem">            <h2>JUnit 5 Disable Tests</h2>        </div>
        <div id="solution">            <p>            Sometimes you may want to skip or disable a <code>JUnit</code> test, this can be done using <code>@Disabled</code> annotation.             <code>@Disabled</code> annotation accepts the value parameter, in which you can provide the message why you skipped this test            </p>        </div>                <h3>Disable an individual JUnit test using <code>@Disabled</code> annotation</h3>          <div id="code"><pre class="prettyprint">public class User {    private String name;    public User(String name) {        this.name = name;    }    public String getName() {        return this.name;    }}</pre></div><br>                <div id="code"><pre class="prettyprint">import org.junit.jupiter.api.Disabled;public class UserTest {    @Disabled (value = "skipping this test for now")    public void testUserNameIsNotNull() {        User user = new User("Nicolas Cage");        assertNotNull(user);    }        @Test    public void testUserNameIsNotEmpty() {        User user = new User("Nicolas Cage");        assertTrue(user.getName().length() > 0);    }}   </pre></div><br>        <div id="solution">            <h3>Disable all JUnit tests using <code>@Disabled</code> annotation</h3>              <p>            You can also disable all JUnit tests by using <code>@Disabled</code> annotation at Class level as shown below.            </p>        </div>                <div id="code"><pre class="prettyprint">@Disabled(value = "skipping all tests for now")public class UserTest {        // Junits }</pre></div><br>    
    </div> <!-- blog div-->
    <?php include("../sidebar/sidebar.htm"); ?>
    </div> <!-- content div -->
    <div id="content">        <?php include '../blogs/entry.php';?>    </div>
    <?php include("share.htm"); ?>
    </body>
    <?php include("footer.htm");?>
</html>