<html>
  <head>
    <style>
    body 
    {box-sizing: border-box;}

    input[type=text], select, textarea {
      width: 70%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      margin-top: 6px;
      margin-bottom: 16px;
      resize: vertical;
    }
    
    input[type=email], select, textarea {
      width: 70%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      margin-top: 6px;
      margin-bottom: 16px;
      resize: vertical;
    }

    input[type=submit] {
      background-color: #4CAF50;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=submit]:hover {
      background-color: #45a049;
    }

    .container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
    </style>
    <title>Comments</title>
    <!--<script src='https://www.google.com/recaptcha/api.js' async defer></script>-->
    
    <script> 
    function validateForm() {
        var x = document.forms["contact_form"]["name"].value;
        if (x == null || x == "") {
            alert("Please enter your name", "error");
        return false;
    }
    }    
    </script>    
  </head>
  <body>
    <h2>Leave a Reply</h2>
    <p>Your email address will not be published. Required fields are marked *</p>
    <form id="contact_form" action="../blogs/form.php" method="post" onsubmit="return validateForm();">
      <label>Comment</label><br>
      <textarea name="comment" placeholder="Type your message"  rows="8" cols="39" required></textarea><br>
      
      <label>Name*</label><br>
      <input type="text" name="name" placeholder="Type your name" size="40" required><br><br>
      
      <label>Email*</label><br>
      <input type="email" name="email" placeholder="Type your email" size="40" required><br><br>
      
      <input type="submit" name="submit" value="Post Comment"><br><br>
      <!--<div class="g-recaptcha" data-sitekey="6LchIrEUAAAAAFe9hQyQZvFckxEvQaKGxi0epArT"></div>-->
    </form>
  </body>
</html>
<!--
<form action='' method='post'>

    <p><label>Comments</label><br />
    <textarea name='postCont' cols='100' rows='10'><?php if(isset($error)){ echo $_POST['postCont'];}?></textarea></p>

    <p><label>Name</label><br />
    <input type='text' name='postTitle' value='<?php if(isset($error)){ echo $_POST['postTitle'];}?>'></p>

    <p><label>Email</label><br />
    <input type='text' name='postTitle' value='<?php if(isset($error)){ echo $_POST['postTitle'];}?>'></p>

    
    <p><input type='submit' name='submit' value='Post Comments'></p>

</form>-->