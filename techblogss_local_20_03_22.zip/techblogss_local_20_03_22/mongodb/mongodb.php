<?php 
    include("header.htm");
?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="Solutions to problems in MongoDB" />
    <link rel="canonical" href="https://www.techblogss.com/mongodb/mongodb">
    <meta name="robots" content="noindex">
</head>

<body>
    <?php include("navigation.htm");?>
	
	<div id="title">
		<div id="topic" class="topic">
		
		<div style='background-color:#159414;color:white'><h3>MongoDB</h3></div>
            <ul id="problems">
                <li><a href="create-drop-mongodb-collection" target="_blank">Create & Drop Collection</a></li>
                <li><a href="create-drop-mongodb-database" target="_blank">Create & Drop Database</a></li>
            </ul>
        </div>
		
	</div>
	

	<div id="contentMain">
		<div id="wrap">
            <h2>MongoDB Tutorials</h2>
            <p>MongoDB is a powerful, flexible, and scalable general-purpose database. MongoDB is a cross-platform document-oriented database and is
            classified as a NoSQL database, MongoDB uses JSON-like documents with schema. MongoDB is developed by MongoDB Inc.<br><br>
            This page provides MongoDB tutorials for software programmers who want to learn MongoDB from scratch.
            Please click on the topic on left to see details. The code solutions have been tested with <b><i>MongoDB 3.2</b></i>. <br><br>
            <?php include("share.htm"); ?>
            </div>
	</div>
    
            <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>

	
</body>

<?php include("footer.htm");?>

</html>
