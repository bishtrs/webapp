<?php 
    include("header.htm");
?>

<head>
    <title>How to create & drop MongoDB Collection</title>
	<meta name="description" content="Create & Drop MongoDB Collection" />
	<link rel="canonical" href="https://www.techblogss.com/mongodb/create-drop-mongodb-collection" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to create & drop MongoDB Collection</h1>
	</div>
    
	<div id="solution">
		
        <p>
            A <b><i>collections</b></i> is a group of documents. If a document is the MongoDB analog of a row in a relational database, then a <b><i>collections</b></i> 
            can be thought of as the analog to a table.
        </p>
        
        <p>
            <b><i>Collections</b></i> have dynamic schemas. This means that the documents within a single <b><i>collection</b></i> can have any number of different
            keys/values. For example, both of the following documents could be stored in a single <b><i>collection</b></i>. So to keep same type of data together,
            we should use <b><i>Collections</b></i>.
        </p>
<pre class="prettyprint">
{"bar" : "Hello, world!"}
{"foo" : 5, "bar" : "hello" }
</pre>
        <br>

        <h2>1. Create MongoDB Collection</h2>

        <p>
            To create a students <b><i>collection</b></i>, you can use createCollection(name, options) method, where name is the name of the collection and
            options is provided to specify memory size & indexing information.
        </p>
       
<pre class="prettyprint">>  db.createCollection("employees")
{ "ok" : 1 }
</pre>
        <p>
            To check if  employees <b><i>collection</b></i> is created, type show collections
        </p>
<pre class="prettyprint">> show collections
employees
system.indexes
</pre>
        
        <br>
        <h2>2. Create MongoDB Collection with options</h2>
		
        <p>
            You can create a <b><i>collection</b></i> with some options like capped, autoIndexId, size, max. To view complete list of options visit this page
        </p>
        <a href="https://docs.mongodb.com/manual/reference/method/db.createCollection/" target="_blank">https://docs.mongodb.com/manual/reference/method/db.createCollection/</a>
        <br><br>
<pre class="prettyprint">> db.createCollection("employees", { capped : true, size : 5242880, max : 5000 } )
{ "ok" : 1 }
</pre>
        <br>

        <h2>3. Creating default MongoDB Collection</h2>
		
        <p>
            Also note that in case you don't create a <b><i>collection</b></i> specifically and you simply insert data in a database, by default a <b><i>collection</b></i> 
            with same name as database will be created
        </p>

 <pre class="prettyprint">> db.employees.insert({"id":"1"})
WriteResult({ "nInserted" : 1 })
> show collections
employees
system.indexes
</pre>
        <br>

         <h2>4. Dropping MongoDB Collection</h2>
		
        <p>
            You can drop a MongoDB Collection using drop() method.
        </p>

 <pre class="prettyprint">> db.employees.drop()
true
> show collections
system.indexes
</pre>
    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
    References : <br><br>
    <a href="https://docs.mongodb.com/manual/reference/method/db.createCollection/" target="_blank">https://docs.mongodb.com/manual/reference/method/db.createCollection/</a>
	<br><br>
 
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>