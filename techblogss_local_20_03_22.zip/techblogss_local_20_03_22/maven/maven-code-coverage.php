<?php 
    include("header.htm");
?>

<head>
    <title>Run Spring Boot application in eclipse</title>
	<meta name="description" content="maven compiler plugin, maven compiler plugin dependency" />
	<link rel="canonical" href="https://www.techblogss.com/eclipse/run-spring-boot-application-in-eclipse" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h2>Run Spring Boot application in eclipse</h2>
	</div>
	<div id="solution">
        <p>This blog shows how to configure eclipse and run a basic spring boot application in eclipse IDE.</p> 
        First you need to download eclipse from eclipse site. If you need 32-bit installer, you can download from here
        <a href="https://www.eclipse.org/downloads/packages/release/helios/sr1/eclipse-ide-java-developers" target="_blank">
        https://www.eclipse.org/downloads/packages/release/helios/sr1/eclipse-ide-java-developers
        </a><br>
        Else if you need 64-bit installer, you can download from here
        <a href="https://www.eclipse.org/downloads/packages/" target="_blank">
        https://www.eclipse.org/downloads/packages/
        </a>
	</div>
    
    <h4>Step 1) Open the directory that contains eclipse </h4>
        <div>
            <p><img src="../images/eclipse/eclipse.jpg" alt="Eclipse" style="width:800px;height:500px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
    <div id="pom">    
    <h4>Step 1) Create pom.xml</h4>
    
    Create a pom.xml file as below and keep it in Java project directory. It contains Spring Boot starter maven dependencies.
	The <b><i>spring-boot-starter</b></i> will pull in all the dependencies needed to start a basic Spring Boot application.
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
	
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
	
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
	
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Demo project for Spring Boot&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;
    </pre>
	</div>
    </div>
    <br>
	
	 <h4>Step 2) Create DemoApplication class</h4>
     This Class prints number of beans provided by Spring Boot and also bean names.
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(DemoApplication.class, args);
			
        System.out.println("Number of beans --> " + ctx.getBeanDefinitionCount());
        String[] beanNames = ctx.getBeanDefinitionNames();
        for (String beanName : beanNames) {
            System.out.println("Bean --> "+ beanName);
        }
    }

}

 	</div>
	</pre>
    <br>

    <div id="1">
    <h4>Step 3) Building DemoApplication</h4>
    a) To build this Spring Boot application in eclipse, you can right click on DemoApplication project
    , select <b>Run as </b>&rarr; <b>Maven build </b>. In Goals provide <b>clean install</b><br>
    
    
        <p><img src="../images/sb_maven.jpg" alt="Maven Build" style="width:600px;height:400px;"></p>
    </div>
    
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    b) To build this Spring Boot application from command prompt, use following command &rarr; <b>mvn clean install</b>.
    
    <br>
    <div id="2">
    <h4>Step 4) Running DemoApplication</h4>
    a) To Run this Spring Boot application in eclipse, you can right click on DemoApplication class
    , select <b>Run as </b>&rarr; <b>Java Application</b><br><br>
    b) To Run this Spring Boot application from command prompt, use following command &rarr; <b>java -jar demo-0.0.1-SNAPSHOT.jar</b></h4>
    </div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.6.RELEASE)

2019-08-04 13:22:28.018  INFO 3480 --- [           main] com.example.demo.DemoApplication         : Starting DemoApplication on ssss-PC with PID 3480 (C:\Dev\eclipse\workspace\SpringBoot\target\classes started by sss in C:\Dev\eclipse\workspace\SpringBoot)
2019-08-04 13:22:28.018  INFO 3480 --- [           main] com.example.demo.DemoApplication         : No active profile set, falling back to default profiles: default
2019-08-04 13:22:29.641  INFO 3480 --- [           main] com.example.demo.DemoApplication         : Started DemoApplication in 3.168 seconds (JVM running for 3.961)
Number of beans --> 27
Bean --> org.springframework.context.annotation.internalConfigurationAnnotationProcessor
Bean --> org.springframework.context.annotation.internalAutowiredAnnotationProcessor
Bean --> org.springframework.context.annotation.internalCommonAnnotationProcessor
Bean --> org.springframework.context.event.internalEventListenerProcessor
Bean --> org.springframework.context.event.internalEventListenerFactory
Bean --> demoApplication
Bean --> org.springframework.boot.autoconfigure.internalCachingMetadataReaderFactory
Bean --> org.springframework.boot.autoconfigure.AutoConfigurationPackages
Bean --> org.springframework.boot.autoconfigure.context.PropertyPlaceholderAutoConfiguration
Bean --> org.springframework.boot.autoconfigure.condition.BeanTypeRegistry
Bean --> propertySourcesPlaceholderConfigurer
Bean --> org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration
Bean --> mbeanExporter
Bean --> objectNamingStrategy
Bean --> mbeanServer
Bean --> org.springframework.boot.autoconfigure.context.ConfigurationPropertiesAutoConfiguration
Bean --> org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor
Bean --> org.springframework.boot.context.properties.ConfigurationBeanFactoryMetadata
Bean --> org.springframework.boot.autoconfigure.info.ProjectInfoAutoConfiguration
Bean --> spring.info-org.springframework.boot.autoconfigure.info.ProjectInfoProperties
Bean --> org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration
Bean --> taskExecutorBuilder
Bean --> applicationTaskExecutor
Bean --> spring.task.execution-org.springframework.boot.autoconfigure.task.TaskExecutionProperties
Bean --> org.springframework.boot.autoconfigure.task.TaskSchedulingAutoConfiguration
Bean --> taskSchedulerBuilder
Bean --> spring.task.scheduling-org.springframework.boot.autoconfigure.task.TaskSchedulingProperties
		</pre>
	</div>		
	<div id="comments">
	</div>


	
References : <br><br>
<a href="https://docs.spring.io/spring-boot/docs/current/reference/html/getting-started-first-application.html">Spring Boot First Application</a>	<br><br>
	</div>
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
</body>

<?php 
    include("footer.htm");
?>
</html>