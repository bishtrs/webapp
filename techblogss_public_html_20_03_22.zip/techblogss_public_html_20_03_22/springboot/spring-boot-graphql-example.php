<?php include("../header.htm");?>

<head>
    <title>Spring Boot GraphQL tutorial</title>
    <meta name="description" content="Spring Boot GraphQL tutorial" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-graphql-example" />
</head>

<body>
    <?php include("../navigation.htm"); ?>
        
    <div id="content">
    <div id="blog">
        <div id="problem">
            <h1>Spring Boot GraphQL tutorial</h1>
        </div>
        <div id="solution">
            <p>
            When a request is made to a <code>REST</code> service, it sends data for only that service with all the fields. But what if only a 
            subset of data is required in the response or response should contain multiple resource data ? For example if request is made to get
            User and we want only subset of data along with User Address, then we can make a <code>GraphQL</code> query.
            </p>
            <p>
            A <code>GraphQL</code> query will select only the fields required in the response and also save multiple REST calls to a service.           
            This tutorial shows how to query an API using <code>Spring Boot</code> & <code>GraphQL</code>.
            </p> 
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.springframework.boot&lt;/groupId>
    &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
&lt;/dependency>
&lt;dependency>
    &lt;groupId>com.graphql-java&lt;/groupId>
    &lt;artifactId>graphql-spring-boot-starter&lt;/artifactId>
    &lt;version>5.0.2&lt;/version>
&lt;/dependency>
&lt;dependency>
    &lt;groupId>com.graphql-java&lt;/groupId>
    &lt;artifactId>graphql-java-tools&lt;/artifactId>
    &lt;version>5.2.4&lt;/version>
    &lt;/dependency>
&lt;dependency>
    &lt;groupId>com.graphql-java&lt;/groupId>
    &lt;artifactId>graphiql-spring-boot-starter&lt;/artifactId>
    &lt;version>5.0.2&lt;/version>
&lt;/dependency>       </pre></div><br>
        
        <h4>Step 2) Create User POJO, UserRepository and UserService classes</h4>
       
        <p>
        UserService will make call to UserRepository class and get users details.
        </p>
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.io.Serializable;

public class User implements Serializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String email;
    private String firstName;
    private String lastName;

    // removed getter and setters

}</pre></div> <br>

        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Repository;

@Repository()
public class UserRepository {

    private Map&lt;Integer, User> users = new HashMap&lt;>();
    
    
    public Collection&lt;User> findAll() {
        return users.values();
    }

    public Optional&lt;User> findUser(Integer userId) {
        return Optional.ofNullable(users.get(userId));
    }

    public User addUser(int id, User user) {
        users.put(id, user);
        return user;
    }

    public void deleteItem(Integer id) {
        users.remove(id);
    }

    public void updateUser(Integer id, User user) {
        users.put(id, user);
    }
}</pre></div> <br>

<div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User createUser(final int id, final String email, 
        final String firstName, final String lastName) {
        return userRepository.addUser(id, new User(id, "harry@hotmail.com", "Harry", "Potter"));
    }

    public List&lt;User> getAllUsers(final int count) {
        return userRepository.findAll().stream().limit(count).collect(Collectors.toList());
    }

    public Optional&lt;User> getUser(final Integer id) {
        return userRepository.findUser(id);
    }

}</pre></div> <br>

    <h4>Step 3) Create GraphQL schema file to query the API</h4>
    <p>
    Create a <code>GraphQL</code> schema file under <code>src/main/resources</code> folder which is written in SDL (Schema Definition Language). 
    It provides the schema that describes the APIs. Note that <code>GraphQL</code> schema can contain only one root Query & one Mutation.
    </p>
       
    <div id="code">
    <pre class="prettyprint">
type User {
    id: Int,
    email: String,
    firstName: String,
    lastName: String
}

type Query {
    users(count: Int):[User]
    user(id: String):User
}

type Mutation {
    createUser(id: Int!, email: String, firstName: String, lastName: String):User
}</div></pre><br>

    <h4>Step 4) Create GraphQLApplication, UserQuery, UserMutation, classes</h4>
           
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class GraphQLApplication {

    public static void main(String[] args) {
        SpringApplication.run(GraphQLApplication.class, args);
    }
    
    @Bean
    public ApplicationRunner userInitializer(UserRepository userRepository) {
        return args -> {
            userRepository.addUser(1, new User(1, "harry@hotmail.com", "Harry", "Potter"));
        };
    }
    
}</div></pre><br>
        
    <p>
    To handle the queries defined in <code>GraphQL</code> schema, we need to add Query & Mutation Resolvers. When a query is made, <code>UserQuery</code>
    will process it, while if want to add a record or make a mutation, it will be handled by <code>UserMutation</code>.
    </p>
    
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;

@Component
public class UserQuery implements GraphQLQueryResolver {

    @Autowired
    private UserService userService;

    public List&lt;User> getUsers(final int count) {
        return this.userService.getAllUsers(count);
    }

    public Optional&lt;User> getUser(final Integer id) {
        return this.userService.getUser(id);
    }
}    </div></pre><br>  

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;

@Component
public class UserMutation implements GraphQLMutationResolver {

    @Autowired
    private UserService userService;

    public User createUser(final int id, final String email, final String firstName,
        final String lastName) {
            return userService.createUser(id, email, firstName, lastName);
    }
}   </div></pre><br>        
        
     <h4>Step 5) Running GraphQLApplication </h4>
     <div>Run above GraphQLApplication, and launch <a href="http://localhost:8080/graphiql" target="_blank">http://localhost:8080/graphiql</a></div>
     <p>You will see GraphQL user interface where you can run queries. Run below queries and see result</p>
   
    <div id="code">
    <pre class="prettyprint">
query {
  users(count: 2) {
    id
    email
    firstName
    lastName
  }
}</div></pre> <br>
<p>Query Result</p>

<div id="code">
    <pre class="prettyprint">
{
  "data": {
    "users": [
      {
        "id": 1,
        "email": "harry@hotmail.com",
        "firstName": "Harry",
        "lastName": "Potter"
      }
    ]
  }
}</div></pre> <br>
    
    <div id="code">
    <pre class="prettyprint">
mutation {
  createUser(id: 2, email: "sfdsf@sdfsdf", firstName: "XYZ", lastName: "sdfd") {
    id
  }
}</div></pre> <br>

<p>Mutation Result</p>

<div id="code">
    <pre class="prettyprint">
{
  "data": {
    "createUser": {
      "id": 2
    }
  }
}</div></pre> <br><br>

    References : <br><br>
    <a href="https://www.howtographql.com/basics/2-core-concepts/">GraphQL core concepts</a>    <br><br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>