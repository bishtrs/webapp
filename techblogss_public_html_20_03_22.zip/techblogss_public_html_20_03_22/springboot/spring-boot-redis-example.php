<?php include("../header.htm");?>

<head>
    <title>Spring Boot Redis example</title>
    <meta name="description" content="Spring Boot Redis example" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-redis-example" />
</head>

<body>
    <?php include("../navigation.htm"); ?>
        
    <div id="content">
    <div id="blog">
        <div id="problem">
            <h1>Spring Boot Redis example</h1>
        </div>
        <div id="solution">
            <p>
            <code>Redis</code> is an in-memory open source data store which can be used as database, cache and as a message broker.
            <code>Redis</code> supports data structures such as strings, lists, hashes, sets, and sorted sets. The <code>Spring Data Redis</code> 
            provides framework to interact with <code>Redis</code> store and makes it easy to integrate Java applications with <code>Redis</code>.
            </p>
            <p>
            This example shows how to build a <b><i>Spring Boot Redis</b></i> application which will create, delete, update 
            data in Redis server.
            </p> 
        </div>
        
        <h4>Step 1) Install and run Redis server</h4>
        <div>
        Download <code>Redis</code> for windows from here <a href="https://github.com/tporadowski/redis/releases/" target="_blank">
        https://github.com/tporadowski/redis/releases/</a>
        </div>
        <p>
        After extracting <code>Redis</code>, run redis-server from the Redis directory "C:\Dev\Redis-x64-5.0.14".
        </p>
        
        <h4>Step 2) Add below dependencies in pom.xml</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.springframework.boot&lt;/groupId>
    &lt;artifactId>spring-boot-starter-data-redis&lt;/artifactId>
&lt;/dependency>
&lt;dependency>
    &lt;groupId>redis.clients&lt;/groupId>
    &lt;artifactId>jedis&lt;/artifactId>
&lt;/dependency>       </pre></div><br>
        
        <h4>Step 3) Create User, UserRepository classes</h4>
        <p>
        UserRepository will use <code>HashOperations</code> instance created by <code>RedisTemplate</code> to perfrom CRUD operations
        on redis server. We will use User as domain object.
        </p>
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.io.Serializable;

public class User implements Serializable {

    private String email;
    private String firstName;
    private String lastName;

    // constructor, getter, setter removed

    @Override
    public String toString() {
        return "User [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }
    
}</pre></div> <br>

        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

@Repository()
public class UserRepository {

    public static final String KEY = "USER";
    
    private HashOperations&lt;String, String, User> hashOperations;
    
    @Autowired
    public UserRepository(RedisTemplate&lt;String, String> redisTemplate) {
        hashOperations = redisTemplate.opsForHash();
    }
    
    JedisConnectionFactory jedisConnectionFactory() {
        return new JedisConnectionFactory();
    }
    
    public Map&lt;String, User> getAllItems() {
        return hashOperations.entries(KEY);
    }

    public User getUser(String itemId) {
        return hashOperations.get(KEY, itemId);
    }

    public void addUser(String id, User user) {
        hashOperations.put(KEY, id, user);
    }

    public void deleteItem(String id) {
        hashOperations.delete(KEY, id);
    }

    public void updateUser(String id, User user) {
        addUser(id, user);
    }
}</pre></div> <br>

    <h4>Step 4) Create RedisConfiguration, RedisApplication classes</h4>
    <p>
    By default Spring Boot Application will connect to Redis server on localhost 6379 port, but we can change it using <code>
    RedisStandaloneConfiguration</code> as shown in RedisConfiguration class. 
    </p>
    <p>
    There are two Redis connectors <code>Lettuce</code> and <code>Jedis</code> Connector. We will use <code>Jedis</code> Connector to connect to 
    Redis server.
    </p>
       
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class RedisConfiguration {
    
    @Bean
    JedisConnectionFactory jedisConnectionFactory() {
        RedisStandaloneConfiguration configuration = 
            new RedisStandaloneConfiguration("localhost", 6379);
        JedisConnectionFactory jedisConnectionFactory =
            new JedisConnectionFactory(configuration);
        return jedisConnectionFactory;
    }

    @Bean
    public RedisTemplate&lt;String, String> redisTemplate() {
        RedisTemplate&lt;String, String> redisTemplate  = new RedisTemplate&lt;>();
        redisTemplate.setConnectionFactory(jedisConnectionFactory());
        return redisTemplate;
    }

}</div></pre><br>
        
    
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RedisApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedisApplication.class, args);
    }
    
    @Bean
    public ApplicationRunner userInitializer(UserRepository userRepository) {
        return args -> {
            System.out.println("reading all items");
            System.out.println(userRepository.getAllItems());
            System.out.println("adding item");
            userRepository.addUser("1", new User("harry@hotmail.com", "Harry", "Potter"));
            System.out.println("reading item");
            System.out.println(userRepository.getUser("1"));
            userRepository.updateUser("1", new User("harry@gmail.com", "Harry", "Potter"));
            System.out.println(userRepository.getUser("1"));
        };
    }
    
}     </div></pre><br>        
        
     <h4>Step 5) Running RedisApplication </h4>
     <p>Run above RedisApplication, it will print below in console</p>
   
    <div id="code">
    <pre class="prettyprint">
reading all items
{1=User [email=harry@gmail.com, firstName=Harry, lastName=Potter]}
adding item
reading item
User [email=harry@hotmail.com, firstName=Harry, lastName=Potter]
User [email=harry@gmail.com, firstName=Harry, lastName=Potter]    </div></pre> <br><br>

    References : <br><br>
    <a href="https://docs.spring.io/spring-data/data-redis/docs/current/reference/html/#reference">Spring Data Redis</a>	<br><br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>