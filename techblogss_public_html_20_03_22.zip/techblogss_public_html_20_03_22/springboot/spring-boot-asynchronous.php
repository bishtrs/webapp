<?php include("../header.htm");?>

    <head>
        <title>Spring Boot Asynchronous Controller example</title>
        <meta name="description" content="Spring Boot Asynchronous controller example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-asynchronous" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Asynchronous Controller example</h1>
        </div>
        <div id="solution">
            <p>
            As of <b><i>Servlet 3</b></i>, it is possible to handle a <b><i>HTTP request asynchronously</b></i> by releasing the thread 
            that handles the <b><i>HTTP request</b></i>. This is useful when a call takes some time to send the response, so instead of 
            blocking the thread, you can do the processing in the background and return the data when the processing is done by another thread.
            </p>
            <p>
            Spring MVC supports following return types that are processed asynchronously : <b><i>DeferredResult&lt;V>, ListenableFuture&lt;V>,
            CompletionStage&lt;V>, CompletableFuture&lt;V>, Callable&lt;V>, ResponseBodyEmitter&lt;V>, SeeEmitter&lt;V>, StreamingResponseBody&lt;V>.
            </b></i>
            </p>
            
            <p>
            Below example shows how to send the response to a HTTP request asynchronously in a <b><i>Spring Boot MVC</b></i> application.
            </p> 
        </div>
        
        <h4>Step 1) Add below dependency in pom.xml</h4>
    <div id="code">
        <pre class="prettyprint">&lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
&lt;/dependency&gt;        </pre></div><br>
    
         <h4>Step 2) Create AynchronousControllerApplication class</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AynchronousControllerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AynchronousControllerApplication.class, args);
    }
}
        </div>
        </pre>
        <br>
        <h4>Step 3) Create AynchronousController class which will send reponse asynchronously using Callable</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.concurrent.Callable;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AynchronousController {

    @GetMapping()
    public Callable&lt;String> hello() {
        return () -> {
            Thread.sleep(2000); // simulate time consuming call
            return "Hello Aynchronous Controller";
        };
    }
}       </div></pre><br>

        <h4>Sending reponse asynchronously from the Controller using CompletableFuture</h4>
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.concurrent.CompletableFuture;

import org.springframework.core.task.TaskExecutor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AynchronousController {
    
    private final TaskExecutor taskExecutor; 
    
    public AynchronousController(TaskExecutor taskExecutor) {
        this.taskExecutor = taskExecutor;
    }

   @GetMapping()
    public CompletableFuture&lt;String> hello() {
        return CompletableFuture.supplyAsync(() -> {
            delay(2000); // simulate time consuming call
            return "Hello Aynchronous Controller";
        }, taskExecutor );
    }
    
    private void delay(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
    }
} </div></pre><br>

        <h4>Step 4) Running AynchronousControllerApplication</h4>
        
        <div id="solution">
            <h4>Console Output : </h4>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2020-01-18 10:55:31.320  INFO 4352 --- [main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.21]
2020-01-18 10:55:31.648  INFO 4352 --- [main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2020-01-18 10:55:31.648  INFO 4352 --- [main] o.s.web.context.ContextLoader            : Root WebApplicationContext: initialization completed in 8809 ms
2020-01-18 10:55:32.506  INFO 4352 --- [main] o.s.s.concurrent.ThreadPoolTaskExecutor  : Initializing ExecutorService 'applicationTaskExecutor'
2020-01-18 10:55:33.131  INFO 4352 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2020-01-18 10:55:33.131  INFO 4352 --- [main] c.e.d.AynchronousControllerApplication   : Started AynchronousControllerApplication in 12.524 seconds (JVM running for 13.742)           </pre></div>        <br>
    

     <h4>Step 5) Testing AynchronousControllerApplication </h4>
     <p>Open any browser and launch <b>http://localhost:8080</b>. You will see 'Hello Aynchronous Controller' message displayed in the broswer.</p><br>
     
        <div>
            <p><img src="../images/springboot/sb_asychronous_controller.jpg" alt="Maven Build" style="width:400px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br>
    
    <p>
    Note that in the logs below, a new thread <i>(nio-8080-exec-1)</i> is started in the backend to handle the request. Then another
    thread <i>(task-1)</i> did the actual processing and the reponse was submitted by another thread <i>(nio-8080-exec-4)</i> to the dispatcher servlet.
    </p>
   
    <div id="code">
    <pre class="prettyprint">   
2021-09-03 11:39:03.992 DEBUG 9284 --- [nio-8080-exec-1] o.apache.coyote.http11.Http11Processor   : Socket: Status in: [OPEN_READ], State out: [LONG]
2021-09-03 11:39:03.992 DEBUG 9284 --- [nio-8080-exec-1] o.apache.coyote.http11.Http11Processor   : State after async post processing: [LONG]
2021-09-03 11:39:05.999 DEBUG 9284 --- [task-1] o.s.w.c.request.async.WebAsyncManager : Async result set, dispatch to /
2021-09-03 11:39:06.000 DEBUG 9284 --- [task-1] o.apache.catalina.core.AsyncContextImpl : Req: 503167fb  CReq: 5ef6938d  
RP: 449c882f  Stage: 7  Thread:               task-1  State:                  N/A  Method: dispatch     URI: /
2021-09-03 11:39:06.219 DEBUG 9284 --- [nio-8080-exec-4] o.s.web.servlet.DispatcherServlet        : Completed 200 OK
</pre></div> 
        
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>