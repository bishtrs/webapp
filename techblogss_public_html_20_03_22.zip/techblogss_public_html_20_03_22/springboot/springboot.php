<?php include "../header.htm" ;?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="Solutions to problems in Spring Boot" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/springboot">
</head>

<body>
    <?php include("../navigation.htm");?>
	
    <!--
	<div id="title">
		<div id="topic" class="topic">
		<div style='background-color:#159414;color:white'><h3>Spring Boot</h3></div>
		<ul id="problems">
            <li><a href="spring-boot-print-all-beans" target="_blank">Display all beans</a></li>
            <li><a href="spring-boot-interceptor" target="_blank">Interceptor example</a></li>
            <li><a href="spring-boot-change-tomcat-port" target="_blank">How to change Tomcat Port</a></li>
            <li><a href="spring-boot-applicationrunner-commandlinerunner" target="_blank">ApplicationRunner & CommandLineRunner </a></li>
            <li><a href="sb_bean" target="_blank">Spring Boot Bean Configuration</a></li>
            <li><a href="spring-boot-value-annotation" target="_blank">Read external configuration</a></li>
		    <li><a href="sb_jsp" target="_blank">Spring Boot JSP example</a></li>            
            <li><a href="spring-boot-logging-example" target="_blank">Logging example</a></li>
            <li><a href="spring-boot-actuator" target="_blank">Actuator health example</a></li>
            <li><a href="spring-boot-micrometer-prometheus" target="_blank">Micrometer Prometheus example</a></li>
			<li><a href="spring-boot-rest-api" target="_blank">REST API example</a></li>
            <li><a href="spring-boot-custom-error-page" target="_blank">Display custom error page</a></li>
            <li><a href="spring-boot-controlleradvice" target="_blank">@ControllerAdvice example</a></li>
            <li><a href="spring-boot-asynchronous" target="_blank">Asynchronous Controller example</a></li>
            <li><a href="spring-boot-async-example" target="_blank">@Async example</a></li>
			<li><a href="spring-boot-swagger-example" target="_blank">Swagger example</a></li>
			<li><a href="spring-boot-thymeleaf-example" target="_blank">Thymeleaf example</a></li>
            <li><a href="spring-boot-webflux" target="_blank">WebFlux example</a></li>
            <li><a href="spring-boot-file-upload-example" target="_blank">File upload example</a></li>
            <li><a href="spring-boot-mongodb-example" target="_blank">MongoDB example</a></li>
            <li><a href="spring-boot-kafka-example" target="_blank">Kafka example</a></li>
            <li><a href="spring-boot-kafka-streams-example" target="_blank"> Kafka Streams</a></li>
    	</ul>
		</div>
	</div>-->
    
    <div id="posts">
        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-print-all-beans" target="_blank">Display all beans</a></h3></div>
            <div id="postText"><p>During Spring Boot application startup, many beans are created, some by...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-interceptor" target="_blank">Interceptor example</a></h3></div>
            <div id="postText"><p>In Spring Boot web application, you can register interceptors for the handlers ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-change-tomcat-port" target="_blank">How to change Tomcat Port</a></h3></div>
            <div id="postText"><p>By default Spring Boot uses Tomcat as the container and runs the server...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">        
            <div id="postHeader"><h3><a href="spring-boot-applicationrunner-commandlinerunner" target="_blank">Application & CommandLine Runner</a></h3></div>
            <div id="postText"><p>ApplicationRunner implementation is used to execute the code after the Spring Boot application ...</p></div>    
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>  

        <div id="postLeft">
            <div id="postHeader"><h3><a href="sb_bean" target="_blank">Spring Boot Bean Configuration</a></h3></div>
            <div id="postText"><p>@Bean annotation is a method-level annotation and is invoked when the class...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-value-annotation"" target="_blank">Read external configuration</a></h3></div>
            <div id="postText"><p>This tutorial shows how to use @Value & @ConfigurationProperties annotations to read...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div> 
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-basic-authentication" target="_blank">Spring Boot Basic Authentication</a></h3></div>
            <div id="postText"><p>To protect a REST API being invoked by any unwanted ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.3.0, Java 1.8</p></div>
        </div>  
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-logging-example"" target="_blank">Logging example</a></h3></div>
            <div id="postText"><p>Spring Boot uses commons-logging for its internal logging & uses SLF4J as logging ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div> 
         
        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-actuator" target="_blank">Actuator health example</a></h3></div>
            <div id="postText"><p>Using Spring Boot Actuator you can monitor your spring boot application...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-micrometer-prometheus"" target="_blank">Micrometer Prometheus example</a></h3></div>
            <div id="postText"><p>Spring Boot Actuator offers basic metrics but Micrometer provides a way ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>

        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-rest-api" target="_blank">REST API example</a></h3></div>
            <div id="postText"><p>This example shows how to build a User CRUD application using ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-custom-error-page" target="_blank">Display custom error page</a></h3></div>
            <div id="postText"><p>By default exception or error handling is enabled in Spring Boot and it shows ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div> 

        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-controlleradvice" target="_blank">@ControllerAdvice example</a></h3></div>
            <div id="postText"><p>By default Spring Boot shows a default or custom error page ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-asynchronous" target="_blank">Asynchronous Controller example</a></h3></div>
            <div id="postText"><p>As of Servlet 3, it is possible to handle a HTTP request asynchronously ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>         
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-async-example" target="_blank">@Async example</a></h3></div>
            <div id="postText"><p>Sometimes you might have a time taking service call which you ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-swagger-example" target="_blank">Swagger example</a></h3></div>
            <div id="postText"><p>Using Spring Boot Swagger you can automate API documentation ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div> 

        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-thymeleaf-example" target="_blank">Thymeleaf example</a></h3></div>
            <div id="postText"><p>Thymeleaf is a Java XML/XHTML/HTML5 template engine that works  ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-webflux" target="_blank">WebFlux example</a></h3></div>
            <div id="postText"><p>Spring WebFlux which is a reactive-stack web framework ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div> 

        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-file-upload-example" target="_blank">File upload example</a></h3></div>
            <div id="postText"><p>This example shows how to create a Spring Boot Web Application that uploads ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-mongodb-example" target="_blank">MongoDB example</a></h3></div>
            <div id="postText"><p>This tutorial shows how to configure and use Mongodb for CRUD operations in ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div> 

        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-kafka-example" target="_blank">Kafka example</a></h3></div>
            <div id="postText"><p>Kafka is a distributed publish/subscribe messaging system which is highly ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-kafka-streams-example" target="_blank">Kafka Streams</a></h3></div>
            <div id="postText"><p>Stream processing means processing the data as it continuosly arrives ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>

        <div id="postLeft">
            <div id="postHeader"><h3><a href="spring-boot-redis-example" target="_blank">Redis example</a></h3></div>
            <div id="postText"><p>Redis is an in-memory open source data store which can be used ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.3.0, Java 1.8, Jedis 3.3.0</p></div>
        </div>

        <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-graphql-example" target="_blank">GraphQL example</a></h3></div>
            <div id="postText"><p>When a request is made to a <code>REST</code> service, it sends data for only ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.3.0, GraphQL Spring Boot 5.0.2, Java 1.8</p></div>
        </div>  

        <div id="postLeft">
            <div id="postHeader"><h3><a href="sb_jsp" target="_blank">Spring Boot JSP example</a></h3></div>
            <div id="postText"><p>This example shows how to render a jsp in Spring Boot application...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Java 1.8</p></div>
        </div>        
        
         <div id="postRight">
            <div id="postHeader"><h3><a href="spring-boot-data-jpa-example" target="_blank">Spring Boot Data JPA example</a></h3></div>
            <div id="postText"><p>Spring Boot Data JPA helps Java based applications access backend ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot Data JPA 2.3.0, h2 1.4, Java 1.8</p></div>
        </div> 
        
        <?php include("../sidebar/ad.htm"); ?>
        <!-- Spring Security annotations -->
        <!-- Inject vs Autowired -->
        <!-- Spring Boot security oauth2 -->
        <!-- Spring Boot security jwt -->
        <!-- Spring Boot Lombok example -->
        <!-- Spring Boot REST API validation example -->
        <!-- Spring boot retry example -->
        <!-- How to create war file using maven in spring boot -->
        <!--TBD resttemplate exception handling , resttemplate error handler-->
        <!--TBD spring boot devtools-->
        <!--spring requestmapping, spring boot requestmapping, getmapping vs requestmapping -->
        <!--spring boot request param-->
        <!--TBD <li><a href="sb_crud.php" target="_blank">Spring Boot crud example</a>< /li>-->
        <!--TBD <li><a href="spring-boot-postmapping.php" target="_blank">Spring Boot Postmapping</a></li>postmapping spring boot-->
		<!--TBD <li><a href="spring-boot-jdbc-example" target="_blank">Spring Boot jdbc example</a></li>
        <!--TBD <li><a href="spring-boot-scheduler-example" target="_blank">Spring Boot scheduler example</a></li>-->
          
    </div>
	
    <?php include("../sidebar/sidebarHomePage.htm"); ?>
	
</body>

<?php include("footer.htm");?>

</html>
