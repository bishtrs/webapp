    <?php include("../header.htm");?>

    <head>
        <title>Spring Boot File Upload example</title>
        <meta name="description" content="Spring Boot File Upload example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-file-upload-example" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h2>Spring Boot File Upload example</h2>
        </div>
        <div id="solution">
            <p>This example shows how to create a Spring Boot Web Application that uploads file. We will create a FileUploadController and 
            FileService to upload a file.
            </p> 
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;		
          
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-thymeleaf&lt;/artifactId&gt;
    &lt;/dependency&gt;	 
&lt;/dependencies&gt;        </pre></div><br>
    
         <h4>Step 2) Create FileUploadApplication class</h4>
         
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadApplication {

    public static void main(String[] args) {
        SpringApplication.run(FileUploadApplication.class, args);
    }
}        </div>
        </pre>
        <br>
    
    <h4>Step 3) Create uploadForm.html file and put it under src/main/resources/templates directory</h4>
    <p>
    <b><i>uploadForm.html</b></i> is a HTML5 page which serves as the file upload form page for FileUploadApplication
    </p>
        <div id="code">
        <pre class="prettyprint">
&lt;!DOCTYPE html&gt;
    &lt;html xmlns:th="http://www.thymeleaf.org"&gt;

    &lt;div th:if="${message}"&gt;
		&lt;h2 th:text="${message}"/&gt;
	&lt;/div&gt;
    
    &lt;div&gt;
        &lt;form method="POST" enctype="multipart/form-data" action="/"&gt;
            &lt;table&gt;
                &lt;tr&gt;&lt;td&gt;File to upload:&lt;/td&gt;&lt;td&gt;&lt;input type="file" 
                    name="file" /&gt;&lt;/td&gt;&lt;/tr&gt;
                &lt;tr&gt;&lt;td&gt;&lt;/td&gt;&lt;td&gt;&lt;input type="submit" 
                    value="Upload" /&gt;&lt;/td&gt;&lt;/tr&gt;
            &lt;/table&gt;
        &lt;/form&gt;
    &lt;/div&gt;
&lt;/html&gt;        </div>
        </pre>	
        <br>
        
        
    <h4>Step 4) Create FileServiceImpl classes</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {
	
    void save(MultipartFile file);

}        </div>
        </pre>	
            
       <br>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileServiceImpl implements FileService {
	
    public void save(MultipartFile file) {
        try {
            Files.write(Paths.get("C://Data.txt"), file.getBytes());
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        System.out.println("File saved successfully");
    }

}        </div>
        </pre>	
        <br>
                
 
<h4>Step 5) Create FileUploadController class</h4>
<p>FileUploadController contains one GET request mapping to load file upload form and another POST request mapping to handle file upload.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class FileUploadController {
	
    @Autowired
    private FileService fileService;
        
    @GetMapping("/")
    public String uploadFiles(Model model) throws IOException {
        return "uploadForm";
    }
        
    @PostMapping("/")
    public String handleFileUpload(@RequestParam("file") MultipartFile file,
            RedirectAttributes redirectAttributes) {

        fileService.save(file);
        redirectAttributes.addFlashAttribute("message",
            "You successfully uploaded " + file.getOriginalFilename() + "!");

        return "redirect:/";
    }

}        </div>
        </pre>	
        <br>
 
        <h4>Step 6) Running FileUploadApplication</h4>
        To Run this Spring Boot application from command prompt, use following command &rarr; <b>java -jar demo-0.0.1-SNAPSHOT.jar</b></h4>
        
    <!-- ADU1 -->
    <?php include("../sidebar/sidebar.htm"); ?>    

     <h4>Step 7) Testing FileUploadApplication </h4>
     <p>Open any browser and launch <b>http://localhost:8080</b>. You will see below page.</p>
     <p>Choose file and click on upload button. Check that file is saved to specified location.</p><br>
        <div>
            <p><img src="../images/springboot/fileupload.jpg" alt="File upload" style="width:300px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br>
   
    <div id="solution">
        <h2>Controlling File Upload Limits</h2>
        <p>
        When configuring file uploads, you can set limits on the size of file. To achieve this you need to add 
        the following properties to your existing properties settings (in application.properties under src/main/resources) file.
        </p>   
     </div>
     
    <div id="code">
    <pre class="prettyprint">
spring.servlet.multipart.max-file-size=128KB
spring.servlet.multipart.max-request-size=128KB</pre>
    </div>	

    <p>
    If you try to upload a file with size more than 128KB, you will get below error
    </p>
<div id="code">
    <pre class="prettyprint">
Whitelabel Error Page
This application has no explicit mapping for /error, so you are seeing this as a fallback.

Fri Apr 17 19:20:03 IST 2020
There was an unexpected error (type=Internal Server Error, status=500).
Maximum upload size exceeded; nested exception is java.lang.IllegalStateException: 
org.apache.tomcat.util.http.fileupload.FileUploadBase$SizeLimitExceededException: the request was rejected because its size (38223)
 exceeds the configured maximum (1024)</pre>
    </div>    
    <br>
    References : <br><br>
    <a href="https://spring.io/guides/gs/uploading-files/" target="_blank">Uploading files</a>	<br><br>

    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->

        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>