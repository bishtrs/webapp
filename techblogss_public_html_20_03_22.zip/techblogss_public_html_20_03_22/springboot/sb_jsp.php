    <?php include("../header.htm");?>

    <head>
        <title>Spring Boot JSP Example</title>
        <meta name="description" content="Spring Boot JSP Example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/sb_jsp" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot JSP Example</h1>
        </div>
        <div id="solution">
            <p>This example shows how to render a jsp in Spring Boot application</p> 
        </div>
        
    <h4>Step 1) Create pom.xml and add below maven dependency</h4>
    
	<div id="code">
    <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;
    
    <!-- JSTL for JSP -->
    &lt;dependency&gt;
        &lt;groupId&gt;javax.servlet&lt;/groupId&gt;
        &lt;artifactId&gt;jstl&lt;/artifactId&gt;
    &lt;/dependency&gt;	
 
    <!-- Required to compile JSP -->
    &lt;dependency&gt;
        &lt;groupId&gt;org.apache.tomcat.embed&lt;/groupId&gt;
        &lt;artifactId&gt;tomcat-embed-jasper&lt;/artifactId&gt;
        &lt;scope>provided&lt;/scope>
    &lt;/dependency&gt;	    
&lt;/dependencies&gt;
</pre></div><br>

         <h4>Step 2) Create WebApplication class</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication  
public class WebApplication extends SpringBootServletInitializer {
	
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(WebApplication.class);
    }
    
    public static void main( String[] args ) {
    	SpringApplication.run(WebApplication.class, args);  
    }

}        </div></pre><br>

    <h4>Step 3) Create HelloWorldController class which will expose endpoint to return a String which will be displayed by the JSP page</h4>
    
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloWorldController {

    @GetMapping("/")
    public String hello(Map&lt;String, Object> model) {
    	model.put("message", "Hello world JSP example");
        return "helloWorld";
    }
}        </div></pre><br>
        
        <h4>Step 4) Create helloWorld.jsp file under src/main/webapp/WEB-INF/jsp folder</h4>
    
        <div id="code">
        <pre class="prettyprint">
&lt;!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"&gt;
&lt;%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%&gt;
&lt;%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%&gt;
&lt;html&gt;
    &lt;head&gt;
        &lt;title&gt;Spring Boot JSP example&lt;/title&gt;
        &lt;link href="css/main.css" rel="stylesheet"&gt;
    &lt;/head&gt;
	
    &lt;body&gt;
        &lt;h1&gt;Spring Boot JSP Example&lt;/h1&gt;
        &lt;h2&gt;Message: ${message}&lt;/h2&gt;
    &lt;/body&gt;
&lt;/html&gt;	
        </div>
        </pre>	
        <br>
        
<h4>Step 5) Create application.properties file under src/main/resources folder</h4>
    
        <div id="code">
        <pre class="prettyprint">
spring.mvc.view.prefix: /WEB-INF/jsp/
spring.mvc.view.suffix: .jsp       </div></pre><br>
        
        <h4>Step 6) Create main.css file under src/main/resources/static/css folder</h4>
    
        <div id="code">
        <pre class="prettyprint">
spring.mvc.view.prefix: /WEB-INF/jsp/
spring.mvc.view.suffix: .jsp     </div></pre><br>
        
        <div>
            <p><img src="../images/sb_jsp_2.jpg" alt="Maven Build" style="width:400px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
        <h4>Step 7) Running WebApplication</h4>
        
        <div id="solution">
            <h4>Console Output : </h4>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2019-10-19 09:23:33.576  INFO 4432 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8080 (http)
2019-10-19 09:23:33.620  INFO 4432 --- [main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
2019-10-19 09:23:33.620  INFO 4432 --- [main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.21]
2019-10-19 09:23:33.931  INFO 4432 --- [main] org.apache.jasper.servlet.TldScanner     : At least one JAR was scanned for TLDs yet contained no TLDs. Enable debug logging for this logger for a complete list of JARs that were scanned but no TLDs were found in them. Skipping unneeded JARs during scanning can improve startup time and JSP compilation time.
2019-10-19 09:23:33.938  INFO 4432 --- [main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2019-10-19 09:23:34.591  INFO 4432 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2019-10-19 09:23:34.595  INFO 4432 --- [main] com.example.demo.WebApplication          : Started WebApplication in 3.447 seconds (JVM running for 3.933)
2019-10-19 09:23:39.334  INFO 4432 --- [nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
2019-10-19 09:23:39.334  INFO 4432 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
2019-10-19 09:23:39.343  INFO 4432 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 9 ms
         </pre>
        </div><br>		
        

     <h4>Step 8) Testing HelloWorldApplication </h4>
     <p>Open any browser and launch <b>http://localhost:8080</b>. You will see 'Hello World' message displayed in the broswer.</p><br>
     
        <div>
            <p><img src="../images/sb_jsp.jpg" alt="Maven Build" style="width:700px;height:400px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
        </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
        
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>