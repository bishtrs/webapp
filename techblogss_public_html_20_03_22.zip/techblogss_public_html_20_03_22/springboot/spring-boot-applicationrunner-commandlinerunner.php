<?php 
    include("header.htm");
?>

<head>
    <title>Spring Boot ApplicationRunner & CommandLineRunner</title>
	<meta name="description" content="This tutorial explains how to use Spring Boot ApplicationRunner & CommandLineRunner and what is the difference between Spring Boot ApplicationRunner & CommandLineRunner" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-applicationrunner-commandlinerunner" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
        <h1>Spring Boot ApplicationRunner & CommandLineRunner</h1><br>
	</div>
    
	<div id="solution">
         <p>Both <b><i>ApplicationRunner</b></i> & <b><i>CommandLineRunner</b></i> provide same functionality but the only difference between 
         CommandLineRunner and ApplicationRunner is that CommandLineRunner run() accepts String array[] whereas ApplicationRunner run() accepts 
         ApplicationArguments as argument.</p>
    
        <h2>ApplicationRunner</h2>
        <p>
        <b><i>ApplicationRunner</b></i> is used to run the code after the Spring Boot application is started.
        You can use this interface to perform any actions right after the spring boot application is initialized.
        </p>
        <p>
        <b><i>ApplicationRunner</b></i> is a functional interface and it contains void <b><i>run(ApplicationArguments... args)</b></i> method
        which is invoked after the application startup.</p>
        <p>Multiple <b><i>ApplicationRunner</b></i> beans can be defined within the same application context and can be ordered using the Ordered 
        interface or @Order annotation.</p>
	</div><br>

 	 <h3>ApplicationRunner example</h3>
     <div id="solution">
        <p>Below <b><i>ApplicationRunner</b></i> implementation class DemoApplicationRunner will be invoked right after application has started.</p>
        <p>
        <b><i>ApplicationArguments</b></i> has getOptionNames() method that returns the names of all option arguments. For example,
        if the arguments were --option1=value1 --option2" would return the values ["option1", "option2"].
        </p>
        <p>
         Also <b><i>ApplicationArguments</b></i> contains getNonOptionArgs() method which returns the collection of non-option arguments parsed.
        </p>
     </div>
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class DemoApplicationRunner implements ApplicationRunner {

    @Override
    public void run(ApplicationArguments args) throws Exception {
        System.out.println("Application Runner called with " + args.getNonOptionArgs());
        System.out.println("Application Runner called with " + args.getOptionNames());
    }
}	</pre></div><br>
    
	 <h4>Spring Boot Application class
     
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelloWorldApplication.class, args);
    }
}	</pre>
	</div>

    <br>

    <h4>Running HelloWorldApplication</h4>
    <p>
        Run this Spring Boot application using following command &rarr; <b><i>java -jar demo-0.0.1-SNAPSHOT.jar --export=excel --db=oracle nonoption</b></i>
    </p>    
    <p>
    You will see the export, db options getting printed in console.
    </p>
<div id="solution">
		<h4>Output : </h4>
	</div>
    
    <div id="code">
    <pre class="prettyprint">
2020-04-06 14:25:58.923  INFO 4648 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2020-04-06 14:25:58.938  INFO 4648 --- [main] com.example.demo.HelloWorldApplication   : Started HelloWorldApplication in 3.761 seconds (JVM running for 5.125)
Application Runner called with [nonoption]
Application Runner called with [export, db]	</div></pre><br>
    

	<div id="problem">
		<h2>CommandLineRunner</h2>
	</div>
	<div id="solution">
        <p>
        <b><i>CommandLineRunner</b></i> implementation is used to run the code after the Spring Boot application is started.
        You can use this interface to perform any actions right after the spring boot application is initialized.
        </p>
        <p>
        <b><i>CommandLineRunner</b></i> is a functional interface and it contains void <b><i>run(String... args)</b></i> method which is invoked 
        after the application startup.</p>
        <p>Multiple <b><i>CommandLineRunner</b></i> beans can be defined within the same application context and can be ordered using the Ordered 
        interface or @Order annotation.
        </p>
     </div>

	 <h3>CommandLineRunner example</h3>
     <p>Below <b><i>CommandLineRunner</b></i> implementation class DemoCommandLineRunner will be invoked right after application has started.</p>
     
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DemoCommandLineRunner implements CommandLineRunner {

    @Override
    public void run(String... args) throws Exception {
        System.out.println("CommandLine Runner called with " + Arrays.toString(args));
    }
}	</pre>
	</div>

    <br>
    
    	<div id="code">
		<pre class="prettyprint">
2020-04-03 12:06:18.355  INFO 3764 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2020-04-03 12:06:18.359  INFO 3764 --- [main] com.example.demo.HelloWorldApplication   : Started HelloWorldApplication in 3.275 seconds (JVM running for 3.81)
CommandLine Runner called with [--database=oracle]</pre>	</div>		
    <br><br>
    
References : <br><br>
<a href="https://docs.spring.io/spring-boot/docs/current/api/org/springframework/boot/ApplicationRunner.html" target="_blank">Spring ApplicationRunner</a>	<br><br>
<a href="https://docs.spring.io/spring-boot/docs/current/api/org/springframework/boot/ApplicationArguments.html target="_blank">Spring ApplicationArguments</a>	<br><br>
<a href="https://docs.spring.io/spring-boot/docs/current/api/org/springframework/boot/CommandLineRunner.html" target="_blank">Spring CommandLineRunner</a>	<br><br>
    
 

    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>