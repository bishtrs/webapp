    <?php include("../header.htm"); ?>

    <head>
        <title>Spring Boot Thymeleaf example</title>
        <meta name="description" content="Spring Boot Thymeleaf example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-thymeleaf-example" />
    </head>

    <body>
        <?php include("../navigation.htm"); ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Thymeleaf example</h1>
        </div>
        <div id="solution">
            <p><code>Thymeleaf</code> is a Java <b><i>XML/XHTML/HTML5</b></i> template engine that works in both web (servlet-based) and non-web environments. In web applications <code>Thymeleaf</code> aims to be a complete substitute for JavaServer Pages (JSP).<code>Thymeleaf</code> is ideal for modern-day HTML5 JVM web development.
            </p>
            <p>This <code>Spring Boot Thymeleaf</code> example shows how to create a view using <code>Thymeleaf</code> as template engine in a <code>Spring Boot application</code>.</p> 
        </div>
        
        <h4>Step 1) Create pom.xml</h4>
        <div style="text-align: justify;">
        <p>
         Add <b><i>spring-boot-starter-thymeleaf</b></i> as a dependency in pom.xml file to get the desired <b><i>Thymeleaf</b></i> dependencies. Using above <b><i>Spring Boot</b></i> will configure the <b><i>ThymeleafViewResolver</b></i> automatically.
        </p>
        </div>
        
        <div id="code">
        <pre class="prettyprint">
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;		
          
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-thymeleaf&lt;/artifactId&gt;
    &lt;/dependency&gt;	 </pre></div>
        <br>
        
        <h4>Step 2) Create StudentsApplication class</h4>
         
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentsApplication.class, args);
    }
}        </div>
        </pre>
        <br>
    
    <h4>Step 3) Create index.html file and put it under src/main/resources/templates directory</h4>
    <p><b><i>index.html</b></i> is a HTML5 page which serves as the home page for StudentsApplication</p>
        <div id="code">
        <pre class="prettyprint">
&lt;!DOCTYPE html&gt;
    &lt;html xmlns:th="http://www.thymeleaf.org"&gt;
    &lt;head&gt;
        &lt;meta charset="UTF-8"&gt;
        &lt;title&gt;Spring Boot Thymeleaf example&lt;/title&gt;
    &lt;/head&gt;

    &lt;body&gt;
        &lt;h1&gt;List of Students&lt;/h1&gt;
        &lt;a th:href="@{/students}" href="#"&gt;Click here to view list of Students&lt;/a&gt;
    &lt;/body&gt;
&lt;/html&gt;        </div>
        </pre>	
        <br>
        
<h4>Step 4) Create students.html file and put it under src/main/resources/templates directory</h4>
    <p><b><i>students.html</b></i> is a HTML5 page which prints the list of all students</p>
        <div id="code">
        <pre class="prettyprint">
&lt;!DOCTYPE html&gt;
&lt;html xmlns:th="http://www.thymeleaf.org"&gt;&lt;/html&gt;
&lt;head&gt;
	&lt;meta charset="UTF-8"&gt;
	&lt;title&gt;Spring Boot Thymeleaf example&lt;/title&gt;
&lt;/head&gt;

&lt;body&gt;
&lt;h1&gt;List of Students&lt;/h1&gt;

 &lt;table&gt;
	 &lt;thead&gt;
		 &lt;tr&gt;
		 &lt;th&gt;Roll Number&lt;/th&gt;
		 &lt;th&gt;First Name&lt;/th&gt;
		 &lt;th&gt;Last Name&lt;/th&gt;
		 &lt;/tr&gt;
	 &lt;/thead&gt;
	 
    &lt;tbody&gt;
    &lt;tr th:each="student: ${students}"&gt;
    	&lt;td th:text ="${student.rollNumber}"&gt;Roll Number&lt;/td&gt;
    	&lt;td th:text ="${student.firstName}"&gt;First Name&lt;/td&gt;
    	&lt;td th:text ="${student.lastName}"&gt;Last Name&lt;/td&gt;
    &lt;/tr&gt;
    &lt;/tbody&gt;
    &lt;/table&gt;
&lt;/body&gt;        </div>
        </pre>	
        <br>        
        
    <h4>Step 5) Create Student StudentsService, StudentsServiceImpl classes</h4>
    <p><b><i>Student</b></i> class will be used as model by the Students application, <b><i>StudentsService</b></i> class will be used as service by controller.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class Student {

    private String rollNumber;
    private String firstName;
    private String lastName;
	
    public Student(String rollNumber, String firstName, String lastName) {
        this.rollNumber = rollNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }
	
    // removed getter and setter for brevity

    @Override
    public String toString() {
        return "Student [rollNumber=" + rollNumber + ", firstName=" + firstName + ", lastName="
            + lastName + "]";
    }

}        </div>
        </pre>	
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Collection;

public interface StudentsService {

    Collection&lt;Student> getAll();
    Student create(Student user);

}        </div>
        </pre>	
       
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

@Service
public class StudentsServiceImpl implements StudentsService {
	
    private final Map&lt;String, Student> students =  new ConcurrentHashMap&lt;>();
    
    public StudentsServiceImpl() {
    	students.put("123", new Student("123", "Robert", "Downey"));
    	students.put("124", new Student("124", "Christian", "Bale"));
    	students.put("125", new Student("125", "Henry", "Cavil"));
    }

    @Override
    public Collection&lt;Student>  getAll() {
        return students.values();
    }

    @Override
    public Student create(Student student) {
    	students.put(student.getRollNumber(), student);
        return student;
    }

}        </div>
        </pre>	
        <br>
                
 
<h4>Step 6) Create StudentsController class</h4>
    <p><b><i>getAllStudents()</b></i> will populate the model with the list of all students and returns the view name.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentsController {
	
    @Autowired
    private StudentsService studentsService;

    @RequestMapping(value = "/index")
    public String index() {
       return "index";
    }

    @GetMapping("/students")
    public String getAllStudents(Model model) {
    	model.addAttribute("students", studentsService.getAll());
    	System.out.println(model);
        return "students";
    }
    
    @PostMapping()
    public Student create(@RequestBody Student student) {
        return studentsService.create(student);
    }
}        </div>
        </pre>	
        <br>
        <h4>Directory structure</h4>        
        <div>
            <p><img src="../images/sb_thymeleaf_3.jpg" alt="Directory structure" style="width:300px;height:400px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

        <h4>Step 7) Run StudentsApplication</h4>
        <div id="solution">
            <h4>Console Output : </h4>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2019-11-30 21:00:08.555  INFO 3096 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8080 (http)
2019-11-30 21:00:08.602  INFO 3096 --- [main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
2019-11-30 21:00:08.602  INFO 3096 --- [main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.21]
2019-11-30 21:00:08.758  INFO 3096 --- [main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2019-11-30 21:00:08.758  INFO 3096 --- [main] o.s.web.context.ContextLoader            : Root WebApplicationContext: initialization completed in 2981 ms
2019-11-30 21:00:09.139  INFO 3096 --- [main] o.s.s.concurrent.ThreadPoolTaskExecutor  : Initializing ExecutorService 'applicationTaskExecutor'
2019-11-30 21:00:09.381  INFO 3096 --- [main] o.s.b.a.w.s.WelcomePageHandlerMapping    : Adding welcome page template: index
2019-11-30 21:00:09.529  INFO 3096 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2019-11-30 21:00:09.529  INFO 3096 --- [main] com.example.demo.StudentsApplication     : Started StudentsApplication in 4.569 seconds (JVM running for 5.058)
2019-11-30 21:00:09.824  INFO 3096 --- [nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring DispatcherServlet 'dispatcherServlet'
2019-11-30 21:00:09.824  INFO 3096 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet : Initializing Servlet 'dispatcherServlet'
2019-11-30 21:00:09.910  INFO 3096 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet : Completed initialization in 86 ms
2019-11-30 21:00:09.958  WARN 3096 --- [nio-8080-exec-1] .w.s.m.s.DefaultHandlerExceptionResolver : Resolved [org.springframework.web.HttpRequestMethodNotSupportedException: Request method 'GET' not supported]
{students=[Student [id=123, firstName=Robert, lasttName=Downey], Student [id=124, firstName=Christian, lasttName=Bale], Student [id=125, firstName=Henry, lasttName=Cavill]]}            </pre> </div><br>		
        
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>    

     <h4>Step 8) Testing StudentsApplication </h4>
     Open any browser and launch <a href="http://localhost:8080/index" target="_blank">http://localhost:8080/index</a> You will see below page.<br><br>
     
        <div>
            <p><img src="../images/sb_thymeleaf_1.jpg" alt="Maven Build" style="width:300px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br>
    
    <p>Click on the hyperlink which will navigate the user to <b>http://localhost:8080/students</b>. You will see below page.</p><br>
     
        <div>
            <p><img src="../images/sb_thymeleaf_2.jpg" alt="Maven Build" style="width:300px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br>
    References : <br><br>
    <a href="https://www.thymeleaf.org/" target="_blank">Thymeleaf </a>	<br><br>

    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->

        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>