<?php include 'header.php';?>

<head>
    <title>Spring Boot Interceptor example</title>
    <meta name="description" content="This example shows how to write an Interceptor in Spring Boot using Spring HandlerInterceptor" />
    <!-- Add AsyncHandlerInterceptor example also -->
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-interceptor" />
</head>

    <body>
        <?php 
            include("navigation.htm");
        ?>
        
        <div id="content">
        <div id="blog" style="float:left;">
        <div id="problem">
            <h1>Spring Boot Interceptor example</h1>
        </div><br>
        <h2>The example below shows how to create an Interceptor in Spring Boot using Spring HandlerInterceptor</h2>
        <div id="solution">
            <p>
            In Spring Boot web application, you can register interceptors for the handlers to implement common checking or logic. For example, a 
            handler interceptor can check the time taken by request, check authorization, perform auditing etc.
            </p> 
            <p>An <b><i>Interceptor</b></i> is similar to a Servlet <b><i>Filter</b></i>, but an <b><i>Interceptor</b></i> allows custom pre-processing and you can also stop the execution of the handler and custom post-processing. 
            </p>
            <h3>Implementing Interceptor</h3>
            <p>
            To create an interceptor in Spring Boot, you need to implement the <b><i>HandlerInterceptor</b></i> interface.
            You need to implement following three methods defined in <b><i>HandlerInterceptor</b></i> interface:
            <ul>
            <li>
            <b><i>preHandle()</b></i> method - this is called after handler object is chosen, but before HandlerAdapter invokes the handler.
            </li>
            <li>
            <b><i>postHandle()</b></i> method - this is called after HandlerAdapter invokes the handler, but before the DispatcherServlet renders the view.
            </li>
            <li>
            <b><i>afterCompletion()</b></i> method - this is called after request is processed and view is rendered.
            </li>
            </ul>
            </p>
        </div>
        
        <p>In the example below we will create a Logging <b><i>interceptor</b></i> and see how it gets invoked in a Spring Boot application</p>
        <h4>Step 1) Create pom.xml</h4>
        <div id="code">
        <pre class="prettyprint">
 &lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
	
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
	
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
	
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Spring Boot Interceptor&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;    </pre>
	</div>       <br>

         <h4>Step 2) Create SpringBootInterceptorApplication class</h4>
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootInterceptorApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootInterceptorApplication.class, args);
    }
}       </div>
        </pre>
        <br>
    <h4>Step 3) Create SpringBootInterceptorController class</h4>
    
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringBootInterceptorController {

    @GetMapping("/")
    public String hello() {
        System.out.println("Returning respone");
        return "Hello World";
    }
}        </div>
        </pre>	        <br>
        
    <h4>Step 4) Create LoggingInterceptor class which will act as an interceptor in this Spring Boot application.</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
public class LoggingInterceptor implements HandlerInterceptor {
	
    @Override
    public boolean preHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler) throws Exception {

        System.out.println("Pre Handle method is Calling");
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {

        System.out.println("Post Handle method is Calling");
    }

    @Override
    public void afterCompletion(HttpServletRequest request,
            HttpServletResponse response, Object handler, Exception exception)
            throws Exception {

        System.out.println("Request and Response is completed");
    }
}       </div>
        </pre>	
        <br>        

            <h4>Step 5) Create InterceptorConfig class</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Component
public class InterceptorConfig implements WebMvcConfigurer    {
   @Autowired
   LoggingInterceptor loggingInterceptor;

   @Override
   public void addInterceptors(InterceptorRegistry registry) {
      registry.addInterceptor(loggingInterceptor).addPathPatterns("/**");
   }
}   </pre>
        </div>	
        <br>   
        
        
       <h4>Step 7) Run SpringBootInterceptorApplication </h4>     
        Open any browser and launch <a href="http://localhost:8080" target="_blank">http://localhost:8080</a>. You will see 'Hello World' message 
        displayed in the broswer.<br>
     
        <div>
            <p><img src="../images/sb_helloworld.jpg" alt="Maven Build" style="width:700px;height:400px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
     
    <p>Observe the logs below which shows the log messages from the LoggingInterceptor class</p>    
        <div id="code">
        <pre class="prettyprint">
Pre Handle method is Calling
Returning respone
Post Handle method is Calling
Request and Response is completed       </pre>
        </div>	
        <br><br>        
        
    References : <br><br>
    <a href="https://docs.spring.io/spring/docs/current/javadoc-api/org/springframework/web/servlet/HandlerInterceptor.html" target="_blank">
    Spring HandlerInterceptor</a>	<br><br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>    
    
    
      </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>