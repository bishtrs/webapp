<?php include("../header.htm");?>

<head>
    <title>JUnit 5 Tutorial</title>
    <meta name="description" content="JUnit 5 Tutorial" />
    <link rel="canonical" href="https://www.techblogss.com/junit/junit5-tutorial" />
</head>

<body>
    <?php include("../navigation.htm");    ?>
       
    <div id="content">
    
    <div id="blog" style="float:left;">
    
    <div id="problem">
        <h1>JUnit 5 Tutorial</h1>
    </div>
    
    <div id="solution">
        <p>
        When you write business logic, you may tend to test it using actual test scenario like performing some action from UI or call the API 
        from tool like Postman, but it is always good practice to have a suite of <code>JUnit</code> tests to quickly test your code. 
        Writing <code>JUnit</code> test gives more confidence that code actually works!. Also if you write <code>JUnit</code> for an 
        existing piece of code, it provides you good understanding of code.
        </p>
        
        <p>
        <code>JUnit</code> is a standard framework for developing unit tests in Java.<code>JUnit</code> tests are programs to test the business
        logic of a program and helps in automating tests for code. Apart from testing existing code, <code>JUnit</code> test suite is also helpful
        in checking if anything is broken due to any code modifications.
        </p>
        
        <p>
        In this tutorial, we will show how to write a JUnit tests using <code>JUnit 5</code> framework.
        </p>
    </div>
    
    <div id="solution">
        <h2>How to write a basic JUnit 5 test</h2>
        <h4>Step 1) Add maven JUnit 5 dependencies</h4>
        <p>To run a <code>JUnit 5</code> test, you need below dependencies:</p>
    </div>
    
    <h4>Maven dependencies</h4>
    <div id="code"> <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.junit.jupiter&lt;/groupId>
    &lt;artifactId>junit-jupiter-api&lt;/artifactId>
    &lt;version>5.8.1&lt;/version>
    &lt;scope>test&lt;/scope>
&lt;/dependency>

&lt;dependency>
    &lt;groupId>org.junit.jupiter&lt;/groupId>
    &lt;artifactId>junit-jupiter-engine&lt;/artifactId>
    &lt;version>5.8.1&lt;/version>
    &lt;scope>test&lt;/scope>
&lt;/dependency>

&lt;dependency>
    &lt;groupId>org.junit.platform&lt;/groupId>
    &lt;artifactId>junit-platform-launcher&lt;/artifactId>
    &lt;version>1.8.2&lt;/version>
    &lt;scope>test&lt;/scope>
&lt;/dependency>    </pre></div><br> 

    <h4>Gradle dependencies</h4>  

<div id="code"> <pre class="prettyprint">
dependencies {

    testImplementation 'org.junit.jupiter:junit-jupiter-api:5.6.0'

    testRuntimeOnly 'org.junit.jupiter:junit-jupiter-engine:5.6.0'

    testImplementation 'org.junit.platform:junit-platform-launcher:1.8.2'

}</pre></div><br>  
            
    <div id="solution">
        <h4>Step 2) Write Calculator class with method multiply</h4>
        <p>
        In the example below, we will first write a Calculator class which has one method multiply, and then we will write a
        <code>JUnit 5</code> Test class to test whether multiply method actually works or not.
        </p>
    </div>
    
    <div id="code">    <pre class="prettyprint">
public class Calculator {
    
    public double multiply(double number1, double number2) {
        return number1 * number2;
    }
}    </pre></div>    

    <br>
    <div id="solution">
        <h4>Step 3) Write JUnit 5 CalculatorTest class which tests multiply() method of Calculator Class</h4>
        <p>
        Typically a <code>JUnit</code> test class ends with Test as suffix, so our <code>JUnit</code> class name will be CalculatorTest.
        </p>
        <p>
        <code>JUnit</code> framework will identify a method as test only if you mark the method as <code>@Test</code> annotation.
        CalculatorTest class below will create an instance of Calculator class and call its multiply method. To validate if the result
        is correct we use <code>assertEquals</code> method provided by the <code>Assert</code> class in which we provide the expected 
        result as one of the arguments and actual result as other argument.
        </p>
    </div>
    
    <div id="code">    <pre class="prettyprint">
// JUnit test which tests methods of Calculator class , it checks if result expected is correct   
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class CalculatorTest {

    @Test
    public void testMultiply() {
        Calculator calculator = new Calculator();
        double result = calculator.multiply(11, 12);
        assertEquals(132, result, 0);
    }

}    </pre></div><br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?> 
    <br>
 
     </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>