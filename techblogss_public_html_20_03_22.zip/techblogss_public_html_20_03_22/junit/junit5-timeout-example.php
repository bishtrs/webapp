<?php include("../header.htm"); ?>
<head>    <title>JUnit 5 timeout example</title>    <meta name="description" content="JUnit 5 timeout example" />    <link rel="canonical" href="https://www.techblogss.com/junit/junit5-timeout-example" /></head>
<body>    <?php include("../navigation.htm"); ?>    
    <div id="content">        <div id="blog">        <div id="problem">            <h2>JUnit 5 timeout example</h2>        </div>
        <div id="solution">        <p>            In some cases you are required to check if a method execution is completed within expected time say 500 ms. It not then the JUnit test            should fail. For e.g. setup of JUnit test or connecting to DB or method execution, etc. To achieve this you            can use <code>@Timeout</code> annotation with specified time limit in seconds, ms, ns, etc. and also using <code>assertTimeout</code>            This example shows JUnit 5 timeout examples.        </p>         </div>                <h4>1) Add below dependencies to pom.xml</h4>        <div id="code">        <pre class="prettyprint">&lt;dependency&gt;    &lt;groupId>org.junit.jupiter&lt;/groupId>    &lt;artifactId>junit-jupiter-engine&lt;/artifactId>    &lt;version>5.8.1&lt;/version>    &lt;scope>test&lt;/scope>&lt;/dependency&gt;</pre></div><br>                <h4>2) Write a Calculator class with time consuming factorial method.</h4>
        <div id="code">        <pre class="prettyprint">public class Calculator {
    public long factorial(int number) {
        if (number == 1) {            return 1;        }            return number * factorial(number - 1);    }
}</div></pre><br>    
        <h4>3) Write CalculatorTest class using JUnit 5 which tests factorial() method of Calculator Class by <code>@Timeout</code> annotation.</h4>        <p>        <code>@Timeout</code> annotation by default uses seconds as unit of time. You can change the unit by specifying value and unit attributes.        In below tests, test setup will fail if takes more than 2 sec. testFactorialWithTimeout test will fail if factorial takes more than 5 sec.        testFactorialWithLessTimeout test will fail if it takes more than 1 nanoseconds.        </p>         <div id="code">        <pre class="prettyprint">         import org.junit.jupiter.api.BeforeEach;import org.junit.jupiter.api.Test;import org.junit.jupiter.api.Timeout;
public class CalculatorTest {
    @BeforeEach    @Timeout(2)    void setUp() {        System.out.println("Sleeping for 1 sec");        try {            Thread.sleep(1000);        } catch (InterruptedException e) {
        // throws exception if time taken is more than 1 sec        e.printStackTrace();
        }
    }
    @Test    @Timeout(5)    public void testFactorialWithTimeout() {        Calculator calculator = new Calculator();        System.out.println("Calling factorial");        System.out.println(calculator.factorial(30));    }
    // fails if time taken is more than 1 ns    @Test    @Timeout(value = 1, unit = TimeUnit.NANOSECONDS)    public void testFactorialWithLessTimeout() {        Calculator calculator = new Calculator();        System.out.println("Calling factorial");        System.out.println(calculator.factorial(1000));    }
}</pre></div><br>

        <p>testFactorialWithLessTimeout test fails with below error message as it takes more than 1 nanosecond</p>        <div id="code"><pre class="prettyprint">        java.util.concurrent.TimeoutException: testFactorialWithLessTimeout() timed out after 1 nanosecond    at org.junit.jupiter.engine.extension.TimeoutInvocation. createTimeoutException (TimeoutInvocation.java:70)    at org.junit.jupiter.engine.extension.TimeoutInvocation.proceed (TimeoutInvocation.java:59)</pre></div><br>
        <h4>4) Test CalculatorTest using assertTimeout</h4>        <p>        You can also test timeout using <code>assertTimeout</code> as shown below. In this case you do not need to use <code>@Timeout</code>.        </p>
        <div id="code">            <pre class="prettyprint">import static java.time.Duration.ofMillis;import static java.time.Duration.ofNanos;import static org.junit.jupiter.api.Assertions.assertEquals;import static org.junit.jupiter.api.Assertions.assertTimeout;import java.util.concurrent.TimeUnit;import org.junit.jupiter.api.Test;
public class CalculatorTest {
    @Test    public void testFactorialTimeout() {        Calculator calculator = new Calculator();        System.out.println("Calling factorial");        // throws exception if time taken is more than 1 ns        long actualResult = assertTimeout(ofNanos(1), () -> {            return calculator.factorial(10);
        });
        assertEquals(3628800, actualResult);    }
    @Test    public void testTimeout() {        assertTimeout(ofMillis(10), () -> {            Thread.sleep(100);        });    }}       </pre></div><br>    

    References : <br><br>    <a href="https://junit.org/junit5/docs/5.5.1/api/org/junit/jupiter/api/Timeout.html">Timeout JUnit 5.5.1</a>    <br><br>    <a href="https://junit.org/junit5/docs/current/user-guide/#writing-tests-declarative-timeouts">JUnit 5 User Guide</a>    <br><br>              
    </div> <!-- blog div-->
    <?php include("../sidebar/sidebar.htm"); ?>
    </div> <!-- content div -->
    <div id="content">        <?php include '../blogs/entry.php';?>    </div>
    <?php include("share.htm"); ?>
    </body>
    <?php include("footer.htm");?>
</html>