
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb">
<head>
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="header">
	<div class="header-inner-block">
		<div class="header-inner header-left">
			<a href="https://www.hostingraja.in/" target="_blank"><img src="https://image.hostingraja.in/images/logo-white.png"></a>
		</div>
		<div class="header-inner header-right">
			<a href="https://help.hostingraja.in/" target="_blank" class='header-tutorial'>Tutorials</a>
			<a href="https://www.hostingraja.in/refer-earn-money/" target="_blank" class='header-refer'>Earn with us</a>
			<a href="https://affiliates.hostingraja.in/login" target="_blank" class='header-login'>Affiliates</a>
			<a href="https://www.hostingraja.in/login" target="_blank" class='header-login'>Login</a>
		</div>
	</div>
</div>
<div class="main-body">
<div class="body-content">
	<div class="body-content-inner">
		<div class="account-created-header-block">
			<h1>Your account has been created!</h1>
		</div>
		<div class="account-created-content-block">
			<div class="content-logo">
				<img alt="Hosting Raja" src="https://image.hostingraja.in/images/logo.jpg">
			</div>
			<div class="content-block-area">
				<p>Your account has been successfully installed on server! Please delete the file default.php/index.php/index.html from the public_html folder and then upload your website. </p>
			</div>
		</div>
	</div>
</div>
<div class="grid-block-contents">
	<div class="grid-blocks-content-inner">
		<div class="grid-block-content">
			<h3>Earn Money using Refer & Earn</h3>
			<p>
				You can refer and earn money using HostingRaja refer and earn money program.
				Visit this URL: <a href="https://www.hostingraja.in/refer-earn-money/" target="_blank">https://www.hostingraja.in/refer-earn-money/</a> to know more.
				Simply get the URL with your email ID and share it on facebook or twitter. On every successful sale, you can earn money.
			</p>
		</div>
		<div class="grid-block-content">
			<h3>Join Our Affiliates</h3>
			<p>
				Join India's most popular affiliate program. Joining HostingRaja's affiliate program is easy and you can make money using your website's traffic. On every successful sale, you get commission.<br><br>
				Refer more to learn about it: <a href="https://affiliates.hostingraja.in/" target="_blank">https://affiliates.hostingraja.in/</a>

			</p>
		</div>
		<div class="grid-block-content">
			<h3>Do it yourself help pages</h3>
			<p>
				We have captured all the common issues and also how to resolve them by yourself.
				Refer our help section to find a solution for all common issues: <a href="https://help.hostingraja.in/" target="_blank">https://help.hostingraja.in/.</a> You can find a solution for all issues including servers, VPS and cloud pages.
			</p>
		</div>
		<div class="grid-block-content">
			<h3>Raise Ticket & Support Assistance</h3>
			<p>
				You can raise tickets using support portal <a href="https://support.hostingraja.in/" target="_blank">https://support.hostingraja.in/</a> and also by login to your account <a href="https://www.hostingraja.in/login" target="_blank">https://www.hostingraja.in/login/</a>
			</p>
		</div>

	</div>
</div>
<div class="inner-banner-content">
<div style="background: #5b1807;margin-bottom: 20px;">
<p id="hosting-offer-p3">Click below to get upto 55% OFFER</p>
</div>
<ul>
<li>
<a href="https://www.hostingraja.in/vps-hosting/">
<img src="https://image.hostingraja.in/images/vps-hosting-india.png" title="vps-hosting-india" alt="vps-hosting-india" />
<div>
<p id="best-hosting-plan-in-india"><strong>VPS Hosting India</strong></p>
<p>We provide FREE control panel and cheapest VPS hosting plans in India. Our VPS server starts from Rs. 999 per month with 44% OFFER on all VPS plans.</p>
</div>
</a>
</li>
<li>
<a href="https://www.hostingraja.in/windows-hosting/">
<img src="https://image.hostingraja.in/images/windows-web-hosting.png" title="windows-web-hosting" alt="windows-web-hosting" />
<div>
<p id="indian-hosting"><strong>Windows Web Hosting</strong></p>
<p id="india-hosting-company">Click here to <b><a href="https://www.hostingraja.in/">buy hosting</a></b>, Windows hosting space from Indian hosting company. Like Make In India, Hosting in India, With India's No.1 webhosting provider.</p>
</div>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.hostingraja.in/dedicated-servers/">
<img src="https://image.hostingraja.in/images/buy-dedicated-server.png" title="buy-dedicated-server" alt="buy-dedicated-server" />
<div>
<p><strong>Buy Dedicated Server</strong></p>
<p>India's No.1 dedicated server provider in India, We provide fully managed dedicated hosting in India, Get 44% OFFER on server today.</p>
</div>
</a>
</li>
<li>
<a href="https://www.hostingraja.in/cloud-hosting/">
<img src="https://image.hostingraja.in/images/buy-cloud-hosting.png" title="buy-cloud-hosting" alt="buy-cloud-hosting" />
<div>
<p><strong>Buy Cloud Hosting</strong></p>
<p>Our cloud hosting platform is designed as high available across all the components, fully scallable. The cheap and best cloud solutions in India.</p>
</div>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.hostingraja.in/">
<img src="https://image.hostingraja.in/images/cheap-web-hosting.png" title="cheap-web-hosting" alt="cheap-web-hosting" />
<div>
<p id="cheap-website-hosting"><strong>Cheap Web Hosting</strong></p>
<p id="cheap-web-hosting-india">Our hosting prices used to start from Rs. 69 onwards, Due to good quality support need, We are providing it for from Rs. 99 monthly. <b><a href="https://www.hostingraja.in/">Buy Web Hosting</a></b> from India.</p>
</div>
</a>
</li>
<li>
<a href="https://www.hostingraja.in/reseller-web-hosting/">
<img src="https://image.hostingraja.in/images/reseller-web-hosting.png" title="reseller-web-hosting" alt="reseller-web-hosting" />
<div>
<p id="Web-Hosting"><strong>Reseller Web Hosting</strong></p>
<p>Set up your Hosting Business Today with India's Best Reseller Hosting Company. Get upto 44% Off on Reseller Hosting Packages with many free and exciting Features.</p>
</div>
</a>
</li>
</ul>
</div>
</div>
<style>
.header {
    background: #000;
}
.header-inner-block {
	display: inline-block;
    width: 100%;
}
.header-inner.header-left {
    float: left;
}
.header-inner.header-right {
    float: right;
	padding: 35px;
}
.header-inner.header-right a {
	color:#FFF !important;
	padding: 0 10px 0 10px;
}
.body-content-inner {
    padding-top: 30px;
    padding-bottom: 30px;
}
.account-created-header-block {
    text-align: center;
}
.account-created-content-block {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 50%;
    margin: 0 auto;
}
.content-block-area {
    padding: 15px;
	border-radius:  3px;
    font-size: 18px;
    color: #fff;
    line-height: 26px;
}
.content-block-area,
.grid-block-content {
	background : #2ab7ca ;
	color: #000;
}
.grid-block-content a {
	color: #000 !important;
}
.grid-block-content {
    width: 25%;
	border-radius:  3px;
    margin: 20px;
    padding: 15px;
}

.main-body {
    width: 90%;
    margin: 0 auto;
}
.grid-block-contents {
    border-top: 3px solid #d2d2d2;
    padding-bottom: 17px;
}
.grid-blocks-content-inner {
    display: flex;

    justify-content: center;
}
.grid-block-content p {
	font-size: 16px;
    font-family: HelveticaNeue;
    line-height: 1.7;
    word-spacing: 2px;
}
p {
	font-size: 16px;
    font-family: HelveticaNeue;
    line-height: 1.7;
    word-spacing: 2px;
}
.content-block-area p {
    margin: 0;
}
.grid-block-content a {
    font-weight: bold;
}
a, body{
	font-family:HelveticaNeue
}
@font-face
{
	font-family:HelveticaNeue;
	src: url('https://image.hostingraja.in/templates/ja_community_plus/css/HelveticaNeue_Lt.ttf');
}
@-moz-document url-prefix() {
	@font-face
	{
		font-family:HelveticaNeue;
		src: url('https://image.hostingraja.in/templates/ja_community_plus/css/helvetica.ttf');
	}
}
@media screen and (-webkit-min-device-pixel-ratio:0) {
@font-face
	{
		font-family:HelveticaNeue;
		src: url('https://image.hostingraja.in/templates/ja_community_plus/css/helvetica.ttf');
	}
}
body {
	margin: 0;
}
.inner-banner-content, .logo {
	text-align: center;
}
.inner-banner-content-div, .logo {
	width: 85%;
	margin: 10px auto;
}
.inner-banner-content strong {
	font-family:HelveticaNeue;
	line-height: 35px;
	font-size: 23px;
}
.inner-banner-content ul {
	width: 30%;
	display: table-cell;
}
.inner-banner-content li {
	padding-bottom: 20px;
	margin-right: 20px;
	text-align: left;
	min-height: 140px;
	list-style-type: none;
	display: inline-block;
	vertical-align: middle;
}
.inner-banner-content li img {
	float: left;
	margin: 30px 0;
	width: 25%;
}
.inner-banner-content li div {
	float: right;
	width: 72%;
	padding-left: 5px;
}
.inner-banner-content p {
    font-size: 16px;
    font-family: HelveticaNeue;
    line-height: 1.7;
    word-spacing: 2px;
}
#hosting-offer {
	background: #DB4D0F;
	color: #fff;
	font-family:HelveticaNeue;
}
#hosting-offer-p1 {
	font-size: 60px;
	margin: 0 0 -11px;
}
#popup-close-icon{right:9px;width:25px;color:#fff;font-size:21px;border:2px solid #fff;border-radius:50%;padding:0;top:9px;background:#db4d0f;float:right;position:absolute;cursor:pointer;height:25px;display:flex;align-items:center;justify-content:center}
#hosting-offer-p2 {
    font-size: 34px;
    margin: 0 0 15px;
}
#hosting-offer-p3 {
    font-size: 32px;
    margin: 0;
    color: #fff;
    font-weight: bold;
    text-decoration: underline;
}
a {
    text-decoration: none;
    color: #000;
}
.inner-banner-content li:hover {
	background-color: #f2f2f2;
}

@media screen and (min-width: 100px) and (max-width: 520px) {
	.header-inner.header-left {
 	   float: none !important;
	    text-align: center;
	}
	.header-inner.header-right {
 	   float: none !important;
	    padding: 0 0 20px 0;
	    display: flex;
	    align-items: center;
	    justify-content: center;
	}
	.account-created-content-block {
	    display: block !important;
	    width: 100% !important;
	    margin: 0 auto;
	}
	.grid-block-content {
	    width: 80% !important;
		margin: 10px !important;
	}
	.content-logo {
	    text-align: center;
	}

	.grid-blocks-content-inner {
	    display: block !important;
	}
	.inner-banner-content ul {
	    width: 100%;
	    display: block;
	    margin: 0;
	    padding: 0;
	}
	.logo {
		display: inline-block;
		width: 100%;
	}
	#hosting-offer-p2 {
		font-size: 24px;
	}
	.inner-banner-content li {
		text-align: center;
		margin: 0;
		padding: 0;
	}
	.inner-banner-content li img, .inner-banner-content li div {
		float: none;
		text-align: center;
		margin: 0 auto;
		padding: 0;
	}
	.inner-banner-content li div {
		width: 90%;
	}
	
}
.webshosting-logo {
	margin-bottom: 17px;
}
.webshosting-logo img {
    width: 350px;
}
#expp {
    background: #fff none repeat scroll 0 0 !important;
    color: #000 !important;
    text-align: center;
}
.col21 {
    background: #DB4D0F none repeat scroll 0 0;
    color: #fff;
    float: left;
    width: 100%;
}
#expp .wait_pp {
    float: left;
    font-size: 31px;
    margin-bottom: 0;
    margin-top: 0;
    padding-top: 0;
    width: 100%;
}
.col23 {
    background: #ffc300;
    float: left;
    width: 100%;
    color: #000000;
}
.col23 > h4 {
    float: left;
    width: 100%;
    margin-top: 10px;
    margin-bottom: 8px;
    font-size: 30px;
}
.col22 {
    float: left;
    width: 100%;
    line-height: 26px;
    padding-bottom: 13px;
    padding-top: 20px;
}
.col22 a {
    color: #555;
    float: left;
    font-size: 17px;
    line-height: 24px;
    text-decoration: none;
    width: 100%;
}
#expp p {
    color: #000000;
    float: left;
    font-size: 12px;
    margin-top: 0px ! important;
    text-align: center;
    width: 100%;
}
#expp p span {
    color: #E44600;
    font-size: 25px;
    font-weight: bold;
}
#expp_bg {
    width: 100%;
    height: 100%;
    position: fixed;
    z-index: 999999;
    opacity: 0.8;
    background: rgb(0, 0, 0);
    float: left;
    text-align: right;
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
}
</style>
</body>
</html>

