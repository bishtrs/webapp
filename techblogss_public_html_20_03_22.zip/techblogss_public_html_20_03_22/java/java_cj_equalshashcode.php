<?php 
    include("../header.htm");
?>

<head>
    <title>How to implement equals and hashcode methods in Java</title>
	<meta name="description" content="implement equals and hashcode in Java, implement using jdk 7, your own implementation, using Apache Commons Lang." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_cj_equalshashcode">
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to implement equals() and hashcode() methods in Java  ?</h1>
	</div><br>
    
   <h2>1) Implementing equals() method</h2>
   
     <div id="solution">
    <p>In Java if you want to check that two objects are meaningfully equal, then you need to implement <code>equals()</code> method in the respective Class. This is useful when you put objects in a <code>Set</code> or a <code>Map</code> implementation where you want to identify the unique object, as these classes rely on <code>equals()</code> method to uniquely identify an object.</p>
    <p>By default the <code>equals()</code> implementation in Object class uses <code>==</code> operator to compare two objects which is comparing by references.</p>
    <p>Suppose you have a Class Color and it has one attribute String color. Now you have two instances of Color Class which both have color as blue.
    So these two instances are meaningfully equal, but to compare you need to implement equals method in Color class.</p>
    <p>Below example shows how to implement <code>equals()</code> method.</p>
    <p>It is good practice to do <code>instanceof</code> check as shown below, else you may get <code>ClassCastException</code> while casting the object.</p>
    <p>The <code>equals()</code> method follows below:
    <ul>
        <li>Reflexive: If a reference x is not null, then <code>x.equals(x)</code> must return true.</li>
        <li>Symmetric: If references x,y are not null, then <code>x.equals(y)</code> should return true if and only if <code>y.equals(x)</code> returns true.</li>
        <li>Transitive: If references x,y,z are not null, and if <code>x.equals(y)</code> & <code>y.equals(z)</code> return true then <code>x.equals(z)</code> must return true.</li>
        <li>Consistent: If references x,y are not null, then multiple invocations of <code>x.equals(y)</code> must return true consistently or false consistently.</li>
        <li>If a reference x is not null, then <code>x.equals(null)</code> must return false.</li>
    </ul>
    </p>
    </div><br>
    
    	<div id="code">
    <pre class="prettyprint">
public class Color {
    private String color;
    public Color(String color) {
        this.color = color;
    } 

    public String getColor() {
        return this.color;
    }    

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Color) {
            Color other = (Color) obj;
            if (other.color.equals(this.color)) {
                return true;
            }
        } 
        return false;
    }

    public static void main(String args[]) {
        Color c1 = new Color("blue");
        Color c2 = new Color("blue");
        System.out.println(c1.equals(c2)); // prints true
    }
    
}   </pre></div>

    <br>
    <h2>2) Implementing hashCode() method</h2>
    <div id="solution">
    <p>When you use data structure like <code>HashMap</code>, apart from implementing <code>equals()</code> method, you also need to implement <code>hashCode()</code> to properly distribute the keys in <code>HashMap</code>.</p>
    <p><code>HashMap</code> uses buckets to store keys, and to uniformly distribute keys across buckets, it uses <code>hashCode()</code> to decide in which bucket key will land up.</p>
    <p>A bucket may contain more then one key with same hashCode value but <code>equals()</code> method will determine which is the correct key. So if two objects are equal, they should always have same hashcode but the reverse is not mandatory.</p>
    <p>Below example shows how to implement <code>equals()</code> and <code>hashCode()</code> methods. Here we create a MobileNumber class and to determine if two mobile numbers are equal, we use prefix and the mobileNumber attributes.</p>
    <p>Note that in <code>hashCode()</code> implementation, we multiply intermediate values by a prime number so that its evenly generated.</p>
    </div>

   
	<div id="code">
    <pre class="prettyprint">
// Overrides equals and hashcode in Java    
public final class MobileNumber {
    private final int prefix;
    private final int mobileNumber;
	
    public MobileNumber(int prefix, int mobileNumber) {
        this.prefix = prefix;
        this.mobileNumber = mobileNumber;
    }
	
    // equals method implementation
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }

        if ( !(o instanceof MobileNumber) ) { // checks for null also
            return false;
        }

        MobileNumber mn = (MobileNumber) o;
        return (mn.mobileNumber == mobileNumber && mn.prefix == prefix);
    }
    
    // hashCode method implementation	
    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + prefix;
        result = 31 * result + mobileNumber;
        return result;
    }
	
    // Test
    public static void main(String[] args) {
    	MobileNumber mobileNumber1 = new MobileNumber(91, 1234565789);
    	MobileNumber mobileNumber2 = new MobileNumber(92, 1234565789);
    	System.out.println(mobileNumber1.equals(mobileNumber2));
    	
    	MobileNumber mobileNumber3 = new MobileNumber(91, 1234565789);
    	System.out.println(mobileNumber1.equals(mobileNumber3));
    }	

}
	</pre>	
	</div>
 
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
false
true		</pre></div><br>

	
	
	<div id="solution">
		<h2>3) Implement equals() and hashcode() using Java 7 Objects equals() & hashcode(). </h2>
        <p>Java <code>Objects</code> class also provides equals() & hashcode() methods to simplify the implementation as shown below.
        It makes equals() & hashcode() implementations more compact.</p>
        <p>Objects equals() method will return true if both the arguments are equal while hashcode() will return a hashcode if argument is
        not null.</p>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
import java.util.Objects;
	
public final class MobileNumber {
    private final int prefix;
    private final int mobileNumber;
        
    public MobileNumber(int prefix, int mobileNumber) {
        this.prefix = prefix;
        this.mobileNumber = mobileNumber;
    }
    
    // equals method implementation	
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }

        if ( getClass() != o.getClass() ) {
            return false;
        }
        MobileNumber mn = (MobileNumber) o;
        return (Objects.equals(this.prefix, mn.prefix) 
            && Objects.equals(this.mobileNumber, mn.mobileNumber));
    }
     
    // hashCode method implementation		 
    @Override
    public int hashCode() {
        return Objects.hash(this.prefix, this.mobileNumber);
    }

    // Test
    public static void main(String[] args) {
    	MobileNumber mobileNumber1 = new MobileNumber(91, 1234565789);
    	MobileNumber mobileNumber2 = new MobileNumber(92, 1234565789);
    	System.out.println(mobileNumber1.equals(mobileNumber2));
    	
    	MobileNumber mobileNumber3 = new MobileNumber(91, 1234565789);
    	System.out.println(mobileNumber1.equals(mobileNumber3));
    }	

}   </pre> </div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
false
true</pre></div><br>
	
	<div id="solution">
		<h2>4) Using Apache Commons Lang EqualsBuilder and HashCodeBuilder method.</h2>
        <p>You can also use Apache commons lang library to implement equals() and hashcode() methods. You can specify the Class attribute (you want to use in implementing equals and hashcode) in the <code>EqualsBuilder</code> or <code>HashCodeBuilder</code> append method.</p>
        You need to download Apache Commons Lang library from here <a href="https://jar-download.com/artifacts/org.apache.commons/commons-lang3/3.7/source-code" target="_blank">download commons-lang3-3.7.jar</a>
	</div>
    
    <div id="code">
    <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.apache.commons&lt;/groupId>
    &lt;artifactId>commons-lang3&lt;/artifactId>
    &lt;version>3.7&lt;/version>
&lt;/dependency>   </pre></div><br>
	
	<div id="code">
    <pre class="prettyprint">
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
	
public final class MobileNumber {
    private final int prefix;
    private final int mobileNumber;
        
    public MobileNumber(int prefix, int mobileNumber) {
        this.prefix = prefix;
        this.mobileNumber = mobileNumber;
    }
    
    // equals method implementation	              
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }

        if ( getClass() != o.getClass() ) {
            return false;
        }
        MobileNumber mn = (MobileNumber) o;
    
        return new EqualsBuilder()
            .append(prefix, mn.prefix)
            .append(mobileNumber, mn.mobileNumber)
            .isEquals();
    }
    
    // hashCode method implementation		
    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 31)
        .append(this.prefix)
        .append(this.mobileNumber)
        .toHashCode();
    }
	
    // Test
    public static void main(String[] args) {
    	MobileNumber mobileNumber1 = new MobileNumber(91, 1234565789);
    	MobileNumber mobileNumber2 = new MobileNumber(92, 1234565789);
    	System.out.println(mobileNumber1.equals(mobileNumber2));
    	
    	MobileNumber mobileNumber3 = new MobileNumber(91, 1234565789);
    	System.out.println(mobileNumber1.equals(mobileNumber3));
    }	
}
   </pre>        
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
false
true	</pre>
	</div><br>
    
    References : <br><br>
    <a href ="https://docs.oracle.com/javase/8/docs/api/java/util/Objects.html#equals-java.lang.Object-" target="_blank">https://docs.oracle.com/javase/8/docs/api/java/util/Objects.html#equals-java.lang.Object-</a><br><br>
    <a href="https://docs.oracle.com/javase/8/docs/api/java/util/Objects.html#hashCode-java.lang.Object-" target="_blank">https://docs.oracle.com/javase/8/docs/api/java/util/Objects.html#hashCode-java.lang.Object-</a>	

    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
   
</body>

<?php include("footer.htm");?>

</html>
