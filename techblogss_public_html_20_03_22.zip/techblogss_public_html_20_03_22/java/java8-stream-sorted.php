<?php include("../header.htm");?>

<head>
    <title>Java 8 Stream sort list of objects by field</title>
	<meta name="description" content="Java 8 Stream sort list of objects by field" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-stream-sorted" />
</head>

<body>
	<?php include("../navigation.htm");	?>
    
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h1>Sort list of objects by field in Java 8</h1>
        <p>The <b><i>Stream</b></i> interface includes <b><i>sorted()</b></i> method that can be used to sort list of objects by 
        natural order or by using a <b><i>Comparator</b></i>. 
	</div>

	<div id="solution">
		<h4>1) Sort list of objects by natural order using <b><i>Stream sorted()</b></i> method</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Stream Sort example    
package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StreamSort {

    public static void main(String[] args) {
        List&lt;String> actors = Arrays.asList("Tom", "Harry", "Mark");
        actors.stream().sorted().forEach(System.out::println);
    }
}	</pre></div>

    <div id="solution">
		<h4>Console Output : </h4>
    </div>
	
	<div id="code">
		<pre class="prettyprint">
Harry
Mark
Tom	</pre></div><br>

	<div id="solution">
		<h4>2) Sort list of objects by providing a <b><i>Comparable</b></i> order using <b><i>Stream sorted()</b></i> method</h4>
        <p>
        In this example we will sort list of Ball objects by name field.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Stream Sort example    
package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StreamSort {

    public static void main(String[] args) {
        Ball tennis = new Ball("tennis", 1, "green");
        Ball footBall = new Ball("football", 2, "white");
        Ball basketBall = new Ball("basketBall", 3, "orange");
        List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall);
        balls.stream().sorted().forEach(System.out::println);
    }
}

class Ball implements Comparable&lt;Ball> {

    private String name;
    private int size;
    private String color;

    // removed constructor, getters and setter for brevity    

    @Override
    public String toString() {
        return "Ball [name=" + name + ", size=" + size + ", color=" + color + "]";
    }

    public int compareTo(Ball ball) {
        return this.getName().compareTo(ball.getName());
    }

}	</pre></div>

    <div id="solution">
		<h4>Console Output : </h4>        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Ball [name=basketBall, size=3, color=orange]
Ball [name=football, size=2, color=white]
Ball [name=tennis, size=1, color=green]	</pre></div><br>
	
    <div id="solution">
		<h4>3) Sort list of objects by calling <b><i>Comparator comparing()</b></i> method using any of the object field.</h4>
        <p>You can also sort the stream like this</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StreamSort {

    public static void main(String[] args) {
        Ball tennis = new Ball("tennis", 1, "green");
        Ball footBall = new Ball("football", 2, "white");
        Ball basketBall = new Ball("basketBall", 3, "orange");
        List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall);
        balls.stream().sorted(Comparator.comparing(Ball::getSize))
            .forEach(System.out::println);
        balls.stream().sorted(Comparator.comparing(Ball::getSize).reversed())
            .forEach(System.out::println);
    }
}
    </div>
    </code>    
    	
	<div id="code">
		<pre class="prettyprint">
Ball [name=tennis, size=1, color=green]
Ball [name=football, size=2, color=white]
Ball [name=basketBall, size=3, color=orange]
Ball [name=basketBall, size=3, color=orange]
Ball [name=football, size=2, color=white]
Ball [name=tennis, size=1, color=green]	</pre></div><br>

    <p>You can also sort the stream like this</p>
		
	<div id="code">
	<pre class="prettyprint">
balls.stream().sorted(b1, b2 -> b1.getSize() - b2.getSize())
    .forEach(System.out::println);    </div></code><br>
    
    <div id="solution">
		<h4>Console Output : </h4>
	</div>
    
       
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#sorted--" target="_blank">Oracle Docs Stream sorted()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html#comparing-java.util.function.Function-" target="_blank">Oracle Docs 
Comparator comparing()</a>	<br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
