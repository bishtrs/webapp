<?php 
    include("header.htm");
?>

<head>
    <title>Lock in Java</title>
	<meta name="description" content="Lock in Java, acquire lock in java using synchronized keyword, ReentrantLock lock, tryLock method." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_lock">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Lock in Java</h1>
        <p>
        Below are the examples of how to acquire lock in Java
        
        </p> 
	</div>
	
	<div id="solution">
		<h4>1) Acquire a <b><i>lock</b></i> in Java using synchronized keyword </h4>
        <p>In below example, you can see that when one <b><i>thread (Thread-0)</b></i> is executing setCounter() method,
        other <b><i>thread (Thread-1)</b></i> cannot enter other synchronized method getCounter().</p>
	</div>
    
    <div id="code">
    <pre class="prettyprint">
public class Counter {
    private int counter;
			
    public synchronized int getCounter() {
        System.out.println(Thread.currentThread().getName() + " in getCounter method");    
        return counter;
    }
    
    public synchronized void setCounter(int counter) {
        System.out.println(Thread.currentThread().getName()  + " in setCounter method");   
        this.counter = counter;
        try {
            Thread.sleep(2000); // takes lock with it
        } catch (InterruptedException e) {
            e.printStackTrace();
        }        
    }
    
    public static void main(String[] args) {
        Counter counter = new Counter();
    	
        Thread t1 = new Thread(() -&gt; {
            for (int i=0; i&lt;5; i ++) {
                counter.setCounter(i++);
            }
        });
   		
        Thread t2 = new Thread(() -&gt; {
            for (int i=0; i&lt;5; i ++) {
                System.out.println("Counter value " + counter.getCounter());
            }
        });
        
        t1.start();
        t2.start();    
    }
}
    </pre>
    </div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread-0 in setCounter method
Thread-0 in setCounter method
Thread-1 in getCounter method
Thread-0 in setCounter method
Counter value 2
Thread-1 in getCounter method
Counter value 4
Thread-1 in getCounter method
Counter value 4
Thread-1 in getCounter method
Counter value 4
Thread-1 in getCounter method
Counter value 4
		</pre>
	</div>	
    <br>
    
	<div id="solution">
		<h4>2) Acquire a <b><i>lock</b></i> in Java using ReentrantLock lock()</h4>
        <p>A thread can also acquire a <b><i>lock</b></i> on a block of code using <b><i>java.util.concurrent.locks.ReentrantLock lock()</b></i> method.
        It has following signature : <b><i>public void lock()</b></i> & it acquires the <b><i>lock</b></i> if it is not held by 
        another thread and returns immediately. <br><br>
        In below example multiple threads cannot execute the block of code of instance for which lock has been acquired.
        It is recommended that you always follow the <b><i>lock()</b></i> method with a try-finally block, which releases the <b><i>lock</b></i>.
        </p> 
	</div>
	
	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Producer {
    private String data;
			
    public void produce() {
        data = "data";
    }
}

public class MyThread implements Runnable {
    private Producer producer;
    private Lock lock = new ReentrantLock();
    
    public MyThread(Producer producer) {
        this.producer = producer;
    }
	
    public void run() { 
        try {
            lock.lock(); // blocks until acquired
            System.out.println(Thread.currentThread().getName()  + " running");
            producer.produce();
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
    
    public static void main(String[] args) {
        MyThread myThread = new MyThread(new Producer());
        Thread threadOne = new Thread(myThread);
        Thread threadTwo = new Thread(myThread);
        Thread threadThree = new Thread(myThread);
        threadOne.start();
        threadTwo.start();
        threadThree.start();
    }
}
	</pre>		
	</div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread-1 running
Thread-0 running
Thread-2 running	
		</pre>
	</div>	   
<br>    

<div id="solution">
		<h4>3) Acquire a <b><i>lock</b></i> in Java using ReentrantLock tryLock()</h4>
        <p>The previous example doesn't really provide a compelling reason for you to choose to use a Lock instance instead of traditional
		synchronization. One of the very powerful features is the ability to attempt (and fail) to acquire a lock.<br><br>
		A thread can also acquire a <b><i>lock</b></i> on a block of code using <b><i>java.util.concurrent.locks.ReentrantLock tryLock()</b></i> method.
        It has following signature : <b><i>public boolean tryLock()</b></i> & it acquires the <b><i>lock</b></i> only if it 
		is not held by another thread at the time of invocation. <br><br>
        In below example multiple threads cannot execute the block of code of instance for which lock has been acquired.
        However those threads will not be blocked and could do something else in the meantime.
        </p> 
	</div>
	
	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Producer {
    private String data;
			
    public void produce() {
        data = "data";
    }
}

public class MyThread implements Runnable {
    private Producer producer;
    private Lock lock = new ReentrantLock();
    
    public MyThread(Producer producer) {
        this.producer = producer;
    }
	
    public void run() {
        boolean locked = false;    
        try {
            locked = lock.tryLock(); // try without waiting
            if (locked) {
                System.out.println(Thread.currentThread().getName()  + " running");
                producer.produce();
                Thread.sleep(2000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            if (locked) {        
                lock.unlock();
            }
        }
    }
    
    public static void main(String[] args) {
        MyThread myThread = new MyThread(new Producer());
        Thread threadOne = new Thread(myThread);
        Thread threadTwo = new Thread(myThread);
        Thread threadThree = new Thread(myThread);
        threadOne.start();
        threadTwo.start();
        threadThree.start();
    }
}
	</pre>		
	</div>
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread-0 running
		</pre>
	</div>	    	


<div id="comments">
		<h4>Java lock vs synchronized</h4>
		<ul>
            <li>One of the very powerful features of using Java <b><i>lock</b></i> is the ability to attempt (and fail) to acquire a <b><i>lock</b></i>.
            With traditional synchronization, once you hit a <b><i>synchronized</b></i> block, your thread either immediately acquires the 
            <b><i>lock</b></i> or blocks until it can.</li>
			<li>There is also a variation of the <b><i>tryLock</b></i> method that allows you to specify an amount of time you are willing to wait to 
            acquire the <b><i>lock</b></i>.</li>
			<li>Another benefit of the <b><i>tryLock</b></i> method is you can avoid deadlock. With traditional synchronization, you must acquire locks 
            in the same order across all threads. You can always check if <b><i>lock</b></i> is acquired when using Java <b><i>lock</b></i> by calling
            <b><i>tryLock</b></i>.</li>
			<li>One drawback of using Java <b><i>lock</b></i> is that you always follow the <b><i>lock()</b></i> method with a try-finally block, 
            which releases the <b><i>lock</b></i>.</li>
        </ul>
	</div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
References : <br>
	<ul>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/ReentrantLock.html">Oracle Docs ReentrantLock
        </a>
        </li><br>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/ReentrantLock.html#lock--">Oracle Docs ReentrantLock lock()
        </a>	</li><br>	
        <li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/ReentrantLock.html#tryLock--">Oracle Docs ReentrantLock 
        tryLock()  </a>	</li><br><br>
	</ul>

	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
	
</body>
</html>
