<?php 
    include("header.htm");
?>

<head>
    <title>Java StringJoiner</title>
	<meta name="description" content="Java StringJoiner" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_j8_stringjoiner" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
    <div id="blog" style="float:left;">
	<div id="problem">
		<h1>Java StringJoiner examples</h1>
	</div><br>
	
	<div id="solution">
		<h2>1) StringJoiner example that shows how to add elements using <b><i>add(CharSequence newElement).</b></i></h2>
        <p>Below <b><i>StringJoiner</b></i> example constructs String "[Harry,Sally,John]"</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Java StringJoiner example
import java.util.StringJoiner;
    
public class TestClass { 
    public static void main(String[] args) {
        StringJoiner joiner = new StringJoiner(",");
        joiner.add("Harry")
        .add("Sally")
        .add("John");
        System.out.println(joiner);
    }
}	</pre>
	</div>

    <div id="solution">
		<h3>Output : </h3>
     
	</div>
	
	<div id="code">
		<pre class="prettyprint">
[Harry:Sally:John]        </pre>
	</div>	
    <br>
    
	<div id="solution">
		<h2>2) StringJoiner example that shows how to add elements using <b><i>add(CharSequence newElement) using prefix and suffix.</b></i></h2>
        <p>Below <b><i>StringJoiner</b></i> example constructs String "[Harry:Sally:John]"</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Java StringJoiner example    
import java.util.StringJoiner;
    
public class TestClass { 
    public static void main(String[] args) {
        StringJoiner joiner = new StringJoiner(":", "[", "]");
        joiner.add("Harry")
        .add("Sally")
        .add("John");
        System.out.println(joiner);
    }
}	</pre>
	</div>

    <div id="solution">
		<h3>Output : </h3>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Harry,Sally,John        </pre>
	</div>
<br>	
    
	<div id="solution">
		<h2>3) StringJoiner example that shows how to create formatted output from a Stream using Collectors.joining(CharSequence).</b></i></h2>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Java StringJoiner example    
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

    
public class TestClass { 
    public static void main(String[] args) {
        List&lt;Integer&gt; numbers = Arrays.asList(10, 11, 12, 13);
        String commaSeparatedNumbers = numbers.stream()
        .map(i -> i.toString())
        .collect(Collectors.joining(", ")); // internally uses StringJoiner
        System.out.println(commaSeparatedNumbers);
    }
}	</pre>
	</div>

    <div id="solution">
		<h3>Output : </h3>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
10, 11, 12, 13        </pre>
	</div>	
    <br>    

	<div id="solution">
		<h2>4) StringJoiner example that shows how to merge one StringJoiner object with another using StringJoiner merge().</b></i></h2>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.StringJoiner;
   
public class TestStringJoinerMerge { 
    public static void main(String[] args) {
        StringJoiner joiner = new StringJoiner(",");
        joiner.add("Harry")
        .add("Sally")
        .add("John");
        StringJoiner joiner2 = new StringJoiner(":");
        joiner.add("Ginger")
        .add("Jasmine")
        .add("Mike");
        
        joiner.merge(joiner2);
        System.out.println(joiner);
    }
}	</pre>
	</div>

    <div id="solution">
		<h3>Output : </h3>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Harry,Sally,John,Ginger,Jasmine,Mike        </pre>
	</div>	
    <br>    

<div id="solution">
		<h2>5) String Join example that shows how to add elements using <b><i>join(CharSequence delimiter, CharSequence... elements).</b></i></h2>
        <p>Below StringJoiner example constructs String "[Harry,Sally,John]"</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
public class TestClass { 
    public static void main(String[] args) {
        String message = String.join("-", "Boy", "and", "Girl");
        System.out.println(message);
    }
}	</pre>
	</div>

    <div id="solution">
		<h3>Output : </h3>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Boy-and-Girl        </pre>
	</div>	
    
     <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
 <br>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/StringJoiner.html">Oracle Docs StringJoiner</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html#joining-java.lang.CharSequence-">Oracle Docs Collectors joining()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/lang/String.html#join-java.lang.CharSequence-java.lang.CharSequence...-">Oracle Docs String join()</a> <br><br>
	
    </div> <!-- blog div-->
    
    <div id="sidebar">
	       <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>
    <?php include("../sidebar/ad.htm"); ?>
    
	</div> <!-- sidebar div -->
    
    </div> <!-- content div -->
	
<?php 
    include("footer.htm");
?>
	
</body>
</html>
