<?php 
    include("../header.htm");
?>

<head>
    <title>Java Executor and ExecutorService examples</title>
	<meta name="description" content="Java Executor and ExecutorService examples" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-executor" />
</head>


<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Java Executor and ExecutorService examples</h1>
        <p>
        When you need more then one <code>Thread</code> to process multiple tasks in Java, you typically create multiple 
        <code>Threads</code> and start them using new <code>Thread(r).start()</code>. But this way you need to manage 
        <code>Thread</code> life cycle and you can't tune number of threads you actually need to perform the tasks. 
        This is where <code>java.util.Executor</code> comes in very useful. You can use your choice of implementation
        of <code>Executor</code> interface and thus it lets you decouple the submission of task to execution of task.
        </p>
	</div>
    
    <div id="solution">
		<h2>1) Examples of Executor interface implementation</h2>
        <h3>Executor that executes task asynchronously</h3>
         <p>In below example we implement <code>Executor</code> which starts a new thread for each submitted task.
         A task is submitted by calling <code>Executor execute(Runnable r)</code> which accepts a <code>Runnable</code> type argument.
         </p>
	</div>
    
	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.Executor;

public class TaskExecutor implements Executor {
    public void execute(Runnable r) {
        new Thread(r).start();
    }
	
    public static void main(String[] args) {
        TaskExecutor taskExecutor = new TaskExecutor();
        Runnable runnable = () -> {System.out.println("Thread implementing Runnable started");};
            
        taskExecutor.execute(runnable);
    }
}    </pre>	</div>
 
    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread implementing Runnable started		</pre></div><br>
    <div id="solution">
		<h3>Executor that executes task synchronously</h3>
        <p>Its not necessary that each submitted task would be run asynchronously. You can call <code>Runnable run()</code> inside the <code>execute</code> method to make the task run synchronously.</p>
	</div>
    
	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.Executor;

public class TaskExecutor implements Executor {
    public void execute(Runnable r) {
        r.run();
    }
	
    public static void main(String[] args) {
        TaskExecutor taskExecutor = new TaskExecutor();
        Runnable runnable = () -> {System.out.println("Thread implementing Runnable started");};
            
        taskExecutor.execute(runnable);
    }
}    </pre></div>
 
    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread implementing Runnable started		</pre></div><br>    

    <div id="solution">
		<h2>2) ExecutorService and Executors examples</h2>
        <p>
        There are various useful <code>Executor</code> implementations provide by <code>Executors</code> class is a factory of <code>Executor</code> which returns <code>ExecutorService</code> type that extends <code>Executor</code>.
        </p>
        <p>Below are some of the important <code>Executor</code> implementations:
        <ul>
            <li><code>newSingleThreadExecutor()</code> returns an <code>Executor</code> with single thread. If there are more than one tasks submitted, only one task will be active and others will be put in a queue.
            </li>
            <li><code>newFixedThreadPool()</code> returns an <code>Executor</code> with fixed number of threads. If there are more tasks submitted than the thread pool size, then rest of the tasks will be put in a queue.
            </li>
            <li><code>newCachedThreadPool()</code> returns an <code>Executor</code> which creates new Thread as needed and put into a pool. Threads that are not used for sixty seconds are terminated and removed from the cache.
            </li>
            <li><code>newSingleThreadScheduledExecutor()</code> returns an <code>Executor</code> which will schedule the task to run after a certain interval.
            </li>
        </ul>
        An <code>Executor</code> will accept a <code>Runnable</code> in <code>submit(Runnable r)</code> method which can be created as below using Lambda expression
        </p>
	</div>
    
<div id="code">
    <pre class="prettyprint">
() -> System.out.println("Thread started")
</pre></div>
Below is the equivalent code:
<div id="code">
    <pre class="prettyprint">
public class MyClass implements Runnable {
    public void run() {
        System.out.println("Thread started");
    }
}    
</pre></div>

	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
    
public class ExecutorServiceExample {
	
    public static void main(String[] args) {
       
        // fixed thread pool with four threads
        ExecutorService service = Executors.newFixedThreadPool(4); 
        service.submit(() -> System.out.println("Thread started"));
        
        // cached thread pool
        service = Executors.newCachedThreadPool(); 
        service.submit(() -> System.out.println("Thread started"));
        
         // single thread pool
        service = Executors.newSingleThreadExecutor(); 
        service.submit(() -> System.out.println("Thread started"));
        service.shutdown();
        
        ScheduledExecutorService scheduledExecutorService
            = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.schedule(() -> System.out.println("Thread scheduled started"),
            2000, TimeUnit.MILLISECONDS);
            
        scheduledExecutorService.scheduleAtFixedRate(() 
            -> System.out.println("Thread scheduleAtFixedRate started"),
            1000, 2000, TimeUnit.MILLISECONDS);

    }
}    </pre></div>
    
    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread started
Thread started
Thread started
Thread scheduleAtFixedRate started
Thread scheduled started
Thread scheduleAtFixedRate started
Thread scheduleAtFixedRate started    </pre></div><br>

    <h3><i>ExecutorService</b></i> invokeAll() and invokeAny() example</h3>
    <p>
    <code>invokeAll()</code> will take multiple <code>Callable</code> instances and start running all the tasks while 
    <code>invokeAny()</code> will take multiple <code>Callable</code> instances and returns the result of the task which is completed successfully.
    </p>
    
    <div id="code">
		<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
    
public class ExecutorServiceExample {
	
    public static void main(String[] args) {
       
        ExecutorService service = Executors.newFixedThreadPool(2); 
        List&lt;Callable&lt;String>> tasks = new ArrayList&lt;>();
        tasks.add(() -> "task1");
        tasks.add(() -> "task2");
        service = Executors.newFixedThreadPool(2);
        try {
            service.invokeAll(tasks);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        tasks.forEach(task -> {
            try {
                System.out.println(task.call());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        
        service.shutdown();

        service = Executors.newFixedThreadPool(2);
        try {
            System.out.println(service.invokeAny(tasks));
        } catch (InterruptedException | ExecutionException e1) {
            e1.printStackTrace();
        }
        
        service.shutdown();
    }

}    </pre></div>
    
    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
task1
task2  </pre></div><br>
    

    <div id="solution">
        <h2>3) Shutting down ExecutorService</h2>
		<h3><i>ExecutorService</b></i> shutdown() example</h3>
        <p><code>shutdown()</code> will stop all the threads which are executed successfully and will not accept new tasks</p>
	</div>  
    
	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
    
public class MyThread implements Runnable {
    public void run() { 
        System.out.println(Thread.currentThread().getName()  + " started"); 
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()  + " complete"); 
    }
	
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        
         // single thread pool
        ExecutorService service = Executors.newSingleThreadExecutor(); 
        service.submit(myThread);
        service.shutdown();
        
        service.submit(myThread);
    }
}    </pre></div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
pool-1-thread-1 started
Exception in thread "main" java.util.concurrent.RejectedExecutionException: Task java.util.concurrent.FutureTask@10dea4e 
rejected from java.util.concurrent.ThreadPoolExecutor@647e05 [Shutting down, pool size = 1, active threads = 1, queued tasks = 0, completed tasks = 0]
    at java.util.concurrent.ThreadPoolExecutor$AbortPolicy .rejectedExecution(Unknown Source)
    at java.util.concurrent.ThreadPoolExecutor .reject(Unknown Source)
    at java.util.concurrent.ThreadPoolExecutor .execute(Unknown Source)
    at java.util.concurrent.AbstractExecutorService .submit(Unknown Source)
    at java.util.concurrent. Executors$DelegatedExecutorService.submit(Unknown Source)
    at MyThread.main(MyThread.java:24)
pool-1-thread-1 complete 		</pre></div><br>
    
    <div id="solution">
		<h3>ExecutorService shutdownNow() example</h3>
        <p>
        <code>shutdownNow()</code> will stop all the running threads and will return list of the tasks that were awaiting execution
        In below example observe that first thread sleeps and is immediately shutdown and is not allowed to complete the task.
        </p>
	</div>  
    
	<div id="code">
    <pre class="prettyprint">
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
    
public class MyThread implements Runnable {
    public void run() { 
        System.out.println(Thread.currentThread().getName()  + " started"); 
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName()  + " complete"); 
    }
	
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        
         // single thread pool
        ExecutorService service = Executors.newSingleThreadExecutor(); 
        service.submit(myThread);
        service.shutdownNow();
    }
}    </pre></div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
java.lang.InterruptedException: sleep interrupted
    at java.lang.Thread.sleep(Native Method)
    at MyThread.run(MyThread.java:8)
    at java.util.concurrent.Executors$RunnableAdapter.call (Unknown Source)
    at java.util.concurrent.FutureTask.run(Unknown Source)
    at java.util.concurrent.ThreadPoolExecutor .runWorker(Unknown Source)
    at java.util.concurrent.ThreadPoolExecutor$Worker .run(Unknown Source)
    at java.lang.Thread.run(Unknown Source)
pool-1-thread-1 started
pool-1-thread-1 complete
		</pre>
	</div>
    
<br>
	
   
References : <br>
	<ul>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/Executor.html" target="_blank">Oracle Docs Executor </a></li><br>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/Executors.html" target="_blank">Oracle Docs Executors </a>	</li><br>	
        <li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/ExecutorService.html" target="_blank">Oracle Docs ExecutorService </a>	</li><br><br>
	</ul>
    
	<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
	
</body>
<?php 
    include("footer.htm");
?>

</html>
