<?php 
    include("header.htm");
?>

<head>
    <title>Convert XML to JSON in Java</title>
	<meta name="description" content="Convert XML to JSON in Java" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_XMLToJSON">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
    <div id="content">
    <div id="blog">
	<div id="problem">
		<h2>Convert XML to JSON in Java</h2>
	</div>
	<div id="solution">
		<h4>Using JSON-Java library (json.jar), you need to download <a href="https://jar-download.com/artifacts/org.json">json-20180813.jar </a></h4>
	</div>
    
	<div id="solution">
		<h4>XML content</h4>
	</div>
	<div id="code">
    <pre class="prettyprint">
&lt;person&gt;
    &lt;firstName&gt;Harry&lt;/firstName&gt;
    &lt;lastName&gt;Potter&lt;/lastName&gt;
    &lt;addresses&gt;
	&lt;address&gt;
	&lt;city&gt;London&lt;/city&gt;
	&lt;/address&gt;
	&lt;address&gt;
	&lt;city&gt;New York&lt;/city&gt;
	&lt;/address&gt;
    &lt;/addresses&gt;
&lt;/person&gt;
	</pre>
    </div>
    
	<div id="solution">
		<h4>Expected JSON</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
{"person":
    {
        "firstName": "Harry",
        "lastName": "Potter",
        "addresses": 
            {"address":[
                { "city" : "London" },
                { "city" : "New York" }
            ]
        }
    }
}
    </pre>
	</div>
	
	<div id="solution">
		
	</div>
	
	<div id="code">	
    <pre class="prettyprint">
//Converts XML to JSON
import org.json.JSONException;
import org.json.XML;
	
public class XMLToJSON {
    public static void main(String[] args) throws JSONException {
        String xml = "&lt;person&gt;" +
        "&lt;firstName&gt;Harry&lt;/firstName&gt;" +
        "&lt;lastName&gt;Potter&lt;/lastName&gt;" +
        "&lt;addresses&gt;" +
        "&lt;address&gt;" +
        "&lt;city&gt;London&lt;/city&gt;" +
        "&lt;/address&gt;" +
        "&lt;address&gt;" +
        "&lt;city&gt;New York&lt;/city&gt;" +
        "&lt;/address&gt;" +
        "&lt;/addresses&gt;" +
        "&lt;/person&gt;";<br>
        System.out.println(XML.toJSONObject(xml).toString());<br>
    }
}
    </pre>	
	</div>
	
    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
{"person":
{"firstName":"Harry",
"lastName":"Potter",
"addresses":
{"address":[{"city":"London"},
{"city":"New York"}]}}}


    </pre>
	</div>
<!-- ADU1 -->
<?php include("../sidebar/ad.htm"); ?>

    <br>
 
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
</body>
<?php 
    include("footer.htm");
?>

</html>
