<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 -Xms -Xmx</title>
	<meta name="description" content="-Xms -Xmx java 8, java options -Xmx." />
	<link rel="canonical" href="https://www.techblogss.com/java/java8-xmx-xms" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
   
	<div id="problem">
		<h2>Java 8 Heap sizing</h2>
	</div>
	<h3>1) Java 8 -Xms -Xmx options</h3>
	<div id="solution">
		<p>If the heap is too small, the application will spend too much time in performing <b><i>GC (Garbage collection)</b></i> instead of performing
		application logic and if JVM sees it is doing too much GC with the initial heap size, it will keep it increasing till it finds a 
		suitable value or it hits maximum size. 
		</p>
		<p>
		But if the heap is too large, <b><i>GC (Garbage collection)</b></i> will be performed less frequently but duration of pauses
		will increase and will cause performance issues.
		</p>
		<p>
		You can control the size of heap by two values: an initial value using <b><i>-Xms</b></i> flag and a maximum value using 
		<br><b><i>-Xms</b></i> flag.
		</p>
        <h4>Client JVM machine Initial and Maximum Heap Sizes</h4>
		<p>
		For client JVM machine, the default maximum heap size is half of the physical memory up to a physical memory size of 192 megabytes (MB)
		else one fourth of the physical memory up to a physical memory size of 1 gigabyte (GB).
		</p>
		
		<h4>Server JVM machine Initial and Maximum Heap Sizes</h4>
		<p>
		For server JVM machine on 32-bit JVMs, the default maximum heap size can be up to 1 GB if there is 4 GB or more of physical memory,
		while on 64-bit JVMs, the default maximum heap size can go up to 32 GB if there is 128 GB or more of physical memory. 
		</p>
		<h4>Specifying Initial and Maximum Heap Sizes</h4>
		<p>
		You can specify the initial and maximum heap sizes using the flags <b><i>-Xms</b></i> (initial heap size) and <b><i>-Xms</b></i>
		(maximum heap size). If you don't specify <b><i>-Xms</b></i> value, and application doesn't need a larger heap than the default maximum,
		it is fine.
		</p>
		<p>
		But if the application is spending too much time in GC, then the heap size will need to be increased by setting <b><i>-Xmx</b></i> 
		flag. On the other hand if you know exactly what heap your application needs, then you can set <b><i>-Xms</b></i> and <b><i>-Xms</b></i> 
		to the same value. That makes GC bit more efficient, as it never needs to figure out whether the heap should be increased.
		</p>		
	</div>
	
	<h4>Few examples of -Xms -Xmx </h4>
	<div id="code">
    <pre class="prettyprint">
java -Xms512m -Xmx1024m

java -Xms512m -Xmx2g
    </pre>
	</div>
	<br>
    
	<div id="solution">
	<h3>2) Sizing the Generations</h3>
	<p>You can also decide how much of heap should be allocated to young and old generations using below flags. The default <b><i>NewRatio</b></i>
	for the Server JVM is 2. The old generation occupies 2/3 of the heap while the new generation occupies 1/3.</p>
	<ul>
		<li><b><i>-XX:NewRatio</b></i>=2 set the ratio of the young generation to the old generation</li>
		<li><b><i>-XX:NewSize</b></i>=512m set the initial size of the young generation</li>
		<li><b><i>-XX:MaxNewSize</b></i>=1024m set the maximum size of the young generation</li>
		<li><b><i>-Xmn</b></i>1024m set the size of both NewSize and MaxNewSize to the same value</li>
	</ul>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
java -Xms512m -Xmx1024m -XX:NewRatio=2 -XX:NewSize=512m
    </pre>
	</div>
	
	<br>
	<div id="solution">
	<h3>3) Sizing Permgen</h3>
	<p>The metadata of the the classes loaded by JVM is stored in seperate heap space called <b><i>permgen (permanent generation)</b></i>.
	In Java 8, this is called as the <b><i>metaspace</b></i>.
	</p>
	
	<p>
	For example for <b><i>permgen</b></i>, the size is specified using <b><i>-XX:PermSize=512m</b></i> and <b><i>-XX:MaxPermSize=1024m.</b></i> 
	For <b><i>metaspace</b></i>, the size is specified using <b><i>-XX:MetaspaceSize=512m</b></i> and <b><i>-XX:MaxMetaspaceSize=1024m</b></i>  
	</p>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
java -Xms512m -Xmx1024m -XX:PermSize=2 -XX:MaxPermSize=512m
    </pre>
	</div>
    
    <br>
    <p>View this page to see various GC mechanisms</p>
    <a href="https://www.techblogss.com/java/java8-garbage-collection-algorithms" target="_blank">GC Algorithms</a>
    
         <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
	
	<br>
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/technotes/guides/vm/gc-ergonomics.html" target="_blank">Garbage Collector Ergonomics</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/technotes/guides/vm/gctuning/parallel.html#default_heap_size" target="_blank">Default heap size</a>	<br><br>
<a href="https://docs.oracle.com/cd/E19900-01/819-4742/abeik/index.html" target="_blank">Heap Tuning Parameters</a>	<br><br>
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
	<div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>