<?php include("../header.htm");?>

<head>
    <title>Java 8 Stream convert list to map</title>
	<meta name="description" content="Java 8 Stream convert list to map" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-stream-convert-list-to-map" />
</head>

<body>
	<?php include("../navigation.htm");?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h2>Java 8 Stream convert List to Map</h2>
    </div> 

	<div id="solution">
        <p>Below example shows how to convert a <code>List</code> to <code>Map</code> in Java 8 using Stream. Suppose we have a <code>List</code> 
        of students and we want to construct a <code>Map</code> with <code>key</code> as student rollnumber and <code>value</code> as student name, 
        you can do it as below:</p>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
	
class Student {
    private int rollNumber;
    private String name;
    private int age;
	
    Student (int rollNumber, String name, int age) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.age = age;
    }
    
    // removed getters and setter for brevity    
   
    @Override
    public String toString() {
        return "Student [rollNumber=" + rollNumber + ", name=" + name + ", age="+ age + "]";
    }
}
</pre>
	</div>
    
    <div id="code">
	<pre class="prettyprint">
// Converts List to Map using Java 8 Collectors toMap() method
public class ListToMapConverter { 

    public static void main(String[] args) {
	
        List&lt;Student&gt; students = new ArrayList&lt;Student&gt;();
        students.add(new Student(1, "John", 13));
        students.add(new Student(2, "Mark", 14));
        students.add(new Student(3, "Henry", 13));
			
        Stream&lt;Student&gt; studentStream = students.stream();
        Map&lt;Integer, String&gt; rollNumberNameMap = 
        studentStream.collect(Collectors.toMap(Student::getRollNumber, Student::getName));
        System.out.println(rollNumberNameMap);  
    }
}	</pre></div>

    <div id="solution">
		<h4>Output : </h4>
    </div>
	
	<div id="code">
		<pre class="prettyprint">
{1=John, 2=Mark, 3=Henry}        </pre></div><br>

   
    <div id="solution">
		<p>Suppose you have duplicate keys and you create a <b><i>Map</b></i> from the <i>List</i> of Student, you will get
        <code>IllegalStateException</code> (Duplicate Key).</p>
	</div>


	<div id="code">
	<pre class="prettyprint">
// Throws IllegalStateException
public class ListToMapConverter { 

    public static void main(String[] args) {
			
        List&lt;Student&gt; students = new ArrayList&lt;Student&gt;();
        students.add(new Student(1, "John", 13));
        students.add(new Student(2, "Mark", 14));
        students.add(new Student(3, "Henry", 13));
        students.add(new Student(1, "James", 15)); //oops student with same rollNumber
			
        Map&lt;Integer, String&gt; rollNumberNameMap = 
            students.stream().collect(Collectors.toMap(Student::getRollNumber, Student::getName));
        System.out.println(rollNumberNameMap); 
    }
}	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Exception in thread "main" java.lang.IllegalStateException: Duplicate key John
	at java.util.stream.Collectors.lambda$throwingMerger$0(Unknown Source)
	at java.util.HashMap.merge(Unknown Source)	</pre></div>	
<br>
    <p>To resolve duplicate key isse, you need to pass <code>mergeFunction</code> as an argument that will resolve collision between values.</p>
	<div id="code">
	<pre class="prettyprint">
public class ListToMapConverter { 

    public static void main(String[] args) {
        // create students list
			
        Stream&lt;Student&gt; studentStream = students.stream();
        Map&lt;Integer, String&gt; rollNumberNameMap = 
            studentStream.collect(Collectors.toMap(Student::getRollNumber,
            Student::getName, (k1, k2) -> {return k1;}));
        System.out.println(rollNumberNameMap); 
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
{1=John, 2=Mark, 3=Henry}	</pre></div><br>
    
        
	<div id="solution">
		<p>Another example that shows how to convert List to Map with key as rollNumber and value as List of Students.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
public class ListToMapConverter { 

    public static void main(String[] args) {
        // create students list
			
        Map&lt;Integer, List&lt;Student&gt;&gt; rollNumberNameMap = 
            students.stream().collect(Collectors.toMap(Student::getRollNumber, Function.identity()));
        System.out.println(rollNumberNameMap); 
        
        rollNumberNameMap = students.stream().collect(Collectors.toMap(Student::getRollNumber,
            p -> p));
        System.out.println(rollNumberNameMap); 
    }
}	</pre>
	</div>


    <div id="solution">
		<h4>Console Output : </h4>
    </div>
	
	<div id="code">
		<pre class="prettyprint">
{1=Student [rollNumber=1, name=John, age=13], 2=Student [rollNumber=2, name=Mark, age=14], 3=Student [rollNumber=3, name=Henry, age=13]}
{1=Student [rollNumber=1, name=John, age=13], 2=Student [rollNumber=2, name=Mark, age=14], 3=Student [rollNumber=3, name=Henry, age=13]}</pre>
	</div>	
    <br>
    
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html" target="_blank">Oracle Docs Collectors</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html#groupingBy-java.util.function.Function-" target="_blank">Oracle Docs Comparator Collectors groupingBy()</a>	<br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
