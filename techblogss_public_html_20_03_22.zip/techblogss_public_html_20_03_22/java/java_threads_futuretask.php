<?php 
    include("../header.htm");
?>

<head>
    <title>Java Callable and FutureTask example</title>
	<meta name="description" content="Java Callable and FutureTask example" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_threads_futuretask">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
    <div id="problem">
        <h1>Java Callable and FutureTask example</h1>
        <h2>1.Java Callable example</h2>
    </div>
    
    <h4>Implementing Callable Interface</h4>		
	<div id="code">
	<pre class="prettyprint">
// Java Callable example
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
			
public class MyThread implements Callable&lt;String&gt; {

    public String call() throws Exception { 
        return "Thread implementing Callable started";
    }
	
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        FutureTask&lt;String&gt; futureTask = new FutureTask<>(myThread);
        futureTask.run();
        
        try {
            System.out.println(futureTask.get());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}	</pre>	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread implementing Callable started		</pre>	</div>	<br>

	<div id="code">
	<pre class="prettyprint">
// Java Callable example to calculate factorial of a number
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
			
public class MyThread implements Callable&lt;Integer&gt; {

    private int number;
    
    public MyThread(int number) {
        this.number = number;
    }	
	
    public Integer call() throws Exception { 
        int factorial = 1;
        for (int counter = number; counter > 1; counter--) {
            factorial = factorial * counter;
        }
 
        return factorial;
    }
	
    public static void main(String[] args) {
        MyThread myThread = new MyThread(10);
        FutureTask&lt;Integer&gt; futureTask = new FutureTask<>(myThread);
        futureTask.run();
        
        try {
            System.out.println(futureTask.get());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
3628800
		</pre></div> <br>

	<div id="problem">
		<h2>2. FutureTask example</h2>
	</div>
    <div id="solution">
        <p>A <b><i>FutureTask</b></i> is used for cancellable asynchronous computation. <b><i>FutureTask</b></i> provides methods to start and cancel a computation,
        query to see if the computation is complete, and retrieve the result of the computation.
        The results from a <b><i>FutureTask</b></i> can only be retrieved when the computation is complete. The methods used to retrieve the result
        will block if the computation has not yet completed.
        </p> 
	</div>

<h4>1) Below example shows FutureTask example</h4>	
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class FutureTaskExample {
    public static void main(String[] args) {
        ExecutorService es = Executors.newSingleThreadExecutor();
        Factorial task = new Factorial(10);
        Future&lt;Long> future = es.submit(task);
        
        while (!future.isDone()) { 
            System.out.println("Task is in progress");
            try {
                Thread.sleep(500); //sleep for 500 millisecond before checking again
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        long result = 0;
        try {
            result = future.get(); // blocking call
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    
        System.out.printf("factorial of 10 is %d", result);
        es.shutdown();
    }
}

class Factorial implements Callable&lt;Long> {
    private long number;

    public Factorial(long number) {
        this.number = number;
    }

    @Override
    public Long call() throws Exception {
        long fact = 1;
        for (long cnt = 1; cnt &lt;= number; cnt++) {
            fact *= cnt;
            Thread.sleep(500);
        }
        return fact;
    }
}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Task is in progress
Task is in progress
Task is in progress
Task is in progress
Task is in progress
Task is in progress
Task is in progress
Task is in progress
Task is in progress
Task is in progress
Task is in progress
factorial of 10 is 3628800
		</pre>
	</div>		
	<br>
<h4>2) FutureTask example with timeout</h4>
<p>Since <b><i>FutureTask get()</b></i> is a blocking call & for some operations it may sometimes take long time. So in case you want the response within a time of say 2 sec, you can use another method
<b><i>get(long timeout, TimeUnit unit)</b></i>  where you can pass time for computation to complete. Below example shows <b><i>FutureTask get()</b></i> example with timeout.</p>	
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class FutureTaskExample {
    public static void main(String[] args) {
        ExecutorService es = Executors.newSingleThreadExecutor();
        Factorial task = new Factorial(10);
        Future&lt;Long> future = es.submit(task);
        
        long result = 0;
        try {
            result = future.get(2, TimeUnit.SECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            e.printStackTrace();
        }
    
        System.out.printf("factorial of 10 is %d", result);
        es.shutdown();
    }
}

class Factorial implements Callable&lt;Long> {
    private long number;

    public Factorial(long number) {
        this.number = number;
    }

    @Override
    public Long call() throws Exception {
        long fact = 1;
        for (long cnt = 1; cnt &lt;= number; cnt++) {
            fact *= cnt;
            Thread.sleep(500);
        }
        return fact;
    }
}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
java.util.concurrent.TimeoutException
	at java.util.concurrent.FutureTask.get(Unknown Source)
	at threads.FutureTaskExample.main(FutureTaskExample.java:19)
factorial of 10 is 0
		</pre>
	</div>	
    <br>

    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/Callable.html">Oracle Docs Callable</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/FutureTask.html">Oracle Docs FutureTask</a>	<br><br>
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>
