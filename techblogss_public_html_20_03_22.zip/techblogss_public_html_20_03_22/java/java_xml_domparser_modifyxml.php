<?php 
    include("header.htm");
?>

<head>
    <title>Modify XML file in java using DOM parser</title>
	<meta name="description" content="Modify XML file in java using DOM parser" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_xml_domparser_modifyxml">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>

    <div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Modify XML file in java using DOM parser</h1>
        You can modify the contents of a XML file using DOM Parser. You can modify, remove, add elements, attributes of XML file using DOM Parser.<br>
	</div>
	<br>
	<div id="solution">
		XML file that you want to modify: <b>employees.xml</b> 
	</div>

	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
&lt;employees>
    &lt;employee id="123">
        &lt;firstname>Mohit&lt;/firstname>
        &lt;lastname>Bisht&lt;/lastname>
	&lt;/employee>
    &lt;employee id="456">
        &lt;firstname>Samit&lt;/firstname>
        &lt;lastname>Ahlawat&lt;/lastname>
    &lt;/employee>
&lt;/employees>
	</pre>
	</div>
    
    <br>
    <h4>1) Add new element in XML file with nodes and text value & update an existing element</h4>
	<p>Below example shows how to add new element with id = "345" & update firstname of element with id="123"</p>
	<div id="code">
	<pre class="prettyprint">
// Modifies XML file    
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
				
public class ModifyXMLDOMParser {
    public static void main(String[] args) {
        try {
            File inputFile = new File("E:\\employees.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
                
            // update firstname of element with id="123"
            NodeList employees = doc.getElementsByTagName("employee");
            for(int i=0; i&lt;employees.getLength();i++){
                Element emp = (Element) employees.item(i);
                Node name = emp.getFirstChild();
                if ("Mohit".equalsIgnoreCase(name.getNodeValue())) {
                    name.setNodeValue("Mickey");
                }
            }
                
            // add new element with id = "345".
            Element employee = doc.createElement("employee");
            employee.setAttribute("id", "345");
            Element node1 = doc.createElement("firstname");
            node1.appendChild(doc.createTextNode("William"));
            employee.appendChild(node1);
            Element node2 = doc.createElement("lastname");
            node2.appendChild(doc.createTextNode("Wallace"));
            employee.appendChild(node2);
                
            Element emp = (Element) employees.item(0);
            emp.appendChild(employee);
                
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("E:\\employees.xml"));
            transformer.transform(source, result);
                
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
      
}
	</pre>
	</div>
   
	<div id="solution">
		<h4>Generated XML : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8" standalone="no"?&gt;
&lt;employees&gt;
    &lt;employee id="123"&gt;
        &lt;firstname&gt;Mohit&lt;/firstname&gt;
        &lt;lastname&gt;Bisht&lt;/lastname&gt;
	&lt;/employee&gt;
    &lt;employee id="456"&gt;
        &lt;firstname&gt;Samit&lt;/firstname&gt;
        &lt;lastname&gt;Ahlawat&lt;/lastname&gt;
    &lt;/employee&gt;
    &lt;employee id="345"&gt;
        &lt;firstname&gt;William&lt;/firstname&gt;
        &lt;lastname&gt;Wallace&lt;/lastname&gt;
    &lt;/employee&gt;
&lt;/employees&gt;
    </pre>
	</div>
    
<br> 
    <h4>2) Delete an element in XML file & update atribute value in an existing element</h4>
	<p>Below example shows how to delete an element with attribute id = "123" & update atribute value of element with id="456" to id="789"</p>
	<div id="code">
	<pre class="prettyprint">
// Modifies XML file    
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
				
public class ModifyXMLDOMParser {
    public static void main(String[] args) {
        try {
            File inputFile = new File("E:\\employees.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
                
            NodeList nodeList = doc.getElementsByTagName("employee");
            int index = 0;
            
            for (int i = 0; i &lt; nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    NamedNodeMap nodeMap = node.getAttributes();
                
                    for (int j = 0; j &lt; nodeMap.getLength(); j++) {
                        Node node2 = nodeMap.item(j);
                        if (node2.getNodeName().equalsIgnoreCase("id")) { 
                            if (node2.getNodeValue().equalsIgnoreCase("123")) {
                            	index = i; // get the index of node ned to be removed
                            }
                            if (node2.getNodeValue().equalsIgnoreCase("456")) {
                            	node2.setNodeValue("789"); // update atribute value
                            }
                        }
                    }
                }
            }
            
            // remove element    
            Node node = nodeList.item(index);
            doc.getElementsByTagName("employees").item(0).
                removeChild(node);;
                            
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("E:\\employees.xml"));
            transformer.transform(source, result);
                
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
      
}
	</pre>
	</div>
   
	<div id="solution">
		<h4>Generated XML : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8" standalone="no"?&gt;
&lt;employees&gt;
    &lt;employee id="789"&gt;
        &lt;firstname&gt;Samit&lt;/firstname&gt;
        &lt;lastname&gt;Ahlawat&lt;/lastname&gt;
    &lt;/employee&gt;
&lt;/employees&gt;
    </pre>
	</div>
    
   <!-- ADU1 -->
   <?php include("../sidebar/ad.htm"); ?>
    
    <br>
	References: <br><br>
    <a href="https://docs.oracle.com/javase/tutorial/jaxp/xslt/writingDom.html">https://docs.oracle.com/javase/tutorial/jaxp/xslt/writingDom.html</a><br><br>
    <a href="https://www.techblogss.com/java/java_xml_jdomparser">Parse XML using DOM</a><br>
    <br>	

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
</body>

<?php 
    include("footer.htm");
?>
</html>
