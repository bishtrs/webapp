<?php include("../header.htm");?>

<head>
    <title>Sort HashMap by key or value Java 8</title>
    <meta name="description" content="Sort HashMap in Java 8, Sort HashMap by key in Java 8, Sort HashMap by value in Java 8, Sort HashMap by key or value Java 8" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-sort-hashmap" />
</head>

<body>
    <?php include("../navigation.htm");?>
    <div id="content" >
    <div id="blog">
    <div id="problem">
        <h1>Sort HashMap by key or value Java 8</h1>
        <p>Below examples show how to sort <code>HashMap</code> by key or value Java 8</p>
    </div>

    <div id="solution">
        <h4>1) Sort HashMap by key in Java 8</h4>
        <p>
        To sort <code>HashMap</code> by key, you can use <code>Entry comparingByKey()</code> method which will sort the keys by their natural order. To preserve the key order, you need to collect the ouput <code>Map</code> as <code>LinkedHashMap</code>.
        </p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SortHashMap {

    public static void main(String[] args) {
        Map&lt;String, Integer> map = new HashMap&lt;>();
        map.put("John", 22);
        map.put("Mark", 12);
        map.put("Thomas", 43);
        map.put("James", 34);
        map.put("Edwin", 53);
        map.put("Vinod", 68);
        System.out.println(map);
        Stream&lt;Entry&lt;String, Integer>> stream 
            = map.entrySet().stream().sorted(Map.Entry.comparingByKey());
        LinkedHashMap&lt;String, Integer> sortedMap = stream
                .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), 
                (e1, e2) -> e2, LinkedHashMap::new));
        System.out.println(sortedMap);
    }
}        </pre></div>

<div id="solution"><h4>Console Output : </h4></div>
    
    <div id="code">
        <pre class="prettyprint">
{Thomas=43, James=34, Edwin=53, John=22, Mark=12, Vinod=68}
{Edwin=53, James=34, John=22, Mark=12, Thomas=43, Vinod=68}    </pre></div><br>

    <div id="solution">
        <h4>2) Sort HashMap by value in Java 8</h4>
        <p>
        To sort <code>HashMap</code> by value, you can use <code>Entry comparingByValue()</code> method. 
        </p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SortHashMap {

    public static void main(String[] args) {
       Stream&lt;Entry&lt;String, Integer>> stream 
           = map.entrySet().stream().sorted(Map.Entry.comparingByValue());

       sortedMap = stream.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(),
           (e1, e2) -> e2, LinkedHashMap::new));
	   System.out.println(sortedMap);
    }

}</pre></div>

    <div id="solution"><h4>Console Output : </h4></div>
    
    <div id="code">
        <pre class="prettyprint">
{Mark=12, John=22, James=34, Thomas=43, Edwin=53, Vinod=68} </pre></div>    
    
    <br>
    
    <div id="solution">
        <h4>3) Sort HashMap by value in Java 8 when value is an Object type</h4>
        <p>
        In case the value is an Object, you can pass <code>Comparator.comparing()</code> in <code>comparingByValue()</code> argument.
        </p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SortHashMap {

    public static void main(String[] args) {

        Map&lt;Integer, Book> bookMap = new HashMap&lt;>();
        bookMap.put(1, new Book("Lord of the Rings", "J. R. R. Tolkien"));
        bookMap.put(2, new Book("Silence of the Lambs", "Thomas Harris"));
        bookMap.put(3, new Book("The Bourne Identity", "Robert Ludlum"));
        bookMap.put(4, new Book("Day of the Jackal", "Frederick Forsyth"));
        System.out.println(map);

        Stream&lt;Entry&lt;Integer, Book>> stream = bookMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.comparing(Book::getTitle)));

        LinkedHashMap&lt;Integer, Book> sortedMap = stream
                .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(),
                (e1, e2) -> e2, LinkedHashMap::new));
        System.out.println(sortedMap);

    }

}

class Book {
    private final String title;
    private final String author;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    // getter setter remvoed for brevity

    @Override
    public String toString() {
        return "Book [title=" + title + ", author=" + author + "]";
    }

}    </pre></div>

    <div id="solution"><h4>Console Output : </h4></div>
    
    <div id="code">
        <pre class="prettyprint">
{1=Book [title=Lord of the Rings, author=J. R. R. Tolkien],
 2=Book [title=Silence of the Lambs, author=Thomas Harris],
 3=Book [title=The Bourne Identity, author=Robert Ludlum],
 4=Book [title=Day of the Jackal, author=Frederick Forsyth]}
{4=Book [title=Day of the Jackal, author=Frederick Forsyth],
 1=Book [title=Lord of the Rings, author=J. R. R. Tolkien],
 2=Book [title=Silence of the Lambs, author=Thomas Harris],
 3=Book [title=The Bourne Identity, author=Robert Ludlum]}    </pre></div>    
    
    <br>
    
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
