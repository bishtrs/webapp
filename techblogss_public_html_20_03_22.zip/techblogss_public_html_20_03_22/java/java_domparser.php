<?php 
    include("header.htm");
?>

<head>
    <title>Read XML file in Java using DOM parser</title>
	<meta name="description" content="Read XML file in Java using DOM parser" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_domparser" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>

    <div id="content">
    <div id="blog">
	<div id="problem">
        <h1>Read XML file in java using DOM parser</h1>
        <p><b><i>DOM</b></i> stands for Document Object Model, XML <b><i>DOM</b></i> defines a standard for accessing and manipulating documents.
        <b><i>DOM</b></i> parser parses the entire XML document and creates <b><i>DOM</b></i> objects in the memory in form of a Tree structure. 
        You should use <b><i>DOM</b></i> parser in following scenarios:</p>
        <ul>
            <li>In case of small XML documents, or large number of small XML documents.</li>   
            <li>In case you want to access whole XML.</li>
			<li>For editing the xml as it keeps the DOM structure in memory.</li>
        </ul>
        <h2>1) Read XML file and print node names and values</h2>        
        
	</div>
	
	<div id="solution">
		XML file that you want to read: <b>employees.xml</b>
	</div>

	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version="1.0"?>    
&lt;employees>
    &lt;employee id="123">
	&lt;firstname>Mohit&lt;/firstname>
	&lt;lastname>Bisht&lt;/lastname>
    &lt;/employee>
    &lt;employee id="124">
        &lt;firstname>Samit&lt;/firstname>
        &lt;lastname>Ahlawat&lt;/lastname>
    &lt;/employee>
    &lt;employee id="125">
        &lt;firstname>Vikram&lt;/firstname>
        &lt;lastname>Raheja&lt;/lastname>
    &lt;/employee>
&lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Parses XML file using Java DOM parser and prints node names and values
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
				
public class DOMXMLParser {
    public static void main(String[] args) {
        try {
            File inputFile = new File("C://employees.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = null;
            try {
                dBuilder = dbFactory.newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }
			
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("employee");
                
            for (int i = 0; i &lt; nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                System.out.println("Current Element :" + node.getNodeName());
                
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                
                    System.out.println("Employee id: "  
                        + element.getAttribute("id"));
                    System.out.println("First Name : "
                        + element.getElementsByTagName("firstname")
                        .item(0).getTextContent());
                    System.out.println("Last Name : "
                        + element.getElementsByTagName("lastname")
                        .item(0).getTextContent());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 

    }
}
	</pre>
	</div>
   
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
Current Element :employee
Employee id: 123
First Name : Mohit
Last Name : Bisht
Current Element :employee
Employee id: 124
First Name : Samit
Last Name : Ahlawat
Current Element :employee
Employee id: 125
First Name : Vikram
Last Name : Raheja
    </pre>
	</div>
	
	
	<div id="problem">
        <h2>2) Read XML file and print node attribute values</h2>        
	</div>

	<div id="solution">
		XML file that you want to read: <b>employees.xml</b>
	</div>
	<br>
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version="1.0"?>    
&lt;employees>
    &lt;employee id="123" department="accounts">
	&lt;firstname>Mohit&lt;/firstname>
	&lt;lastname>Bisht&lt;/lastname>
    &lt;/employee>
    &lt;employee id="124" department="hr">
        &lt;firstname>Samit&lt;/firstname>
        &lt;lastname>Ahlawat&lt;/lastname>
    &lt;/employee>
&lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Parses XML file using Java DOM parser and prints attribute values
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;

				
public class DOMXMLParserReadAttributes {
    public static void main(String[] args) {
        try {
            File inputFile = new File("C://employees.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = null;
            try {
                dBuilder = dbFactory.newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }
			
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("employee");
                
            for (int i = 0; i &lt; nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                System.out.println("Current Element :" + node.getNodeName());
                
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    NamedNodeMap nodeMap = node.getAttributes();
                
                for (int j = 0; j &lt; nodeMap.getLength(); j++) {
                    	Node node2 = nodeMap.item(j);
                    	System.out.println("attribute name : " + node2.getNodeName());
                    	System.out.println("attribute value : " + node2.getNodeValue());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 

    }
}
	</pre>
	</div>
 
<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
Current Element :employee
attribute name : department
attribute value  : accounts
attribute name : id
attribute value  : 123
Current Element :employee
attribute name : department
attribute value  : hr
attribute name : id
attribute value  : 124
    </pre>
	</div> 
    
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>

	References: <br><br>
    <a href="https://www.w3schools.com/xml/dom_intro.asp">https://www.w3schools.com/xml/dom_intro.asp</a><br><br>
    <a href="https://docs.oracle.com/javase/tutorial/jaxp/dom/readingXML.html">https://docs.oracle.com/javase/tutorial/jaxp/dom/readingXML.html</a>
    <br>	
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
</body>

<?php 
    include("footer.htm");
?>
</html>
