<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Spliterator</title>
	<meta name="description" content="Java 8 Spliterator, Spliterator in Java, Spliterator trySplit() example, 
    Spliterator tryAdvance() example, Spliterator forEachRemaining() example." />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-spliterator" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h1>Java 8 Spliterator example</h1>
         <p>A <b><i>Spliterator</b></i> object is used to traverse a collection or stream and it can split the stream source for parallel processing.</p>     
	</div>

	<div id="solution">
		<h4>1) Spliterator trySplit() example </h4>
        
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Spliterator;

public class SpliteratorExample {
    public static void main(String[] args) {
    	 
        List&lt;String> list = Arrays.asList("Mark", "John", "Andrew");

    	Spliterator&lt;String> s2 = list.spliterator();
    	Spliterator&lt;String> s1 = s2.trySplit();
        
        System.out.println("Iterating using first iterator");
    	s2.forEachRemaining(System.out::println);
        System.out.println("Iterating using second iterator");
    	s1.forEachRemaining(System.out::println);
    }
}
	
	</pre>
	</div>

<div id="solution">
		<h4>Console Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Iterating using first iterator
John
Andrew
Iterating using second iterator
Mark
	</pre>
	</div>	
    <br>
	
    <div id="solution">
		<h4>2) Spliterator tryAdvance() example </h4>
        
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Spliterator;

public class SpliteratorExample {
    public static void main(String[] args) {
    	 
        List&lt;String> list = Arrays.asList("Mark", "John", "Andrew");

        Spliterator&lt;String> s = list.spliterator();
        s.tryAdvance(System.out::println);
        s.tryAdvance(System.out::println);
        boolean b = s.tryAdvance(System.out::println);
        System.out.println("Element exists: " + b);

        b = s.tryAdvance(System.out::println);
        System.out.println("Element exists: " + b);
    }
}
	
	</pre>
	</div>

<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Mark
John
Andrew
Element exists: true
Element exists: false
	</pre>
	</div>	
    <br>

   <div id="solution">
		<h4>3) Spliterator forEachRemaining() example </h4>
        
	</div>
	
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Spliterator;

public class SpliteratorExample {
    public static void main(String[] args) {
    	 
        List&lt;String> list = Arrays.asList("Mark", "John", "Andrew");
        Spliterator&lt;String> s = list.spliterator();
        System.out.println("Processing using forEachRemaining");
        s.forEachRemaining(System.out::println);
    }
}
	
	</pre>
	</div>

<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Processing using forEachRemaining
Mark
John
Andrew
	</pre>
	</div>	
    <br>
    
    <br>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Spliterator.html" target="_blank">Oracle Docs Spliterator</a>	<br><br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>
