<?php 
    include("header.htm");
?>

<head>
    <title>Java 8 Collectors</title>
    <meta name="description" content="Java 8 Collectors" />
    <link rel="canonical" href="https://www.techblogss.com/java/java8-collectors" />
</head>

<body>
    <?php 
        include("navigation.htm");
    ?>
    <div id="content" >
        <div id="blog" style="float:left;">
        <div id="problem">
        <h1>Java 8 Collectors examples</h1>
    </div>
    
    <h2>1. Java 8 Collectors Joining example</h2>
    <div id="solution">
        <h4>a) Below example shows how to append list of characters Stream using without any delimiter.</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Stream Collectors Joining example   
package java8;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectorsJoiningExample {

    public static void main(String[] args) {
        char[] ch = { 'Y', 'o', 'u', ' ', 'o', 'w', 'n', ' ', 'y', 'o', 'u', 'r', ' ',
                    'd', 'e', 's', 't', 'i', 'n', 'y'};
        
        String str = Stream.of(ch) 
                        .map(c -> new String(c)) 
                        .collect(Collectors.joining()); 
        System.out.println(str);
    }
}       </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
You own your destiny    </pre>
    </div>    
 <br>
 
    <div id="solution">
        <h4>b) Below example shows how to append list of Ball names obtained from Stream using ',' delimiter.</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Stream Collectors Joining example using delimiter
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CollectorsJoiningExample {

    public static void main(String[] args) {
        Ball tennis = new Ball("tennis", 1, "green");
        Ball footBall = new Ball("football", 2, "white");
        Ball basketBall = new Ball("basketBall", 3, "orange");
        Ball volleyBall = new Ball("volleyBall", 4, "orange");
        
        List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall, volleyBall);
        
        String ballNames = balls.stream()
                .filter(ball -> ball.getSize() > 1)
                .map(Ball::getName)
                .collect(Collectors.joining(","));
        System.out.println("Name of balls greater than size 1 :: " + ballNames);
    }
}       </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
Name of balls greater than size 1 :: football,basketBall,volleyBall   </pre>
    </div>    
 <br> 
 
     <div id="solution">
        <h4>c) Below example shows how to append list of Ball names obtained from Stream using ',' delimiter, '->' as prefix, and '.' as suffix.</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Stream Collectors Joining example using delimiter, prefix, and suffix    
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CollectorsJoiningExample {

    public static void main(String[] args) {
        Ball tennis = new Ball("tennis", 1, "green");
        Ball footBall = new Ball("football", 2, "white");
        Ball basketBall = new Ball("basketBall", 3, "orange");
        Ball volleyBall = new Ball("volleyBall", 4, "orange");
        
        List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall, volleyBall);
        
        String ballNames = balls.stream()
                .filter(ball -> ball.getSize() > 1)
                .map(Ball::getName)
                .collect(Collectors.joining(",", "-> ", "."));
        System.out.println("Name of balls greater than size 1 :: " + ballNames);
    }
}       </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
Name of balls greater than size 1 -> football,basketBall,volleyBall.   </pre>
    </div>    
 <br> 

    <h2>2. Java 8 Collectors minBy(), maxBy() example</h2>
    
    <p><b><i>minBy() & maxBy()</b></i> methods use a <b><i>Comparator</b></i> to compare the elements from the stream they are being collected
        and return a <b><i>Collector</b></i>.</p>

    <div id="solution">
        <h4>a) Below example shows how to use minBy() & maxBy() on a stream.</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Stream Collectors minBy & maxBy() example   
package java8;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectorsMinByExample {

    public static void main(String[] args) {
        Stream&lt;String> stream = Stream.of("Harry", "Alan", "Tom", "John");
        Optional&lt;String> op = stream.collect(Collectors.minBy(String::compareTo));
        if (op.isPresent()) {
           System.out.println(op.get());
        } else {
           System.out.println("Nothing!");
        }
         
        stream = Stream.of("Harry", "Alan", "Tom", "John"); 
        op = stream.collect(Collectors.maxBy(String::compareTo));
        if (op.isPresent()) {
           System.out.println(op.get());
        } else {
           System.out.println("Nothing!");
        }
    }
}       </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
Alan   
Tom</pre>
    </div>    
 <br>
 
    <div id="solution">
        <h4>b) Another minBy() & maxBy() example with custom Comparator.</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Stream Collectors minBy & maxBy() example   
package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors; 

public class CollectorsMinByExample {

    public static void main(String[] args) {
         Ball tennis = new Ball("tennis", 1, "green");
         Ball footBall = new Ball("football", 2, "white");
         Ball basketBall = new Ball("basketBall", 3, "orange");
         Ball volleyBall = new Ball("volleyBall", 4, "orange");
         
         List&lt;Ball> balls = Arrays.asList(tennis, footBall, basketBall, volleyBall);
         Optional&lt;Ball> ball = balls.stream().collect(Collectors.minBy((b1, b2)
            -> b1.getSize() - b2. getSize()));
         if (ball.isPresent()) {
            System.out.println("Smallest ball :: " + ball);
         } else {
            System.out.println("Not found!");
         }
         
         ball = balls.stream().collect(Collectors.maxBy((b1, b2) -> b1.getSize() - b2. getSize()));
         if (ball.isPresent()) {
            System.out.println("Biggest ball :: " + ball);
         } else {
            System.out.println("Not found!");
         }
    }
}

class Ball {

    private String name;
    private int size;
    private String color;

    public Ball(String name, int size, String color) {
        this.name = name;
        this.size = size;
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public int getSize() {
        return size;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return "Ball [name=" + name + ", size=" + size + ", color=" + color + "]";
    }

}       </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
Smallest ball :: Optional[Ball [name=tennis, size=1, color=green]]
Biggest ball :: Optional[Ball [name=volleyBall, size=4, color=orange]]</pre>
    </div>    
 <br>

    
References : <br><br>
    </div> <!-- blog div-->
    <a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html#joining-java.lang.CharSequence-java.lang.CharSequence-java.lang.CharSequence-" target="_blank">Oracle Docs Collectors joining()</a>    <br><br>
    
    <a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html" target="_blank">Oracle Docs Collectors</a> 
    
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    
<?php 
    include("footer.htm");
?>
    
</body>
</html>
