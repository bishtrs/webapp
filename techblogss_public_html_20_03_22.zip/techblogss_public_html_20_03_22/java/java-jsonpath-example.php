<?php include("../header.htm");?>

<head>
    <title>JsonPath java example</title>
    <meta name="description" content="JsonPath java example" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-jsonpath-example">
</head>

<body>
    <?php include("../navigation.htm");?>
    
    <div id="content">
    <div id="blog">
    <div id="problem">
        <h2>JsonPath Java example</h2>
    </div>
    
    <div id="solution">
        <p>
        Like <code>XPath</code> is used to extract data from a <code>XML</code> document similarly, <code>JsonPath</code> is used to extract data
        from a <code>JSON</code> document. The root of a <code>JSON</code> document is identified by using ($) character.
        </p>
        <p>
        In this example we will show how to use JsonPath to extract content from a <code>JSON</code> document.
        </p>
    </div>
    
    <p>First you need to download below dependency</p>
<div id="code">
    <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>com.jayway.jsonpath&lt;/groupId>
    &lt;artifactId>json-path&lt;/artifactId>
    &lt;version>2.0.0&lt;/version>
&lt;/dependency>
</pre></div></br>

    <div id="solution">
        <h4>1) Extract value from JSON at root level</h4>
        <p>
        In below example we find id element which is at the root level. Root level elements can be found using "$" character.
        We also search for first element of subjects arrays using "$.subjects[0]"
        </p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
package json;

import java.util.List;

import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;


public class JsonPathTest {
    public static void main(String[] args) {
        String json = "{\"id\":12345, \"studentname\":\"James Anderson\", \"age\":35,"
            + " \"subjects\":[\"Computer Science\", \"Physics\"]}";

        Integer id = JsonPath.read(json, "$.id");
        System.out.println(id);
        String subject = JsonPath.read(json, "$.subjects[0]");
        System.out.println(subject);
		
    }
} </pre></div>
    
    <div id="solution">
        <h4>Console Output : </h4>
    </div>
    
    
    <div id="code">
        <pre class="prettyprint">12345
Computer Science   </pre></div>

    <div id="solution">
        <h4>2) Using Predicates to Filter Items</h4>
        <p>
        We can also use predicates to filter an element in JSON. In below example, we will filter out students whose age is more than 30 years.
        </p>
    </div>
    
<div id="code">
    <pre class="prettyprint">
package json;

import java.util.List;

import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;


public class JsonPathTest {
	public static void main(String[] args) {
			
        String json = "{ \"students\" : [{\"id\":12345,	 \"name\":\"James Anderson\", \"age\":25,
                + \"subjects\":[\"computer science\",\"physics\"] }, "
                + "{\"id\":12346, \"name\":\"Keanu Reeves\", \"age\":35,
                + \"subjects\":[\"computer science\",\"physics\"] } ]	}";
        List&lt;Object> names = JsonPath.read(json, "$.students[*].name");
        System.out.println(names);
		
        Filter filter =	Filter.filter(Criteria.where("age").lt(30));
        String expr = "$['students'][?].name";
        names = JsonPath.read(json, expr, filter);
        System.out.println(names);
    }
} </pre></div>
    
    <div id="solution">
        <h4>Console Output : </h4>
    </div>
    
    
    <div id="code">
        <pre class="prettyprint">
["James Anderson","Keanu Reeves"]
["James Anderson"]   </pre></div>
    
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
</body>

<?php 
    include("footer.htm");
?>

</html>
