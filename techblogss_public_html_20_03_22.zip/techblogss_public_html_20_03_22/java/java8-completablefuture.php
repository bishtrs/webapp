<?php 
    include("header.htm");
?>

<head>
    <title>CompletableFuture in Java</title>
	<meta name="description" content="CompletableFuture in Java, CompletableFuture example, completablefuture supplyasync, completablefuture exception handling" />
	<link rel="canonical" href="https://www.techblogss.com/java/java8-completablefuture">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>CompletableFuture example</h1>
	
	</div>
    <div id="solution">
        <!--<p>Visit this page to view <a href="https://www.techblogss.com/java/java_threads_futuretask" target="_blank">Future Task example</a></p>-->
        <p>
        1) Below example shows <b><i>CompletableFuture</b></i> example using <b><i>complete()</b></i> call. Note that if you don't invoke <b><i>complete()</b></i> then <b><i>CompletableFuture get()</b></i> will be blocked forever.
        </p>
    </div>
    
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFutureTaskExample {
    public static void main(String[] args) {
        CompletableFuture&lt;Long> completableFuture = new CompletableFuture&lt;>();
        Factorial task = new Factorial(10, completableFuture);
        Thread th = new Thread(task);
        th.start();

        long result = 0;
        System.out.println("Waiting to calculate factorial");
        try {
            result = completableFuture.get(); // blocking call
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        System.out.printf("Wait over, factorial of 10 is %d", result);
    }
}

class Factorial implements Runnable {
    private long number;
    private CompletableFuture&lt;Long> completableFuture;

    public Factorial(long number, CompletableFuture&lt;Long> completableFuture) {
        this.number = number;
        this.completableFuture = completableFuture;
    }

    @Override
    public void run() {
        long fact = 1;
        for (long cnt = 1; cnt &lt;= number; cnt++) {
            fact *= cnt;
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        completableFuture.complete(fact);
    }
}
	</pre>
	</div>

	<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Waiting to calculate factorial
Wait over, factorial of 10 is 3628800
		</pre>
	</div>		
	<br>
    <div id="solution">
    <p>
    2) Below example shows <b><i>CompletableFuture</b></i> example using <b><i>runAsync()</b></i> call to run a time consuming task asynchronously.
    </p>
    </div>
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFutureTaskExample {
    public static void main(String[] args) {
        Factorial task = new Factorial(10);
        CompletableFuture&lt;Void> completableFuture = CompletableFuture.runAsync(task);
            
        while (!completableFuture.isDone()) {
            System.out.println("Waiting to calculate factorial");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }

        System.out.printf("Wait over, factorial is calculated");
    }
}

class Factorial implements Runnable {
    private long number;

    public Factorial(long number) {
        this.number = number;
    }

    @Override
    public void run() {
        long fact = 1;
        for (long cnt = 1; cnt &lt;= number; cnt++) {
            fact *= cnt;
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
	</pre>
	</div>

	<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Waiting to calculate factorial
Waiting to calculate factorial
Waiting to calculate factorial
Waiting to calculate factorial
Waiting to calculate factorial
Waiting to calculate factorial
Wait over, factorial is calculated
		</pre>
	</div>	
    <br>
    
    <div id="solution">
    <p>
    3) <b><i>CompletableFuture supplyAsync()</b></i> example
    </p>
    
    </div>
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFutureTaskExample {
    public static void main(String[] args) {
        CompletableFuture<String> completableFuture =
            CompletableFuture.supplyAsync(()-> "CompletableFuture example");
        try {
            System.out.println(completableFuture.get());
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
            
        CompletableFuture<Integer> completableFuture2 = CompletableFuture.supplyAsync(()-> 50);
        try {
            System.out.println(completableFuture2.get());
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>

	<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
CompletableFuture example
50
		</pre>
	</div>	
    
    <br>

        <div id="solution">
    <p>
    4) <b><i>CompletableFuture thenApply()</b></i> example
    </p>
    
    </div>
	<div id="code">
	<pre class="prettyprint">
package java8;

import java.util.concurrent.CompletableFuture;

public class CompletableFutureTaskExample {
    public static void main(String[] args) {
    	CompletableFuture<String> cf = CompletableFuture.completedFuture("hello").thenApply(s -> {
    		return s.toUpperCase();
        });
    	System.out.println(cf.getNow(null));
            
    	CompletableFuture<Integer> cf2 = CompletableFuture.completedFuture(10).thenApply(i -> {
    		return i*i;
        });
    	System.out.println(cf2.getNow(null));
            
    }
}
	
	</pre>
	</div>

	<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
HELLO
100
		</pre>
	</div>	
    
    <br>
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : 
<ul>
<li><a href="https://www.techblogss.com/java/java_threads_futuretask" target="_blank">Future Task example</a></li><br>
<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/CompletableFuture.html" target="_blank">Oracle Docs CompletableFuture</a>	</li><br>
<li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/CompletionStage.html" target="_blank">Oracle Docs CompletionStage</a></li>
</ul>
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>
