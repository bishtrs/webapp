<?php 
    include("../header.htm");
?>

<head>
    <title>How to sort an ArrayList in Java</title>
	<meta name="description" content="How to sort an ArrayList in Java using Collections sort with Comparable, Comparator." />
	<link rel="canonical" href="https://www.techblogss.com/java/java-sort-arraylist">
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog" style="float:left;">
	<div id="problem">
		<h1>How to sort an ArrayList in Java ?</h1>
	</div>
    
	<div id="solution">
        <p>
        You can sort an ArrayList using <code>Collections sort()</code> by either implementating a <code>Comparable</code> or <code>Comparator</code>.
        <h4>Drawbacks of using Comparable:</h4>
        
		<ul>
			<li>The Class whose <code>List</code> needs to be sorted is tied to <code>Comparable</code> interface.</li>
			<li>You can't use <code>Comparable</code> interface to sort <code>List</code> of Objects of a Class that can't be modified, e.g. third party library class.</li>
        </ul>
        </p>
        
        <p>
        <h4>Benefits of using Comparator:</h4>
		<ul>
            <li>You can use <code>Comparator</code> interface for sorting when you want to sort an <code>List</code> by different attributes of a Class.</li>
			<li>The Class whose <code>List</code> needs to ne sorted is not tied to <code>Comparator</code> interface and you can change the <code>Comparator</code> implementation on the fly.</li>
			<li>You can use <code>Comparator</code> interface to sort <code>List</code> of Object of a Class that can't be modified, e.g. third party library class.</li>
        </ul>
        </p>
		
        <h4>1) Sort an ArrayList of String using Collections sort() by natural ordering of the elements</h4>
        <p>
        You can sort an <code>ArrayList</code> by natural order using <code>Collections sort()</code> method.
        It has following signature : <code>public static &lt;T extends Comparable&lt;&quest; super T&gt;&gt; sort(List&lt;T&gt; list)</code>
        </p>
        <p>
        It sorts the specified list in ascending order, according to the natural ordering of its elements. The <code>Class</code> whose object is present in the <code>ArrayList</code> must implement the <code>Comparable</code> interface. In the example below, we will create an <code>ArrayList</code> of String. Since <code>String</code> class implements <code>Comparable</code> interface, <code>Collections sort()</code> method will sort the <code>ArrayList</code> alphabetically.
        </p>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
// Sorts ArrayList alphabetically or by its natural order since String implements Comparable	
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestClass {
    public static void main(String[] args) {
        List&lt;String&gt; students = new ArrayList&lt;String&gt;();
        students.add("Harry");
        students.add("IronMan");
        students.add("Batman");
        System.out.println("Before sorting " + students);
		
        Collections.sort(students); // Sort ArrayList
        System.out.println("After sorting " + students);
    }
}	</pre></div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Before sorting [Harry, IronMan, Batman]
After sorting [Batman, Harry, IronMan]		</pre></div><br>	
	

	<div id="solution">
		<h4>2) Sort an ArrayList using Collections sort() & custom Comparable implementation</h4>
        <p>
        In this example, we write a Celebrity class which implements <code>Comparable</code> interface and it defines logic of sorting objects of Celebrity class. You need to implement <code>Comparable compareTo()</code> method. It has following signature :   <code>int compareTo(T o)</code>
        </p>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
// Sorts ArrayList	
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Celebrity implements Comparable&lt;Celebrity&gt; {
    private String name;
    private int rank;
	
    Celebrity (String name, int rank) {
        this.name = name;
        this.rank = rank;
    }
	
    public String getName() {
        return name;
    }
    
	public int getRank() {
        return rank;
    }

    public int compareTo(Celebrity obj) {
        return this.getRank() - obj.getRank();
    }
	
    @Override
    public String toString() {
        return "Celebrity [name=" + name + ", rank=" + rank + "]";
    }
	
}
			
public class TestClass {
    public static void main(String[] args) {
        List&lt;Celebrity&gt; celebrities = new ArrayList&lt;Celebrity&gt;();
        Celebrity celebrity1 = new Celebrity("Harry", 1);
        Celebrity celebrity2 = new Celebrity("IronMan", 3);
        Celebrity celebrity3 = new Celebrity("Batman", 2);
        celebrities.add(celebrity1);
        celebrities.add(celebrity2);
        celebrities.add(celebrity3);
        System.out.println("Before sorting " + celebrities);
		
        Collections.sort(celebrities); // Sort ArrayList
        System.out.println("After sorting " + celebrities);		
    }
}	</pre></div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Before sorting [Celebrity [name=Harry, rank=1], Celebrity [name=IronMan, rank=3],
Celebrity [name=Batman, rank=2]]<br>
After sorting [Celebrity [name=Harry, rank=1], Celebrity [name=Batman, rank=2],
Celebrity [name=IronMan, rank=3]]		</pre></div><br>	
	
		
	<div id="solution">
		<h4>3) Sort an ArrayList of Celebrity class objects using Collections sort(Comparator) and Comparator</h4>
        <p>
        In this example, we write a Celebrity class whose objects can be sorted by various Class attributes using <code>Comparator</code> interface.
        In each of the sort implementation, you need to implement <code>Comparator compareTo()</code> method. It has following signature :   
        <code>int compare(T o1,T o2)</code>
        </p>
        <p>
        Observe that when using <code>Comparator</code> we are not tied to a specific sorting implementation, we can change the sorting logic by just implementating a seperate <code>Comparator</code>. 
        </p>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Celebrity {
    private String name;
    private int rank;
    private int networth;
	
    Celebrity (String name, int rank, int networth) {
        this.name = name;
        this.rank = rank;
        this.networth = networth;
    }
	
    public String getName() {
        return name;
    }
	
    public int getRank() {
        return rank;
    }
	
    public int getNetworth() {
        return networth;
    }
	
    @Override
    public String toString() {
        return "Celebrity [name=" + name + ", rank=" + rank + ", networth="
            + networth + "]";
    }	
}

// Sorts ArrayList using Comparator by networth of Celebrity		
class CelebrityNetWorthComparator implements Comparator&lt;Celebrity&gt;{

    public int compare(Celebrity cel1, Celebrity cel2) {
        return (cel1.getNetworth() &lt; cel2.getNetworth()) ?
            -1 : ((cel1.getNetworth() == cel2.getNetworth()) ? 0 : 1);
    }
}

// Sorts ArrayList using Comparator by rank of Celebrity
class CelebrityRankComparator implements Comparator&lt;Celebrity&gt;{

    public int compare(Celebrity cel1, Celebrity cel2) {
         return (cel1.getRank() &lt; cel2.getRank()) ?
            -1 : ((cel1.getRank() == cel2.getRank()) ? 0 : 1);
    }
}			

public class TestClass {
    public static void main(String[] args) {
        List&lt;Celebrity&gt; celebrities = new ArrayList&lt;Celebrity&gt;();
        Celebrity celebrity1 = new Celebrity("Harry", 1, 100000);
        Celebrity celebrity2 = new Celebrity("IronMan", 3, 2000000);
        Celebrity celebrity3 = new Celebrity("Batman", 2, 50000);
        
        celebrities.add(celebrity1);
        celebrities.add(celebrity2);
        celebrities.add(celebrity3);
        System.out.println("Before sorting " + celebrities);
		
        // Compare celebrities by their networth, Sort ArrayList
        Collections.sort(celebrities, new CelebrityNetWorthComparator());  
        System.out.println("After sorting by networth " + celebrities);
		
        // Compare celebrities by their rank, Sort ArrayList
        Collections.sort(celebrities, new CelebrityRankComparator());
        System.out.println("After sorting by rank " + celebrities);
    }
}	</pre></div>
	
 <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Before sorting [Celebrity [name=Harry, rank=1, networth=100000], Celebrity [name=IronMan, rank=3, networth=2000000], Celebrity [name=Batman, rank=2, networth=50000]]
After sorting by networth [Celebrity [name=Batman, rank=2, networth=50000], Celebrity [name=Harry, rank=1, networth=100000], Celebrity [name=IronMan, rank=3, networth=2000000]]
After sorting by rank[Celebrity [name=Harry, rank=1, networth=100000], Celebrity [name=Batman, rank=2, networth=50000], Celebrity [name=IronMan, rank=3, networth=2000000]]		</pre></div>		
	
	    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Collections.html#sort-java.util.List-">Oracle Docs Collections sort()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Comparable.html#compareTo-T-">Oracle Docs Comparable compareTo() </a> <br><br>		
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html#compare-T-T-">Oracle Docs Comparator compare() </a> <br><br>		
	
    </div> <!-- blog div-->
    <?php include("../sidebar/sidebar.htm"); ?>
    </div> <!-- content div -->
    
        
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>