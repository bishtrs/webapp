<?php include("../header.htm");?>

<head>
    <title>Gson Parse JSON, Convert JSON to Object</title>
	<meta name="description" content="Gson Parse JSON, Convert JSON to Object, Convert JSON string to Java object, Convert Java object to JSON string" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_parsejson_gson">
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
    <div id="content">
    <div id="blog">
	<div id="problem">
		<h2>Parse JSON using Gson, convert JSON to Object and vice-versa</h2>
	</div>
	
	<div id="solution">
		<h4> To parse JSON using Gson, you need to download gson-2.8.5.jar from  <a href="http://central.maven.org/maven2/com/google/code/gson/gson/2.8.5/gson-2.8.5.jar"> gson-2.8.5.jar</a></h4>
        <p>
        For converting small- or medium-sized lists, Gson provides a better response compared to Jackson. For large lists, Jackson provides 
        a better response than Gson.
        </p>
        <p>Below is the JSON string to parse</p>
	</div>
    
  <div id="code">
	
    <pre class="prettyprint">
{
    "id":12345, 
    "name":"Jason Bourne",
    "age":35,
    "emailaddress":["j.bourne@gmail.com", "j.bourne@yahoo.com"]
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Java class used to convert JSON String to object and vice-versa.</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.List;
    
public class Employee {
    
    private int id;
    private String name;
    private int age;
    private List&lt;String&gt; emailaddress;
        
    // removed getter and setter      
    
    @Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ","
            +" age=" + age + ", emailaddress=" + emailaddress + "]";
	}    
    
}
    </pre>
	</div>
 
<div id="solution">
		<h4>1) Convert JSON string to Java object using Gson.</h4>
	</div> 
    <div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
	
public class TestGsonParser {
    public static void main(String[] args) {
        String jsonString = "{\"id\":12345, \"name\":\"Jason Bourne\", \"age\":35,"
            + " \"emailaddress\":[\"j.bourne@gmail.com\", \"j.bourne@yahoo.com\"]}";
                
        Gson gson = new Gson();    
        // parse json string to object
        Employee employee = gson.fromJson(jsonString, Employee.class); 
        System.out.println(employee);
            
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
Employee [id=12345, name=Jason Bourne, age=35, emailaddress=[j.bourne@gmail.com, j.bourne@yahoo.com]]
    </pre>
	</div>
	
<div id="solution">
		<h4>2) Convert Java object to JSON string using Gson.</h4>
	</div>
  
    <div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
	
public class TestGsonParser {
    public static void main(String[] args) {
                
        Employee emp = new Employee();
        emp.setId(2345);
        emp.setName("James Bond");
        emp.setAge(40);
        
        List&lt;String&gt; emailaddress = new ArrayList&lt;&gt;();
        emailaddress.add("jbond@yahoo.com");
        emailaddress.add("jbond@gmail.com");
        emp.setEmailaddress(emailaddress);
		
        Gson gson = new Gson();    
        String jsonEmp = gson.toJson(emp); // create JSON String from Object
        System.out.print(jsonEmp);
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
{"id":2345,"name":"James Bond","age":40,"emailaddress":["jbond@yahoo.com","jbond@gmail.com"]}
    </pre>
	</div>	

	<div id="solution">
		<h4>You can prettify above JSON</h4>
	</div>
   <div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
	
public class TestGsonParser {
    public static void main(String[] args) {
                
        Employee emp = new Employee();
        emp.setId(2345);
        emp.setName("James Bond");
        emp.setAge(40);
        
        List&lt;String&gt; emailaddress = new ArrayList&lt;&gt;();
        emailaddress.add("jbond@yahoo.com");
        emailaddress.add("jbond@gmail.com");
        emp.setEmailaddress(emailaddress);
		
        Gson gson = new GsonBuilder().setPrettyPrinting().create();   
        String jsonEmp = gson.toJson(emp); // create JSON String from Object
        System.out.print(jsonEmp);
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
{
  "id": 2345,
  "name": "James Bond",
  "age": 40,
  "emailaddress": [
    "jbond@yahoo.com",
    "jbond@gmail.com"
  ]
}    </pre>
	</div>	
	
   

    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>    
    References : <a href="https://www.techblogss.com/java/java_parsejson_jackson">Parse JSON using Jackson parser in Java</a>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->    
</body>

<?php 
    include("footer.htm");
?>

</html>
