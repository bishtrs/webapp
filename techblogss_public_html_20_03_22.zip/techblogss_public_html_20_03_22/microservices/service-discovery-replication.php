    <?php include("../header.htm");?>

    <head>
        <title>Eureka Service Discovery Replication</title>
        <meta name="description" content="This tutorial explains how to run Eureka Service discovery in replication mode." />
        <link rel="canonical" href="https://www.techblogss.com/microservices/service-discovery-replication" />
    </head>

    <body>
        <?php 
            include("navigation.htm");
        ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Eureka Service Discovery Replication tutorial</h1>
        </div>
        <div id="solution">
            <p>When you run <b><i>Service Discovery</b></i> in production, you need at least two instances of discovery servers running as one server may go down or network may fail. Eureka supports peer-to-peer replication model which means all of the servers replicate data and
            send hearbeats to all the peers.</p>
            
			<p>This tutorial shows how to configure and run multiple discovery servers in replication mode. We will run three <b><i>Eureka Service discovery</b></i> servers with different profiles and register three instances of <b><i>DoctorService microservice</b></i> with each 
            of the discovery server. Then we will create a <b><i>DoctorClient application</b></i> which will fetch <b><i>DoctorService 
            microservice</b></i> from either of the discovery servers and call <b><i>DoctorService microservice</b></i>.</p>

            <p>Even if you shutdown one of the discovery servers,  <b><i>DoctorClient application</b></i> will still get response from doctor service
            as other two discovery servers are up.</p>
        </div>
        
        <div>
            <p>
            <img src="../images/microservices/servicediscoveryreplication.png" alt="Service Discovery Replication" 
            title="Eureka Service Discovery Replication">
            </p>
        
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>
        
       <h2>Below are the steps to launch Eureka Service Discovery in replication mode</h2>
       <h3>Step 1) Create pom.xml as below to create Eureka Discovery server application</h3>
        
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;

    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;eureka-service&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;packaging&gt;jar&lt;/packaging&gt;

    &lt;parent&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.2.1.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;

    &lt;properties&gt;
        &lt;project.build.sourceEncoding&gt;UTF-8&lt;/project.build.sourceEncoding&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-starter-netflix-eureka-server&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;/dependencies&gt;

    &lt;dependencyManagement&gt;
        &lt;dependencies&gt;
            &lt;dependency&gt;
                &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
                &lt;artifactId&gt;spring-cloud-dependencies&lt;/artifactId&gt;
                &lt;version&gt;Hoxton.RELEASE&lt;/version&gt;
                &lt;type&gt;pom&lt;/type&gt;
                &lt;scope&gt;import&lt;/scope&gt;
            &lt;/dependency&gt;
        &lt;/dependencies&gt;
    &lt;/dependencyManagement&gt;

    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;        </pre>
        </div>
        <br>

    <div id="1">
    <h3>Step 2) Create DiscoveryApplication class to launch Eureka Discovery Server in replication mode</h3>
    <div id="code">
    <pre class="prettyprint">
package com.example.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class DiscoveryApplication {

  public static void main(String[] args) {
    SpringApplication.run(DiscoveryApplication.class, args);
  }
}  </div>
    </pre>	
    <br>
    
<h3>Step 3) Create application.yml file under src/main/resources</h3>
    <div id="code">
    <pre class="prettyprint">
spring:  
  application:
    name: discovery-service

---
spring:
  profiles: peer1
eureka:
  instance:
    hostname: localhost
  client:
    serviceUrl:
      defaultZone: http://localhost:8762/eureka/,http://localhost:8763/eureka/
server:  
  port: 8761

---
spring:
  profiles: peer2
eureka:
  instance:
    hostname: localhost
  client:
    serviceUrl:
     defaultZone: http://localhost:8761/eureka/,http://localhost:8763/eureka/
server:  
  port: 8762

---
spring:
  profiles: peer3
eureka:
  instance:
    hostname: localhost
  client:
    serviceUrl:
      defaultZone: http://localhost:8762/eureka/,http://localhost:8761/eureka/ 
server:  
  port: 8763    </div>
    </pre>	

    </div>    

 <br>
    <h3>Step 4) Launch three instances of DiscoveryApplication using below commands :</h3> <b><i>java -Dspring.profiles.active=peer1 -jar eureka-service-0.0.1-SNAPSHOT.jar</b></i><br><b><i>java -Dspring.profiles.active=peer2 -jar eureka-service-0.0.1-SNAPSHOT.jar</b></i><br>
    <b><i>java -Dspring.profiles.active=peer3 -jar eureka-service-0.0.1-SNAPSHOT.jar</b></i></p>

    <p>Launch <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a> in the browser to see the discovery servers.</p>
    <p>Now <b><i>Eureka Discovery Server</b></i> is running in <b><i>replication</b></i> mode.</p>
    
    <h3>Step 5) Create pom.xml file as mentioned below for DoctorService application</h3>
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?>
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    &lt;modelVersion>4.0.0&lt;/modelVersion>

    &lt;groupId>com.example&lt;/groupId>
    &lt;artifactId>doctor-service&lt;/artifactId>
    &lt;version>0.0.1-SNAPSHOT&lt;/version>
    &lt;packaging>jar&lt;/packaging>

    &lt;parent>
	&lt;groupId>org.springframework.boot&lt;/groupId>
	&lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
	&lt;version>2.2.1.RELEASE&lt;/version>
	&lt;relativePath /> &lt;!-- lookup parent from repository -->
    &lt;/parent>

    &lt;properties>
	&lt;project.build.sourceEncoding>UTF-8&lt;/project.build.sourceEncoding>
	&lt;java.version>1.8&lt;/java.version>
    &lt;/properties>

    &lt;dependencies>
	&lt;dependency>
		&lt;groupId>org.springframework.cloud&lt;/groupId>
		&lt;artifactId>spring-cloud-starter-netflix-eureka-client&lt;/artifactId>
	&lt;/dependency>
	&lt;dependency>
		&lt;groupId>org.springframework.boot&lt;/groupId>
		&lt;artifactId>spring-boot-starter-web&lt;/artifactId>
	&lt;/dependency>

    &lt;/dependencies>

    &lt;dependencyManagement>
	&lt;dependencies>
		&lt;dependency>
			&lt;groupId>org.springframework.cloud&lt;/groupId>
			&lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
			&lt;version>Hoxton.RELEASE&lt;/version>
			&lt;type>pom&lt;/type>
			&lt;scope>import&lt;/scope>
		&lt;/dependency>
	&lt;/dependencies>
    &lt;/dependencyManagement>

    &lt;build>
	&lt;plugins>
		&lt;plugin>
			&lt;groupId>org.springframework.boot&lt;/groupId>
			&lt;artifactId>spring-boot-maven-plugin&lt;/artifactId>
		&lt;/plugin>
	&lt;/plugins>
    &lt;/build>

&lt;/project>
        </div>
        </pre>	    
        
        <br>
        
     <h3>Step 6) Create Doctor, DoctorApplication & DoctorRestController classes</h3>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

public class Doctor {

    private String name;
    private String speciality;

    public Doctor(String name, String speciality) {
        this.name = name;
        this.speciality = speciality;
    }

    public String getName() {
        return name;
    }

    public String getSpeciality() {
        return speciality;
    }

}   </div>
        </pre>
        
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class DoctorApplication {

    public static void main(String[] args) {
        SpringApplication.run(DoctorApplication.class, args);
    }
}
   </div>
        </pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DoctorRestController {
	
    List&lt;Doctor> doctors = new ArrayList&lt;>();
        
    public DoctorRestController() {
    	doctors.add(new Doctor("Andy Thomas", "Orthopedic"));
    	doctors.add(new Doctor("James Hardy", "Physician"));
    	doctors.add(new Doctor("Ana Marie", "Pediatric"));
    }

    @GetMapping("/{id}") 
    public Doctor get(@PathVariable("id") int id) {
    	System.out.println("id ##" + id);
        return doctors.get(id);
    }
}      </div>
        </pre>        
        <br>
 
    <h3>Step 7) Create application.yml file under src/main/resources</h3>
    <div id="code">
    <pre class="prettyprint">
spring:  
  application:
    name: doctor-service

---
spring:
  profiles: peer1
eureka:
  client:
    serviceUrl:
      defaultZone: http://localhost:8761/eureka/,http://localhost:8762/eureka/,http://localhost:8763/eureka/
server:  
  port: 8081

---
spring:
  profiles: peer2
eureka:
  client:
    serviceUrl:
     defaultZone: http://localhost:8762/eureka/,http://localhost:8761/eureka/,http://localhost:8763/eureka/
server:  
  port: 8082

---
spring:
  profiles: peer3
eureka:
  client:
    serviceUrl:
      defaultZone: http://localhost:8763/eureka/,http://localhost:8761/eureka/,http://localhost:8762/eureka/   
server:  
  port: 8083    </div>
    </pre>	 
   <br>  

    <h3>Step 8) Launch three instances of DoctorApplication using below commands :</h3> <b><i>java -Dspring.profiles.active=peer1 -jar doctor-service-0.0.1-SNAPSHOT.jar</b></i><br><b><i>java -Dspring.profiles.active=peer2 -jar doctor-service-0.0.1-SNAPSHOT.jar</b></i><br>
    <b><i>java -Dspring.profiles.active=peer3 -jar doctor-service-0.0.1-SNAPSHOT.jar</b></i></p>   
   
	<h3>Step 9) Create pom.xml file as mentioned in Step # 5 to create DoctorClientApplication as Eureka Client.
Just update the artifactId in the pom.xml to below  </h3>
        <div id="code">
        <pre class="prettyprint">
&lt;groupId&gt;com.example&lt;/groupId&gt;
&lt;artifactId&gt;doctor-client&lt;/artifactId&gt;
&lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
&lt;packaging&gt;jar&lt;/packaging&gt;        </div>
        </pre>	    
        
        <br>
		
<h3>Step 10) Create DoctorClientApplication & DoctorClientRestController classes</h3>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(DoctorClientApplication.class, args);
    }
}   </div>
    </pre>		

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class DoctorClientRestController {

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/doctor-client/{id}")
    public ResponseEntity&lt;?> getDoctor(@PathVariable String id) {
        return restTemplate.getForEntity("http://doctor-service/"+id, String.class);
    }
        
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}   </div>
    </pre>			
    <br>

    <h3>Step 11) Create application.yml file under src/main/resources</h3>
    <div id="code">
    <pre class="prettyprint">
spring:  
  application:
    name: doctor-client

eureka:
  client:
    serviceUrl:
      defaultZone: http://localhost:8761/eureka/,http://localhost:8762/eureka/,http://localhost:8763/eureka/
      register-with-eureka: false
server:  
  port: 8084    </div>
    </pre>	 
   <br>  
   
    <h3>Step 12) Launch DoctorClientApplication and open <a href="http://localhost:8084/doctor-client/1" target="_blank">
    http://localhost:8084/doctor-client/1</a> in the browser.</h3>
    <p>Note that <b><i>DoctorClientRestController</b></i> internally calls <b><i>http://doctor-service/1</b></i>. This means
    <b><i>DoctorService</b></i> instance was fetched from <b><i>Eureka Servie Registry</b></i>
    and then it was invoked.</p>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/servicediscoveryreplication_2.png" alt="Calling microservice" style="width:400px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br>
    </div>
    
    <br>   
    
    <h3>Step 13) Also check below urls in broswer which will show registered services and peer discovery servers:</h3>
    <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a> <br>
    <a href="http://localhost:8762" target="_blank">http://localhost:8762/</a> <br>
    <a href="http://localhost:8763" target="_blank">http://localhost:8763/</a> <br>
        
<br>   
        
    References : <br><br>
    <a href="https://spring.io/guides/gs/service-registration-and-discovery/">Spring Service Registration and Discovery</a>	<br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>