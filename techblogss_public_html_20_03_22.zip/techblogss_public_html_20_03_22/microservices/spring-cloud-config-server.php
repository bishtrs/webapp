<?php include("../header.htm");?>

<head>
    <title>Spring Boot Config Server example</title>
    <meta name="description" content="Spring Boot Config Server example" />
    <link rel="canonical" href="https://www.techblogss.com/microservices/spring-cloud-config-server" />
</head>

<body>
    <?php include("../navigation.htm");?>
        
    <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Config Server example</h1>
        </div>
        <div id="solution">
            <p>This tutorial shows how to configure and launch a <b><i>Config Server</b></i> using <b><i>Spring Boot</b></i>.</p> 
            <p>
            <b><i>Spring Cloud Config</b></i> provides server as well as client side support for externalized configuration
            in a distributed system. Using <b><i>Config Server</b></i>, you can keep application configuration related properties across all environments at one place.
            The <b><i>Spring Cloud Configuration</b></i> server is a REST-based application which is built on top of Spring Boot. It exposes
            APIs which return property in form of <code>JSON</code>, <code>YAML</code>, properties format.
            </p>
            <p>
            <b><i>Spring Cloud Configuration</b></i> server can be configured with <code>Git/Database/File</code> System as backend which will
            store the application configuration. In this example we will use <code>Git</code> as backend system.
            </p>
        </div>
        
        <h4>Step 1) Download Git</h4>
        <div>You can download Git from here <a href="https://gitforwindows.org/" target="_blank">Download Git</a></div>
        <p>Now create a directory named config-server and application-local.properties, application-dev.properties files using
        below commands.</p>
        
        <div id="code">
        <pre class="prettyprint">
C:\ cd %HOMEPATH%
C:\ mkdir config-repo
C:\ cd config-repo
C:\ git init .
C:\ echo env = dev > config-server-dev.properties
C:\ echo message = this is dev configuration >> config-server-dev.properties
C:\ echo env = local > config-server-local.properties
C:\ echo message = this is local configuration >> config-server-local.properties
C:\ git add -A .
C:\ git commit -m "Added properties files"   </pre></div><br>
        
        <h4>Step 2) Create pom.xml for config server project and add below dependencies</h4>

<div id="code">
<pre class="prettyprint">
&lt;dependencyManagement&gt;
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-config-server&lt;/artifactId&gt;
            &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;/dependency&gt;
    &lt;/dependencies&gt;
&lt;/dependencyManagement&gt;
 
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
        &lt;artifactId&gt;spring-cloud-config-server&lt;/artifactId&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-actuator&lt;/artifactId&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-test&lt;/artifactId&gt;
        &lt;scope&gt;test&lt;/scope&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;
 
&lt;repositories&gt;
    &lt;repository&gt;
        &lt;id&gt;central-repo&lt;/id&gt;
        &lt;name&gt;Central Repository&lt;/name&gt;
        &lt;url&gt;https://repo1.maven.org/maven2&lt;/url&gt;
    &lt;/repository&gt;
&lt;/repositories&gt; </pre></div><br>

        <h4>Step 2) Create ConfigServer class that will launch config server</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@EnableConfigServer
@SpringBootApplication
public class ConfigServer {
    public static void main(String[] args) {
        SpringApplication.run(ConfigServer.class, args);
    }
}        </div>
        </pre>
        <br>
  
    <h4>Step 3) Create bootstrap.yml file</h4>
 <p>You need <b><i>bootstrap.yml</b></i> file to load the config server configuration. Choosing port as 8888 is better as by default on client side this port is used by spring.cloud.config.uri.</p>
        <div id="code">
        <pre class="prettyprint">
#Server port
server:
  port: 8888
 
#Git repo location
spring:
  application:
    name: config-server
  cloud:
    config:
      server:
        git:
          uri: C:\\Users\\bisht\\Git\\config-repo        </div>
        </pre> 
        <br>

        <h4>Step 4) Launch ConfigServer application</h4>
       
       <div id="solution">
            <h4>Console Output : </h4>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2020-09-04 13:25:55.390  INFO 7768 --- [           main] com.example.demo.ConfigServer            : Started ConfigServer in 10.234 seconds (JVM running for 11.025)
            </pre></div><br>

     <h4>Step 5) Validate Config Server</h4>
     <p>Open any browser and launch <a href="http://localhost:8888/config-server/dev" target="_blank">http://localhost:8888/config-server/dev</a>. You will see below details displayed in the broswer.</p><br>
     
        <div>
            <p><img src="../images/microservices/configserver.png" alt="Maven Build" style="width:600px;height:400px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<div>
		Launch <a href="http://localhost:8888/config-server/local" target="_blank">http://localhost:8888/config-server/local</a>. You will see below details displayed in the broswer.
        </div><br>
     
        <div>
            <p><img src="../images/microservices/configserver_2.png" alt="Maven Build" style="width:600px;height:400px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
        
    References : <br><br>
    <a href="https://cloud.spring.io/spring-cloud-config/reference/html/" target="_blank">Spring Cloud Config</a> <br><br>
      </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
        <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>